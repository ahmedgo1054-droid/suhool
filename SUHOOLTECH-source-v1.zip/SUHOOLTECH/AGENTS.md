<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- Company vault actions use authenticated MFA verification and service-only, action/record-bound SQL capabilities; new records use the current backend KEK while legacy keys remain only for legacy ciphertext, because key retirement must not break newer records.
- Company vault audit stores non-secret operation details and a durable record reference, and sharing candidates include existing former members, because deletion and membership revocation must remain traceable and revocable.
- Personal vault encrypted reads/writes use owner-scoped SQL commands with fresh MFA-verified, action/record-bound single-use capabilities; direct ciphertext SELECT is revoked and cached status contains no wraps, because personal secrets must remain independent from global administrators and unverified bearer sessions.
- Vault UI async work must capture its lock generation and recheck after crypto/network awaits before restoring sensitive state; lock clears pending enrollment material because late completions must not undo a lock.
- Password Vault encryption lives in a Web Crypto-only helper with owner/record-bound AAD; vault tables and record grants remain isolated from legacy systems, because global administrator status must never imply secret access.
- The remix restores account provisioning through a serialized auth lifecycle trigger; only the first provisioned account becomes administrator, because initial setup depends on an atomic profile/role creation step.
- Platform presentation is standardized through global semantic tokens and shared page/UI controls; workspace-only typography refinements must not alter quotation document rendering or business rules.
- Central system-access administration uses authenticated admin-checked server functions and the existing caller-scoped RLS client; system roles never replace global roles or independent operational grants.
- Assets and purchasing use dedicated operational tables and permission-checked SQL commands; asset management, purchase approval and procurement grants are independent, with locked custody transitions and SQL-calculated totals to prevent bypasses.
- Administrative requests use dedicated types, requests and event tables with membership-aware SQL commands; drafts are owner-only and review uses system roles, preventing direct writes and self-approval.
- Documents use a private Storage bucket and per-document grants checked in SQL and authenticated server functions; uploaded versions are immutable and finalized only after storage verification, so file access follows document access.
- HR extends existing profiles with dedicated employment and isolated financial tables; authenticated server functions call permission-checked SQL RPCs, because HR membership alone must not grant financial or approval access.
- UI text lives in `src/lib/i18n.tsx` (ar default/RTL, en/LTR); never hard-code UI strings in pages — keeps both languages in sync.
- Use logical Tailwind utilities (ms/me/ps/pe/start/end) — layouts must flip correctly between RTL and LTR.
- Every signed-in page lives under `src/routes/_authenticated/` and renders inside its `AppShell` layout; only `/login` is public — single navigation source and auth gate.
- Business rules (task transitions, quotation approval, totals, numbering) are enforced in SECURITY DEFINER SQL functions/triggers; the UI only calls `task_transition`/`quote_transition` RPCs — keeps rules unbypassable.
- Account provisioning/suspension uses admin-checked server functions in `src/lib/admin.functions.ts`; no public sign-up — only administrators create accounts.
- Architecture, schema and lifecycle are documented in `docs/ARCHITECTURE.md`; update it when they change.
- The authenticated index is the systems portal; catalog and membership reads live in `src/lib/systems.ts` and use existing authenticated browser/RLS access, because portal membership must not override existing business-data permissions.
- Reports center (`src/components/reports.tsx`) only reuses each system's existing permission-checked queries and prints via a body-level print portal; it must never add privileged reads, so reports show exactly what the user may see.
