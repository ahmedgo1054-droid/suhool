import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  generate: vi.fn(), wrap: vi.fn(), encrypt: vi.fn(), run: vi.fn(), enroll: vi.fn(),
  factors: vi.fn(), refetch: vi.fn(),
}));
vi.mock('@tanstack/react-query', () => ({ queryOptions: (v: unknown) => v, useSuspenseQuery: () => ({ data: { ownerId: 'owner', hasKey: false }, refetch: mocks.refetch }) }));
vi.mock('@tanstack/react-start', () => ({ useServerFn: () => mocks.run }));
vi.mock('@/lib/personal-vault.functions', () => ({ getPersonalVault: vi.fn(), personalVaultAction: vi.fn() }));
vi.mock('@/integrations/supabase/client', () => ({ supabase: { auth: { mfa: { listFactors: mocks.factors, enroll: mocks.enroll, unenroll: vi.fn() } } } }));
vi.mock('@/lib/i18n', () => ({ useI18n: () => ({ t: (s: string) => s, dir: 'ltr' }) }));
vi.mock('@/components/company-vault', () => ({ CompanyVault: () => null }));
vi.mock('@/lib/vault-crypto', () => ({
  generateVaultKey: mocks.generate, wrapPersonalKey: mocks.wrap, encryptVaultValue: mocks.encrypt,
  generateRecoveryPassphrase: () => 'synthetic recovery', unwrapPersonalKey: vi.fn(), decryptVaultValue: vi.fn(),
}));
import { PersonalVault } from '@/components/personal-vault';

function deferred<T>() { let resolve: ((value: T) => void) | undefined; const promise = new Promise<T>(r => { resolve = r; }); return { promise, finish: (v: T) => resolve?.(v) }; }
function hideTab() { Object.defineProperty(document, 'hidden', { configurable: true, value: true }); fireEvent(document, new Event('visibilitychange')); }
async function prepare() {
  fireEvent.change(screen.getByLabelText('v_passphrase'), { target: { value: 'synthetic passphrase' } });
  fireEvent.change(screen.getByLabelText('v_repeat'), { target: { value: 'synthetic passphrase' } });
  fireEvent.click(screen.getByRole('button', { name: 'v_setup' }));
}
beforeEach(() => {
  vi.clearAllMocks(); Object.defineProperty(document, 'hidden', { configurable: true, value: false });
  mocks.factors.mockResolvedValue({ data: { totp: [{ id: 'factor', status: 'verified' }], all: [] } });
  mocks.generate.mockResolvedValue({}); mocks.wrap.mockResolvedValue({}); mocks.run.mockResolvedValue({ records: [] }); mocks.refetch.mockResolvedValue({});
});
afterEach(cleanup);

it('does not restore pending setup or its recovery key when crypto finishes after locking', async () => {
  const work = deferred<object>(); mocks.generate.mockReturnValue(work.promise);
  render(<PersonalVault />); await waitFor(() => expect(screen.queryByRole('button', { name: 'v_mfa_enroll' })).toBeNull());
  await prepare(); hideTab(); await act(async () => work.finish({}));
  expect(screen.queryByRole('dialog')).toBeNull(); expect(mocks.wrap).not.toHaveBeenCalled(); expect(mocks.run).not.toHaveBeenCalled();
});

it('does not restore pending setup when wrapping finishes after locking', async () => {
  const work = deferred<object>(); mocks.wrap.mockReturnValue(work.promise);
  render(<PersonalVault />); await waitFor(() => expect(screen.queryByRole('button', { name: 'v_mfa_enroll' })).toBeNull());
  await prepare(); await waitFor(() => expect(mocks.wrap).toHaveBeenCalledTimes(2)); hideTab(); await act(async () => work.finish({}));
  expect(screen.queryByRole('dialog')).toBeNull(); expect(mocks.run).not.toHaveBeenCalled();
});

it('discards an enrollment response that arrives after tab lock', async () => {
  mocks.factors.mockResolvedValue({ data: { totp: [], all: [] } }); const work = deferred<object>(); mocks.enroll.mockReturnValue(work.promise);
  render(<PersonalVault />); fireEvent.click(await screen.findByRole('button', { name: 'v_mfa_enroll' }));
  await waitFor(() => expect(mocks.enroll).toHaveBeenCalled()); hideTab();
  await act(async () => work.finish({ data: { id: 'factor', totp: { qr_code: 'data:image/png;base64,synthetic' } } }));
  expect(screen.queryByRole('img')).toBeNull(); expect(screen.getByRole('button', { name: 'v_setup' })).toBeDisabled();
});

it('erases displayed enrollment material and permits re-enrollment on lock', async () => {
  mocks.factors.mockResolvedValue({ data: { totp: [], all: [] } }); mocks.enroll.mockResolvedValue({ data: { id: 'factor', totp: { qr_code: 'data:image/png;base64,synthetic' } } });
  render(<PersonalVault />); fireEvent.click(await screen.findByRole('button', { name: 'v_mfa_enroll' }));
  await screen.findByRole('img'); hideTab();
  expect(screen.queryByRole('img')).toBeNull(); expect(screen.getByRole('button', { name: 'v_mfa_enroll' })).toBeEnabled();
});

it('does not issue an encrypted save after the editor is locked while encryption is pending', async () => {
  render(<PersonalVault />); await waitFor(() => expect(screen.queryByRole('button', { name: 'v_mfa_enroll' })).toBeNull());
  await prepare(); fireEvent.click(await screen.findByRole('checkbox'));
  fireEvent.change(screen.getByLabelText('v_code'), { target: { value: '123456' } }); fireEvent.click(screen.getByRole('button', { name: 'v_verify' }));
  fireEvent.click(await screen.findByRole('button', { name: 'v_new' }));
  fireEvent.change(screen.getByLabelText('name'), { target: { value: 'synthetic record' } });
  const work = deferred<object>(); mocks.encrypt.mockReturnValue(work.promise); fireEvent.click(screen.getByRole('button', { name: 'save' }));
  await waitFor(() => expect(mocks.encrypt).toHaveBeenCalled()); hideTab(); await act(async () => work.finish({}));
  expect(screen.queryByRole('dialog')).toBeNull(); expect(mocks.run).toHaveBeenCalledTimes(1);
});