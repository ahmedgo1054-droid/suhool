import { expect, it } from 'vitest';
import { encryptCompanySecret, decryptCompanySecret, rewrapCompanyKey } from '@/lib/company-vault-crypto';
import { emptyCompanySecret } from '@/lib/company-vault';

it('keeps company passwords encrypted with owner and record bound keys',async()=>{
  const secret={...emptyCompanySecret,password:'SyntheticCompanyQA!'};
  const kek=crypto.randomUUID();
  const cipher=await encryptCompanySecret(secret,kek,'alice','record1','v1');
  expect(JSON.stringify(cipher)).not.toContain(secret.password);
  expect((await decryptCompanySecret(cipher,kek,'alice','record1')).password).toBe(secret.password);
  await expect(decryptCompanySecret(cipher,kek,'bob','record1')).rejects.toThrow();
  await expect(decryptCompanySecret(cipher,kek,'alice','record2')).rejects.toThrow();
  await expect(decryptCompanySecret(cipher,crypto.randomUUID(),'alice','record1')).rejects.toThrow();
});
it('rewraps a company key without changing the encrypted password and rejects the retired key',async()=>{
  const old=crypto.randomUUID();const next=crypto.randomUUID();
  const cipher=await encryptCompanySecret({...emptyCompanySecret,password:'SyntheticRotateQA!'},old,'alice','record1','v1');
  const rotated=await rewrapCompanyKey(cipher,old,next,'alice','record1','v2');
  expect(rotated.envelope).toEqual(cipher.envelope);
  expect(rotated.key_version).toBe('v2');
  expect((await decryptCompanySecret(rotated,next,'alice','record1')).password).toBe('SyntheticRotateQA!');
  await expect(decryptCompanySecret(rotated,old,'alice','record1')).rejects.toThrow();
});