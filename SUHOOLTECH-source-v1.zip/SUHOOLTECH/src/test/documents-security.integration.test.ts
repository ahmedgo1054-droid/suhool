import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
const file=process.env['DOCS_QA_FILE'];
describe.skipIf(!file)('Documents real permissions and persistence',()=>{
 const qa=file?JSON.parse(readFileSync(file,'utf8')):{};
 const url=process.env['SUPABASE_URL']??''; const key=process.env['VITE_SUPABASE_PUBLISHABLE_KEY']??'';
 const id=qa.document_id;
 async function request(role:string,path:string,body?:unknown,method?:string){const session=role==='admin'?qa.admin:qa[role]?.session;return fetch(`${url}${path}`,{method:method??(body?'POST':'GET'),headers:{apikey:key,...(session?{Authorization:`Bearer ${session.access_token}`} : {}),'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});}
 const rpc=(role:string,action:string,data:unknown)=>request(role,'/rest/v1/rpc/docs_command',{_action:action,_data:data});
 let versionId='';let path='';
 it('outsider cannot read document metadata or invoke commands',async()=>{
  const r=await request('outsider',`/rest/v1/documents?id=eq.${id}`);expect(await r.json()).toEqual([]);
  expect((await rpc('outsider','edit',{id,title:'Unauthorized'})).ok).toBe(false);
 });
 it('reader can read but cannot edit, share or approve',async()=>{
  expect((await (await request('reader',`/rest/v1/documents?id=eq.${id}`)).json())[0].id).toBe(id);
  for(const action of ['edit','share','transition']) expect((await rpc('reader',action,{id,title:'Unauthorized',user_id:qa.outsider.id,role:'reader',next:'approved'})).ok).toBe(false);
 });
 it('editor updates real draft and cannot grant permissions',async()=>{
  expect((await rpc('editor','edit',{id,title:'QA edited document',description:'Persisted'})).ok).toBe(true);
  const r=await request('editor',`/rest/v1/documents?id=eq.${id}`);expect((await r.json())[0].description).toBe('Persisted');
  expect((await rpc('editor','share',{id,user_id:qa.outsider.id,role:'reader'})).ok).toBe(false);
 });
 it('requires an uploaded file before submission and verifies storage before finalization',async()=>{
  expect((await rpc('editor','transition',{id,next:'in_review'})).ok).toBe(false);
  const r=await rpc('editor','reserve',{id,file_name:'security.txt',size_bytes:11,mime_type:'text/plain'});expect(r.ok).toBe(true);const v=await r.json();versionId=v.id;path=v.path;
  expect((await rpc('editor','finalize',{id,version_id:versionId})).ok).toBe(false);
 });
 it('editor uploads and finalizes immutable file; reader reads exact content',async()=>{
  const r=await fetch(`${url}/storage/v1/object/documents/${path}`,{method:'POST',headers:{apikey:key,Authorization:`Bearer ${qa.editor.session.access_token}`,'Content-Type':'text/plain'},body:'HELLO SOOL!'});expect(r.ok).toBe(true);
  expect((await rpc('editor','finalize',{id,version_id:versionId})).ok).toBe(true);
  const read=await request('reader',`/storage/v1/object/authenticated/documents/${path}`);expect(read.ok).toBe(true);expect(await read.text()).toBe('HELLO SOOL!');
  const overwrite=await fetch(`${url}/storage/v1/object/documents/${path}`,{method:'PUT',headers:{apikey:key,Authorization:`Bearer ${qa.editor.session.access_token}`,'Content-Type':'text/plain'},body:'OVERWRITE!!'});expect(overwrite.ok).toBe(false);
 });
 it('outsiders cannot download files or obtain signed links',async()=>{
  expect((await request('outsider',`/storage/v1/object/authenticated/documents/${path}`)).ok).toBe(false);
  expect((await request('outsider',`/storage/v1/object/sign/documents/${path}`,{expiresIn:60})).ok).toBe(false);
 });
 it('reviewer cannot edit draft; editor submits; only reviewer approves',async()=>{
  expect((await rpc('reviewer','edit',{id,title:'Unauthorized'})).ok).toBe(false);
  expect((await rpc('editor','transition',{id,next:'in_review'})).ok).toBe(true);
  expect((await rpc('editor','transition',{id,next:'approved'})).ok).toBe(false);
  expect((await rpc('reviewer','transition',{id,next:'rejected',note:''})).ok).toBe(false);
  expect((await rpc('reviewer','transition',{id,next:'approved',note:'QA approved'})).ok).toBe(true);
  const rows=await (await request('reviewer',`/rest/v1/document_events?document_id=eq.${id}&to_status=eq.approved`)).json();expect(rows[0].actor_id).toBe(qa.reviewer.id);
 });
 it('approved content is locked against editors',async()=>expect((await rpc('editor','edit',{id,title:'Unauthorized'})).ok).toBe(false));
 it('revoking system membership removes existing document and file access',async()=>{
  expect((await rpc('admin','membership',{user_id:qa.reader.id,enabled:false})).ok).toBe(true);
  expect(await (await request('reader',`/rest/v1/documents?id=eq.${id}`)).json()).toEqual([]);
  const permission=await request('reader','/rest/v1/rpc/docs_can',{_id:id});expect(await permission.json()).toBe(false);
  expect((await request('reader',`/storage/v1/object/sign/documents/${path}`,{expiresIn:60})).ok).toBe(false);
  const fresh=await request('reader',`/storage/v1/object/authenticated/documents/${path}?verification=${crypto.randomUUID()}`);
  expect(fresh.ok).toBe(false);
  const prior=await request('reader',`/storage/v1/object/authenticated/documents/${path}`);
  console.info('Revoked file request diagnostics', {status:prior.status,cache:prior.headers.get('x-cache'),age:prior.headers.get('age'),cacheControl:prior.headers.get('cache-control'),freshStatus:fresh.status});
  expect(prior.ok).toBe(false);
 });
 it('anonymous metadata and file access is denied',async()=>{
  const r=await request('anonymous','/rest/v1/documents');if(r.ok)expect(await r.json()).toEqual([]);else expect(r.status).toBeGreaterThanOrEqual(400);
  expect((await request('anonymous',`/storage/v1/object/authenticated/documents/${path}`)).ok).toBe(false);
 });
});