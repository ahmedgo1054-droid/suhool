import { describe, expect, it } from "vitest";
import { decryptVaultValue, encryptVaultValue, generateRecoveryPassphrase, generateVaultKey, unwrapPersonalKey, wrapPersonalKey } from "@/lib/vault-crypto";

describe("Password Vault authenticated encryption", () => {
  it("round-trips Arabic secrets without storing plaintext in the envelope", async () => {
    const key = await generateVaultKey();
    const value = JSON.stringify({ password: "QA-only-secret", notes: "اختبار الخزنة" });
    const envelope = await encryptVaultValue(key, value, "record:owner:1");
    expect(JSON.stringify(envelope)).not.toContain("QA-only-secret");
    expect(await decryptVaultValue(key, envelope, "record:owner:1")).toBe(value);
  });
  it("generates a fresh 96-bit IV for each encryption", async () => {
    const key = await generateVaultKey();
    const first = await encryptVaultValue(key, "test", "record:1");
    const second = await encryptVaultValue(key, "test", "record:1");
    expect(atob(first.iv).length).toBe(12);
    expect(first.iv).not.toBe(second.iv);
    expect(first.ciphertext).not.toBe(second.ciphertext);
  });
  it("rejects another owner context and another encryption key", async () => {
    const key = await generateVaultKey();
    const envelope = await encryptVaultValue(key, "private", "owner:alice");
    await expect(decryptVaultValue(key, envelope, "owner:bob")).rejects.toThrow("VAULT_UNLOCK_FAILED");
    await expect(decryptVaultValue(await generateVaultKey(), envelope, "owner:alice")).rejects.toThrow("VAULT_UNLOCK_FAILED");
  });
  it("rejects tampered ciphertext without returning plaintext", async () => {
    const key = await generateVaultKey();
    const envelope = await encryptVaultValue(key, "private", "record:1");
    const bytes = atob(envelope.ciphertext);
    const altered = btoa(String.fromCharCode(bytes.charCodeAt(0) ^ 1) + bytes.slice(1));
    await expect(decryptVaultValue(key, { ...envelope, ciphertext: altered }, "record:1")).rejects.toThrow("VAULT_UNLOCK_FAILED");
  });
  it("allows only the owner passphrase to unwrap a personal key", async () => {
    const key = await generateVaultKey();
    const wrapped = await wrapPersonalKey(key, "qa-personal-passphrase", "alice");
    const value = await encryptVaultValue(key, "owner-only", "alice:record:1");
    const restored = await unwrapPersonalKey(wrapped, "qa-personal-passphrase", "alice");
    expect(await decryptVaultValue(restored, value, "alice:record:1")).toBe("owner-only");
    await expect(unwrapPersonalKey(wrapped, "wrong-passphrase", "alice")).rejects.toThrow("VAULT_UNLOCK_FAILED");
    await expect(unwrapPersonalKey(wrapped, "qa-personal-passphrase", "bob")).rejects.toThrow("VAULT_UNLOCK_FAILED");
  });
  it("restores the same personal key with a separate owner-held recovery phrase", async () => {
    const key = await generateVaultKey();
    const recovery = generateRecoveryPassphrase();
    expect(atob(recovery).length).toBe(32);
    const wrap = await wrapPersonalKey(key, recovery, "alice");
    const restored = await unwrapPersonalKey(wrap, recovery, "alice");
    const record = await encryptVaultValue(key, "recovered", "alice:1");
    expect(await decryptVaultValue(restored, record, "alice:1")).toBe("recovered");
  });
});