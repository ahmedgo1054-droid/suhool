import { describe, expect, it } from "vitest";
import { availableSystems, futureSystems, isSystemCode, type System, type SystemAccess } from "@/lib/systems";

const codes = ["tasks", "quotes", "hr", "docs", "admin_services"];
const systems: System[] = codes.map((code, i) => ({
  id: code, code, name_ar: code, name_en: code,
  status: "active", position: i,
  created_at: "2026-10-17", updated_at: "2026-10-17",
}));
const memberships = (ids: string[]): SystemAccess[] => ids.map((id) => ({
  id, system_id: id, user_id: "administrator", role: "admin",
  created_at: "2026-10-17", updated_at: "2026-10-17",
}));

describe("Portal system membership", () => {
  it("requires explicit membership for the sixth vault system", () => {
    const vault = { ...systems[0], id: 'vault', code: 'vault' } as System;
    expect(isSystemCode('vault')).toBe(true);
    expect(availableSystems([vault], memberships(codes))).toEqual([]);
    expect(availableSystems([vault], memberships(['vault']))).toEqual([vault]);
  });
  it("shows only permitted active systems", () => {
    expect(availableSystems(systems, memberships(["tasks"])).map((s) => s.code)).toEqual(["tasks"]);
    expect(availableSystems(systems, []).length).toBe(0);
  });
  it("gives the fully assigned administrator all five current systems", () => {
    expect(availableSystems(systems, memberships(codes)).map((s) => s.code)).toEqual(["tasks", "quotes", "hr", "docs", "admin_services"]);
  });
  it("keeps future systems out of entry cards even with permission", () => {
    const future = systems.map(s => s.code === "admin_services" ? { ...s, status: "coming_soon" } : s);
    expect(futureSystems(future).map((s) => s.code)).toEqual(["admin_services"]);
    expect(availableSystems(future, memberships(["admin_services"]))).toEqual([]);
  });
});