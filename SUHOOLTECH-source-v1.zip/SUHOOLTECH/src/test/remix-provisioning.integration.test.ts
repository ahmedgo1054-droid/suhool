import { createClient } from "@supabase/supabase-js";
import { expect, it } from "vitest";

const enabled = Boolean(process.env['SUPABASE_URL'] && process.env['SUPABASE_SERVICE_ROLE_KEY']);
it.skipIf(!enabled)("provisions the first admin and subsequent employee without trusting metadata roles", async () => {
  const url = process.env['SUPABASE_URL'];
  const key = process.env['SUPABASE_SERVICE_ROLE_KEY'];
  if (!url || !key) throw new Error("TEST_ACCESS_MISSING");
  const admin = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const before = await admin.from("user_roles").select("id", { count: "exact", head: true }).eq("role", "admin");
  if (before.error) throw new Error("TEST_ACCESS_FAILED");
  const ids: string[] = [];
  try {
    for (const expected of [before.count === 0 ? "admin" : "employee", "employee"]) {
      const created = await admin.auth.admin.createUser({
        email: `qa-remix-${crypto.randomUUID()}@example.com`,
        password: crypto.randomUUID() + "Aa9!", email_confirm: true,
        user_metadata: { full_name_ar: "اختبار مؤقت", full_name_en: "Temporary QA", role: "admin" },
      });
      if (created.error || !created.data.user) throw new Error("TEST_ACCOUNT_CREATE_FAILED");
      const id = created.data.user.id;
      ids.push(id);
      const profile = await admin.from("profiles").select("id,is_active").eq("id", id).single();
      expect(profile.error).toBeNull();
      expect(profile.data?.is_active).toBe(true);
      const roles = await admin.from("user_roles").select("role").eq("user_id", id);
      expect(roles.data?.map((r) => r.role)).toEqual([expected]);
    }
  } finally {
    for (const id of ids.reverse()) {
      const removed = await admin.auth.admin.deleteUser(id);
      if (removed.error) throw new Error("TEST_CLEANUP_FAILED");
    }
  }
}, 30_000);