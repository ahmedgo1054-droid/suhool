import { expect, it } from 'vitest';
import { encryptVaultValue, decryptVaultValue } from '@/lib/vault-crypto';

async function backupKey(secret: string) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(secret));
  return crypto.subtle.importKey('raw', digest, 'AES-GCM', false, ['encrypt', 'decrypt']);
}

it('encrypts the company KEK backup so only the backup key can restore it', async () => {
  const backupSecret = crypto.randomUUID();
  const payload = JSON.stringify({ v1: crypto.randomUUID(), v2: crypto.randomUUID() });
  const blob = await encryptVaultValue(await backupKey(backupSecret), payload, 'company-kek-backup:v1');
  expect(JSON.stringify(blob)).not.toContain(payload);
  expect(await decryptVaultValue(await backupKey(backupSecret), blob, 'company-kek-backup:v1')).toBe(payload);
  await expect(decryptVaultValue(await backupKey(crypto.randomUUID()), blob, 'company-kek-backup:v1')).rejects.toThrow();
  await expect(decryptVaultValue(await backupKey(backupSecret), blob, 'other-context')).rejects.toThrow();
});
