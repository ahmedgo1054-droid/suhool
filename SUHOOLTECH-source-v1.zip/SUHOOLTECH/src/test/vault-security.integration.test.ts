import { createClient } from "@supabase/supabase-js";
import { expect, it } from "vitest";

const enabled = Boolean(process.env['SUPABASE_URL'] && process.env['SUPABASE_SERVICE_ROLE_KEY'] && process.env['VITE_SUPABASE_PUBLISHABLE_KEY']);
it.skipIf(!enabled)("isolates personal ciphertext from other members and administrators and revokes access immediately", async () => {
  const url = process.env['SUPABASE_URL'];
  const key = process.env['SUPABASE_SERVICE_ROLE_KEY'];
  const publicKey = process.env['VITE_SUPABASE_PUBLISHABLE_KEY'];
  if (!url || !key || !publicKey) throw new Error("TEST_ACCESS_MISSING");
  const admin = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const ids: string[] = [];
  let systemId: string | undefined;
  let recordId: string | undefined;
  try {
    const sys = await admin.from("systems").select("id").eq("code", "vault").single();
    if (sys.error || !sys.data) throw new Error("TEST_SYSTEM_CREATE_FAILED");
    systemId = sys.data.id;
    const clients = [];
    for (let i = 0; i < 3; i++) {
      const email = `qa-vault-${crypto.randomUUID()}@example.com`;
      const password = crypto.randomUUID() + "Aa9!";
      const created = await admin.auth.admin.createUser({ email, password, email_confirm: true });
      if (created.error || !created.data.user) throw new Error("TEST_ACCOUNT_CREATE_FAILED");
      const id = created.data.user.id;
      ids.push(id);
      const membership = await admin.from("user_system_access").insert({ user_id: id, system_id: systemId, role: "employee" });
      if (membership.error) throw new Error("TEST_MEMBERSHIP_FAILED");
      const client = createClient(url, publicKey, { auth: { persistSession: false, autoRefreshToken: false } });
      const login = await client.auth.signInWithPassword({ email, password });
      if (login.error) throw new Error("TEST_LOGIN_FAILED");
      clients.push(client);
    }
    const [administrator, owner, outsider] = clients;
    const ownerId = ids[1];
    const administratorId = ids[0];
    if (!administrator || !owner || !outsider || !ownerId || !administratorId) throw new Error("TEST_FIXTURE_MISSING");
    expect((await owner.from("personal_vault_records").insert({ owner_id: ownerId, envelope: {} })).error).not.toBeNull();
    expect((await owner.rpc("personal_vault_command", { _action: "create", _data: { id: crypto.randomUUID(), envelope: {} } })).error?.message).toContain("VAULT_MFA_REQUIRED");
    const inserted = await admin.from("personal_vault_records").insert({ owner_id: ownerId, envelope: { version: 1, iv: "QA-ciphertext", ciphertext: "QA-encrypted-only" } }).select("id").single();
    expect(inserted.error).toBeNull();
    expect((await owner.from("personal_vault_records").select("id")).error).not.toBeNull();
    expect((await administrator.from("personal_vault_records").select("id")).error).not.toBeNull();
    expect((await outsider.from("personal_vault_records").select("id")).error).not.toBeNull();
    const forged = await administrator.from("personal_vault_records").insert({ owner_id: ownerId, envelope: {} });
    expect(forged.error).not.toBeNull();
    const record = await admin.from("vault_records").insert({ owner_id: ownerId, name: "QA company record" }).select("id").single();
    if (!record.data || record.error) throw new Error("TEST_RECORD_CREATE_FAILED");
    recordId = record.data.id;
    await admin.from("vault_record_grants").insert({ record_id: recordId, user_id: administratorId, can_view: true });
    expect((await administrator.rpc("vault_can", { _record: recordId, _permission: "view" })).data).toBe(true);
    expect((await administrator.rpc("vault_can", { _record: recordId, _permission: "reveal" })).data).toBe(false);
    expect((await administrator.rpc("vault_can", { _record: recordId, _permission: "sensitive_print" })).data).toBe(false);
    expect((await administrator.from("vault_ciphertexts").select("*")).error).not.toBeNull();
    expect((await administrator.from("vault_record_grants").update({ can_reveal: true }).eq("record_id", recordId)).error).not.toBeNull();
    await admin.from("user_system_access").delete().eq("user_id", ownerId).eq("system_id", systemId);
    expect((await owner.from("personal_vault_records").select("id")).error).not.toBeNull();
    expect((await owner.rpc('personal_vault_status')).error?.message).toContain('VAULT_DENIED');
    await admin.from("profiles").update({ is_active: false }).eq("id", administratorId);
    expect((await administrator.rpc("vault_can", { _record: recordId, _permission: "view" })).data).toBe(false);
  } finally {
    if (recordId) await admin.from("vault_records").delete().eq("id", recordId);
    for (const id of ids) {
      await admin.from("personal_vault_records").delete().eq("owner_id", id);
      await admin.from("personal_vault_keys").delete().eq("owner_id", id);
      await admin.from("user_system_access").delete().eq("user_id", id);
      const removed = await admin.auth.admin.deleteUser(id);
      if (removed.error) throw new Error("TEST_CLEANUP_FAILED");
    }
  }
}, 30_000);