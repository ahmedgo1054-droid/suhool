import {describe,it,expect} from 'vitest';
import {readFileSync} from 'node:fs';
const enabled=!!process.env['HR_QA_FILE'];
describe.skipIf(!enabled)('HR real RLS and SQL rules',()=>{
 const qa=enabled?JSON.parse(readFileSync(process.env['HR_QA_FILE']??'','utf8')):{};
 const admin=enabled?JSON.parse(readFileSync(process.env['HR_ADMIN_FILE']??'','utf8')).session:{};
 const url=process.env['SUPABASE_URL']??'';const key=process.env['VITE_SUPABASE_PUBLISHABLE_KEY']??process.env['VITE_SUPABASE_ANON_KEY']??'';
 async function request(session:any,path:string,body?:unknown){return fetch(`${url}/rest/v1/${path}`,{method:body?'POST':'GET',headers:{apikey:key,Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});}
 const rpc=(s:any,a:string,d:unknown)=>request(s,'rpc/hr_command',{_action:a,_data:d});
 it('allows admin salary update but denies employee and manager salary reads',async()=>{
  expect((await rpc(admin,'finance',{id:qa.employee.id,salary:12345,allowances:500})).ok).toBe(true);
  for(const r of ['employee','manager'])expect(await (await request(qa[r].session,'hr_finances?select=*')).json()).toEqual([]);
  const data=await (await request(admin,`hr_finances?id=eq.${qa.employee.id}`)).json();expect(data[0].salary).toBe(12345);
 });
 it('employee cannot manage employee files through direct RPC',async()=>expect((await rpc(qa.employee.session,'employee',{id:qa.employee.id})).ok).toBe(false));
 it('manager cannot write financial data',async()=>expect((await rpc(qa.manager.session,'finance',{id:qa.employee.id,salary:1,allowances:0})).ok).toBe(false));
 it('denies salary values in financial audit records to manager',async()=>expect(await (await request(qa.manager.session,'hr_audit_logs?entity=eq.hr_finances')).json()).toEqual([]));
 it('rejects overlapping leave',async()=>{
  const r=await rpc(qa.employee.session,'leave_save',{type_id:qa.type_id,start_date:'2026-11-02',end_date:'2026-11-04',reason:'QA overlap'});expect(r.ok).toBe(false);expect((await r.json()).message).toContain('HR_OVERLAP');
 });
 it('rejects reverse leave dates',async()=>expect((await rpc(qa.employee.session,'leave_save',{type_id:qa.type_id,start_date:'2026-12-03',end_date:'2026-12-01',reason:'QA reverse'})).ok).toBe(false));
 it('rejects approval without an allocated balance',async()=>{
  const existing=await (await request(qa.employee.session,`hr_leaves?employee_id=eq.${qa.employee.id}&start_date=eq.2027-01-01`)).json();
  let l=existing[0];if(!l){const r=await rpc(qa.employee.session,'leave_save',{type_id:qa.type_id,start_date:'2027-01-01',end_date:'2027-01-02',reason:'QA unallocated'});l=await r.json();expect(r.ok).toBe(true);expect((await rpc(qa.employee.session,'leave_transition',{id:l.id,next:'pending'})).ok).toBe(true);}
  const approval=await rpc(qa.manager.session,'leave_transition',{id:l.id,next:'approved'});expect(approval.ok).toBe(false);expect((await approval.json()).message).toContain('HR_BALANCE_REQUIRED');
 });
 it('employee cannot correct attendance',async()=>expect((await rpc(qa.employee.session,'attendance',{employee_id:qa.employee.id,work_date:'2026-10-15',status:'absent',reason:'QA'})).ok).toBe(false));
 it('requires correction reason for authorized admin',async()=>expect((await rpc(admin,'attendance',{employee_id:qa.employee.id,work_date:'2026-10-15',status:'absent',reason:''})).ok).toBe(false));
 it('records past configured workday absence and its audit',async()=>{
  expect((await rpc(admin,'attendance',{employee_id:qa.employee.id,work_date:'2026-10-15',status:'absent',reason:'QA absence'})).ok).toBe(true);
  const records=await (await request(admin,`hr_attendance?employee_id=eq.${qa.employee.id}&work_date=eq.2026-10-15`)).json();expect(records[0].status).toBe('absent');
  const audit=await (await request(admin,'hr_audit_logs?entity=eq.hr_attendance')).json();expect(audit.some((a:any)=>a.diff?.new?.correction_reason==='QA absence')).toBe(true);
 });
 it('rejects checkout earlier than checkin',async()=>expect((await rpc(admin,'attendance',{employee_id:qa.employee.id,work_date:'2026-10-15',check_in:'2026-10-15T08:00:00+03:00',check_out:'2026-10-15T07:00:00+03:00',status:'present',reason:'QA invalid'})).ok).toBe(false));
 it('rejects duplicate checkout',async()=>expect((await rpc(qa.employee.session,'check_out',{})).ok).toBe(false));
 it('separates financial access from employee administration and leave approval',async()=>{
  expect((await rpc(admin,'permissions',{id:qa.manager.id,view_salary:true,manage_employees:false,approve_leaves:false,correct_attendance:false})).ok).toBe(true);
  const salary=await (await request(qa.manager.session,`hr_finances?id=eq.${qa.employee.id}`)).json();expect(salary[0].salary).toBe(12345);
  const can=await request(qa.manager.session,'rpc/hr_can',{_permission:'manage_employees'});expect(await can.json()).toBe(false);
  expect((await rpc(qa.manager.session,'employee',{id:qa.employee.id})).ok).toBe(false);
  expect((await rpc(admin,'permissions',{id:qa.manager.id,view_salary:false,manage_employees:true,approve_leaves:true,correct_attendance:false})).ok).toBe(true);
 });
 it('rejects unauthenticated HR reads',async()=>{
  const r=await fetch(`${url}/rest/v1/hr_employees`,{headers:{apikey:key}});if(r.ok) expect(await r.json()).toEqual([]); else expect(r.status).toBeGreaterThanOrEqual(400);
 });
});
