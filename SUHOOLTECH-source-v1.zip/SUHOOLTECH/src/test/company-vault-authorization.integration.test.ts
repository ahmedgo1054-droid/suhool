import { createClient } from '@supabase/supabase-js';
import { expect,it } from 'vitest';
import { emptyCompanySecret } from '@/lib/company-vault';
import { encryptCompanySecret } from '@/lib/company-vault-crypto';

const enabled=Boolean(process.env['SUPABASE_URL']&&process.env['SUPABASE_SERVICE_ROLE_KEY']&&process.env['VITE_SUPABASE_PUBLISHABLE_KEY']);
it.skipIf(!enabled)('company commands enforce independent grants, single-use scope, expiry and revocation without logging plaintext',async()=>{
  const url=process.env['SUPABASE_URL'];const key=process.env['SUPABASE_SERVICE_ROLE_KEY'];const pub=process.env['VITE_SUPABASE_PUBLISHABLE_KEY'];if(!url||!key||!pub)throw new Error('TEST_ACCESS_MISSING');
  const admin=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});const ids:string[]=[];const clients=[];const record=crypto.randomUUID();
  try{
    const sys=await admin.from('systems').select('id').eq('code','vault').single();if(!sys.data)throw new Error('TEST_SYSTEM_MISSING');
    for(let i=0;i<2;i++){const email=`qa-company-${crypto.randomUUID()}@example.com`;const password=crypto.randomUUID()+'Aa9!';const user=await admin.auth.admin.createUser({email,password,email_confirm:true});if(!user.data.user)throw new Error('TEST_ACCOUNT_FAILED');ids.push(user.data.user.id);await admin.from('user_system_access').insert({user_id:user.data.user.id,system_id:sys.data.id,role:'admin'});const c=createClient(url,pub,{auth:{persistSession:false,autoRefreshToken:false}});await c.auth.signInWithPassword({email,password});clients.push(c);}
    const owner=ids[0];const outsider=ids[1];const ownerClient=clients[0];const client=clients[1];if(!owner||!outsider||!ownerClient||!client)throw new Error('TEST_FIXTURE_FAILED');
    expect((await client.rpc('company_vault_sharing_candidates')).data).toEqual([]);
    const encrypted=await encryptCompanySecret({...emptyCompanySecret,password:'SyntheticSecretNeverInAudit!'},crypto.randomUUID(),owner,record,'v1');
    async function command(actor:string,action:string,payload:object={},scope=record,expired=false){const token=crypto.randomUUID();await admin.from('company_vault_authorizations').insert({token,actor_id:actor,record_id:scope,action,...(expired?{expires_at:'2020-01-01T00:00:00Z'}:{})});const r=await admin.rpc('company_vault_command',{_actor:actor,_action:action,_id:record,_token:token,_data:payload});return {r,token};}
    expect((await command(owner,'create',{metadata:{name:'Synthetic QA record'},...encrypted})).r.error).toBeNull();
    const candidates=await ownerClient.rpc('company_vault_sharing_candidates');expect(candidates.error).toBeNull();expect(candidates.data?.some((p:{id:string})=>p.id===outsider)).toBe(true);
    expect((await command(outsider,'reveal')).r.error?.message).toContain('VAULT_DENIED');
    expect((await client.rpc('company_vault_command',{_actor:owner,_action:'reveal',_id:record,_token:crypto.randomUUID()})).error).not.toBeNull();
    expect((await client.from('company_vault_authorizations').insert({token:crypto.randomUUID(),actor_id:outsider,record_id:record,action:'reveal'})).error).not.toBeNull();
    const grant={user_id:outsider,can_view:true,can_reveal:false,can_edit:true,can_delete:false,can_sensitive_print:true,can_manage_grants:false};
    expect((await command(owner,'grant',{revision:1,grant})).r.error).toBeNull();
    const grantAudit=await admin.from('vault_audit_events').select('details').eq('record_id',record).eq('action','grant').single();expect(grantAudit.data?.details).toMatchObject({target_user_id:outsider,permissions:{can_reveal:false,can_sensitive_print:true}});
    await admin.from('user_system_access').delete().eq('user_id',outsider);
    expect((await ownerClient.rpc('company_vault_sharing_candidates')).data?.some((p:{id:string})=>p.id===outsider)).toBe(true);
    await admin.from('user_system_access').insert({user_id:outsider,system_id:sys.data.id,role:'admin'});
    expect((await client.from('vault_records').select('id')).data?.length).toBe(1);
    expect((await command(outsider,'reveal')).r.error?.message).toContain('VAULT_DENIED');
    expect((await command(outsider,'sensitive_print')).r.error?.message).toContain('VAULT_DENIED');
    expect((await client.rpc('company_vault_sharing_candidates')).data).toEqual([]);
    expect((await command(outsider,'delete',{revision:2})).r.error?.message).toContain('VAULT_DENIED');
    expect((await command(owner,'reveal',{},crypto.randomUUID())).r.error?.message).toContain('VAULT_FRESH_VERIFICATION_REQUIRED');
    expect((await command(owner,'reveal',{},record,true)).r.error?.message).toContain('VAULT_FRESH_VERIFICATION_REQUIRED');
    const read=await command(owner,'reveal');expect(read.r.error).toBeNull();
    expect((await admin.rpc('company_vault_command',{_actor:owner,_action:'reveal',_id:record,_token:read.token,_data:{}})).error?.message).toContain('VAULT_FRESH_VERIFICATION_REQUIRED');
    expect((await command(owner,'edit',{revision:1})).r.error?.message).toContain('VAULT_CONFLICT');
    expect((await command(owner,'revoke',{revision:2,grant})).r.error).toBeNull();
    expect((await client.from('vault_records').select('id')).data).toEqual([]);
    expect((await command(outsider,'edit',{revision:3})).r.error?.message).toContain('VAULT_DENIED');
    const audit=await admin.from('vault_audit_events').select('*').eq('record_id',record);expect(audit.data?.some(e=>e.action==='reveal')).toBe(true);expect(JSON.stringify(audit.data)).not.toContain('SyntheticSecretNeverInAudit');
    const count=audit.data?.filter(e=>e.action==='edit').length;
    expect((await command(owner,'edit',{revision:3})).r.error).toBeNull();
    expect((await admin.from('vault_audit_events').select('id').eq('record_id',record).eq('action','edit')).data?.length).toBe(count);
    expect((await command(owner,'delete',{revision:3})).r.error).toBeNull();
    const deleted=await admin.from('vault_audit_events').select('record_id,record_reference').eq('record_reference',record).eq('action','delete').single();expect(deleted.data).toEqual({record_id:null,record_reference:record});
  }finally{
    await admin.from('vault_audit_events').delete().eq('record_reference',record);await admin.from('vault_records').delete().eq('id',record);
    for(const id of ids){await admin.from('company_vault_authorizations').delete().eq('actor_id',id);await admin.from('user_system_access').delete().eq('user_id',id);await admin.auth.admin.deleteUser(id);}
  }
},30000);