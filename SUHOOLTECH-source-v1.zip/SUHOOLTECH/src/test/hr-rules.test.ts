import { describe,it,expect } from 'vitest';
import { leaveDays,remainingBalance } from '@/lib/hr-rules';
describe('Explicit HR calendar-day policy',()=>{
 it('counts both leave dates',()=>expect(leaveDays('2026-10-17','2026-10-19')).toBe(3));
 it('counts same-day leave as one day',()=>expect(leaveDays('2026-10-17','2026-10-17')).toBe(1));
 it('rejects reversed leave dates',()=>expect(()=>leaveDays('2026-10-19','2026-10-17')).toThrow());
 it('uses only the management allocation minus approved leave',()=>expect(remainingBalance(12,3)).toBe(9));
});
