import { describe, expect, it } from "vitest";
import { validateSystemAccess } from "@/lib/system-access-rules";
const userId = "00000000-0000-0000-0000-000000000001";
const systemId = "00000000-0000-0000-0000-000000000002";
describe("System access commands", () => {
  it("supports granting and changing all four system roles", () => {
    for (const role of ["admin", "manager", "sales", "employee"] as const) {
      expect(validateSystemAccess({ userId, systemId, role })).toEqual({ userId, systemId, role });
    }
  });
  it("supports revocation without a role", () => {
    expect(validateSystemAccess({ userId, systemId, role: null }).role).toBeNull();
  });
  it("rejects invented roles", () => {
    expect(() => validateSystemAccess({ userId, systemId, role: "superadmin" as "admin" })).toThrow("ACCESS_INVALID");
  });
  it("rejects missing or invalid users and systems", () => {
    expect(() => validateSystemAccess({ userId: "", systemId, role: "employee" })).toThrow();
    expect(() => validateSystemAccess({ userId, systemId: "tasks", role: "employee" })).toThrow();
  });
});