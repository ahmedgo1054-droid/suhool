import { describe, expect, it, vi } from "vitest";
vi.mock("@tanstack/react-start", () => ({ createServerFn: () => {
  const builder = { middleware: () => builder, inputValidator: () => builder, handler: (fn: unknown) => fn };
  return builder;
} }));
vi.mock("@/integrations/supabase/auth-middleware", () => ({ requireSupabaseAuth: {} }));
import { getSystemAccess, setSystemAccess } from "@/lib/system-access.functions";
const runRead = getSystemAccess as unknown as (args: unknown) => Promise<unknown>;
const runWrite = setSystemAccess as unknown as (args: unknown) => Promise<unknown>;
function context(admin: boolean, active: boolean) {
  const from = vi.fn();
  return { userId: "actor", supabase: { from, rpc: vi.fn(async (name: string) => ({ data: name === "has_role" ? admin : active, error: null })) } };
}
describe("Administrator system-access boundary", () => {
  it("denies non-administrator reads before any user data is queried", async () => {
    const ctx = context(false, true);
    await expect(runRead({ context: ctx })).rejects.toThrow("ACCESS_DENIED");
    expect(ctx.supabase.from).not.toHaveBeenCalled();
  });
  it("denies grants and revocation by non-administrators", async () => {
    for (const role of ["admin", null]) {
      const ctx = context(false, true);
      await expect(runWrite({ context: ctx, data: { userId: "target", systemId: "system", role } })).rejects.toThrow("ACCESS_DENIED");
      expect(ctx.supabase.from).not.toHaveBeenCalled();
    }
  });
  it("denies suspended administrators", async () => {
    const ctx = context(true, false);
    await expect(runRead({ context: ctx })).rejects.toThrow("ACCESS_DENIED");
    await expect(runWrite({ context: ctx, data: { role: "employee" } })).rejects.toThrow("ACCESS_DENIED");
    expect(ctx.supabase.from).not.toHaveBeenCalled();
  });
});