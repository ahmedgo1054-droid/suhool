import { describe, expect, it } from 'vitest';
import { generateStrongPassword, personalContext, PERSONAL_IDLE_MS } from '@/lib/personal-vault';
import { encryptVaultValue, decryptVaultValue, generateVaultKey } from '@/lib/vault-crypto';

describe('Personal vault rules', () => {
  it('generates a 24-character password with all four character classes', () => {
    const value = generateStrongPassword();
    expect(value).toHaveLength(24);
    expect(value).toMatch(/[A-Z]/); expect(value).toMatch(/[a-z]/); expect(value).toMatch(/[0-9]/); expect(value).toMatch(/[!@#$%&*\-_+=]/);
    expect(() => generateStrongPassword(8)).toThrow();
  });
  it('binds personal ciphertext to both owner and record', async () => {
    const key = await generateVaultKey();
    const envelope = await encryptVaultValue(key, 'synthetic QA secret', personalContext('owner-a','record-a'));
    await expect(decryptVaultValue(key, envelope, personalContext('owner-b','record-a'))).rejects.toThrow();
    await expect(decryptVaultValue(key, envelope, personalContext('owner-a','record-b'))).rejects.toThrow();
  });
  it('uses a five-minute inactivity lock', () => { expect(PERSONAL_IDLE_MS).toBe(300000); });
});