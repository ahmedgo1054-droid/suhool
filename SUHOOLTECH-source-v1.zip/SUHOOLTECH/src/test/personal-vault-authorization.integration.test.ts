import { createClient } from '@supabase/supabase-js';
import { createHmac } from 'node:crypto';
import { expect, it } from 'vitest';

function totp(secret: string) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const bits = [...secret.replace(/=/g,'')].map(c => alphabet.indexOf(c).toString(2).padStart(5,'0')).join('');
  const bytes = Buffer.from(bits.match(/.{8}/g)?.map(b=>parseInt(b,2)) ?? []);
  const counter = Buffer.alloc(8); counter.writeBigUInt64BE(BigInt(Math.floor(Date.now()/30000)));
  const hash = createHmac('sha1',bytes).update(counter).digest(); const offset = (hash.at(-1) ?? 0) & 15;
  return ((hash.readUInt32BE(offset)&0x7fffffff)%1000000).toString().padStart(6,'0');
}
const enabled = Boolean(process.env['SUPABASE_URL'] && process.env['SUPABASE_SERVICE_ROLE_KEY'] && process.env['VITE_SUPABASE_PUBLISHABLE_KEY']);
it.skipIf(!enabled)('requires fresh record-bound single-use capabilities even with MFA', async () => {
  const url=process.env['SUPABASE_URL']; const service=process.env['SUPABASE_SERVICE_ROLE_KEY']; const publishable=process.env['VITE_SUPABASE_PUBLISHABLE_KEY'];
  if (!url||!service||!publishable) throw new Error('TEST_ACCESS_MISSING');
  const admin=createClient(url,service,{auth:{persistSession:false,autoRefreshToken:false}});
  const client=createClient(url,publishable,{auth:{persistSession:false,autoRefreshToken:false}});
  const email=`qa-vault-cap-${crypto.randomUUID()}@example.com`; const password=crypto.randomUUID()+'Aa9!';
  const created=await admin.auth.admin.createUser({email,password,email_confirm:true}); const id=created.data.user?.id;
  if (!id) throw new Error('TEST_ACCOUNT_FAILED');
  try {
    const sys=await admin.from('systems').select('id').eq('code','vault').single(); if(!sys.data) throw new Error('TEST_SYSTEM_FAILED');
    await admin.from('user_system_access').insert({user_id:id,system_id:sys.data.id,role:'employee'});
    await client.auth.signInWithPassword({email,password});
    const factor=await client.auth.mfa.enroll({factorType:'totp'}); if(!factor.data) throw new Error('TEST_MFA_FAILED');
    const verified=await client.auth.mfa.challengeAndVerify({factorId:factor.data.id,code:totp(factor.data.totp.secret)}); expect(verified.error).toBeNull();
    const recordId=crypto.randomUUID(); const envelope={version:1,iv:'abcdefghijklmnop',ciphertext:'SyntheticEncryptedQAFixture=='};
    const noProof=await client.rpc('personal_vault_command',{_action:'create',_data:{id:recordId,envelope}});
    expect(noProof.error?.message).toContain('VAULT_FRESH_VERIFICATION_REQUIRED');
    const token=crypto.randomUUID(); await admin.from('personal_vault_authorizations').insert({token,owner_id:id,action:'create',record_id:recordId});
    const wrongRecord=await client.rpc('personal_vault_command',{_action:'create',_data:{id:crypto.randomUUID(),envelope,authorization:token}});
    expect(wrongRecord.error?.message).toContain('VAULT_FRESH_VERIFICATION_REQUIRED');
    const valid=await client.rpc('personal_vault_command',{_action:'create',_data:{id:recordId,envelope,authorization:token,owner_id:crypto.randomUUID()}}); expect(valid.error).toBeNull();
    expect((valid.data as { records: {owner_id:string}[] }).records[0]?.owner_id).toBe(id);
    expect((await client.from('personal_vault_records').select('*')).error).not.toBeNull();
    expect((await client.from('personal_vault_keys').select('*')).error).not.toBeNull();
    const status=await client.rpc('personal_vault_status'); expect(status.data).toEqual({has_key:false,revision:null});
    const unverifiedRead=await client.rpc('personal_vault_command',{_action:'unlock',_data:{}});
    expect(unverifiedRead.error?.message).toContain('VAULT_FRESH_VERIFICATION_REQUIRED');
    const replay=await client.rpc('personal_vault_command',{_action:'create',_data:{id:recordId,envelope,authorization:token}});
    expect(replay.error?.message).toContain('VAULT_FRESH_VERIFICATION_REQUIRED');
    const audit=await client.from('personal_vault_events').select('*').eq('owner_id',id);
    expect(audit.data?.map(r=>r.action)).toEqual(['create']); expect(JSON.stringify(audit.data)).not.toContain('SyntheticEncrypted');
    const forged=await client.from('personal_vault_authorizations').insert({token:crypto.randomUUID(),owner_id:id,action:'unlock'}); expect(forged.error).not.toBeNull();
  } finally {
    await admin.from('personal_vault_authorizations').delete().eq('owner_id',id);
    await admin.from('personal_vault_events').delete().eq('owner_id',id);
    await admin.from('personal_vault_records').delete().eq('owner_id',id);
    await admin.from('user_system_access').delete().eq('user_id',id);
    await admin.auth.admin.deleteUser(id);
  }
},30000);