import { createFileRoute } from '@tanstack/react-router';
import { Assets } from '@/components/admin-ops';
import { adminOpsQuery } from '@/lib/admin-ops';
import { pageHead } from '@/lib/seo';
export const Route=createFileRoute('/_authenticated/admin-services/assets')({head:()=>pageHead('Asset custody','SUHOOLTECH asset register, employee custody and audited assignment and return.'),loader:({context})=>context.queryClient.ensureQueryData(adminOpsQuery),component:Assets});
