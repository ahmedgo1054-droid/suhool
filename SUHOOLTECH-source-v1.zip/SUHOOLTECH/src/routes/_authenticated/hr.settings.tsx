import { createFileRoute } from '@tanstack/react-router';
import { HrPage } from '@/components/hr/hr-page';
import { hrQuery } from '@/lib/hr';
import { pageHead } from '@/lib/seo';
export const Route = createFileRoute('/_authenticated/hr/settings')({
 head:()=>pageHead('HR policy and permissions', 'SUHOOLTECH HR permissions, work schedule, leave types and explicit balance allocation.'),
 loader:({context})=>context.queryClient.ensureQueryData(hrQuery),
 component:()=> <HrPage mode="settings"/>,
});
