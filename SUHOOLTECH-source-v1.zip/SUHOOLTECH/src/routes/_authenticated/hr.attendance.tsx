import { createFileRoute } from '@tanstack/react-router';
import { HrPage } from '@/components/hr/hr-page';
import { hrQuery } from '@/lib/hr';
import { pageHead } from '@/lib/seo';
export const Route = createFileRoute('/_authenticated/hr/attendance')({
 head:()=>pageHead('HR attendance', 'SUHOOLTECH attendance records, company schedule and authorized correction history.'),
 loader:({context})=>context.queryClient.ensureQueryData(hrQuery),
 component:()=> <HrPage mode="attendance"/>,
});
