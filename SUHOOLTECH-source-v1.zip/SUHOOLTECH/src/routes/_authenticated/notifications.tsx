import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { EmptyState, ErrorBox, Loading, PageHeader } from "@/components/page";
import { supabase } from "@/integrations/supabase/client";
import { must } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => pageHead("Notifications", "Your task and quotation notifications."),
  component: Notifications,
});

function Notifications() {
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["notifications"],
    queryFn: async () => must(await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(200)),
  });
  const refresh = () => { qc.invalidateQueries({ queryKey: ["notifications"] }); qc.invalidateQueries({ queryKey: ["unread"] }); };
  async function markAll() {
    await supabase.from("notifications").update({ read_at: new Date().toISOString() }).is("read_at", null);
    refresh();
  }
  async function markOne(id: string) {
    await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("id", id);
    refresh();
  }
  const rows = q.data ?? [];
  return (
    <div>
      <PageHeader title="notifications">
        <Button variant="outline" onClick={markAll} disabled={!rows.some((n) => !n.read_at)}>{t("mark_all_read")}</Button>
      </PageHeader>
      <Card className="divide-y">
        {q.isLoading ? <Loading /> : q.error ? <div className="p-4"><ErrorBox error={q.error} /></div> : !rows.length ? <EmptyState /> : rows.map((n) => (
          <div key={n.id} className={cn("flex items-start gap-3 p-4", !n.read_at && "bg-accent/40")}>
            <span className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", n.read_at ? "bg-transparent" : "bg-accent-brand")} />
            <div className="min-w-0 flex-1">
              <p className="font-medium">{lang === "ar" ? n.title_ar : n.title_en}</p>
              <p className="text-sm text-muted-foreground">{lang === "ar" ? n.body_ar : n.body_en}</p>
              <p className="mt-1 text-xs text-muted-foreground">{new Date(n.created_at).toLocaleString(lang === "ar" ? "ar-SA-u-ca-gregory" : "en-GB")}</p>
            </div>
            {n.link && <Button size="sm" variant="ghost" asChild onClick={() => markOne(n.id)}><Link to={n.link}>{t("open")}</Link></Button>}
          </div>
        ))}
      </Card>
    </div>
  );
}
