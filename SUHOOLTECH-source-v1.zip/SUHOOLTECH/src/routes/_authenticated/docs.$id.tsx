import { createFileRoute } from '@tanstack/react-router';
import { DocumentDetail } from '@/components/documents';
import { documentsQuery, documentQuery } from '@/lib/documents';
import { pageHead } from '@/lib/seo';
export const Route = createFileRoute('/_authenticated/docs/$id')({
  head: () => pageHead('ملف المستند', 'SUHOOLTECH document files, version history, permissions and review status.'),
  loader: ({ context, params }) => Promise.all([context.queryClient.ensureQueryData(documentsQuery),context.queryClient.ensureQueryData(documentQuery(params.id))]),
  component: () => <DocumentDetail id={Route.useParams().id} />,
});