import { createFileRoute } from '@tanstack/react-router';
import { Purchases } from '@/components/admin-ops';
import { adminOpsQuery } from '@/lib/admin-ops';
import { pageHead } from '@/lib/seo';
export const Route=createFileRoute('/_authenticated/admin-services/purchases')({head:()=>pageHead('Purchasing','SUHOOLTECH purchase requests, protected approvals, purchase orders and receipts.'),loader:({context})=>context.queryClient.ensureQueryData(adminOpsQuery),component:Purchases});
