import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { TableCell, TableRow } from "@/components/ui/table";
import { DataTable, Field, FilterChips, NativeSelect, PageHeader, StatusBadge } from "@/components/page";
import { supabase } from "@/integrations/supabase/client";
import { fmtDate, must, personName, PRIORITIES, useDepartments, useMe, useProfiles, type TaskPriority, type TaskStatus } from "@/lib/data";
import { useI18n, type TKey } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/tasks/")({
  head: () => pageHead("Tasks", "Create, assign, transfer and review tasks."),
  validateSearch: (s: Record<string, unknown>): { q?: string } => (typeof s["q"] === "string" ? { q: s["q"] } : {}),
  component: TasksPage,
});

type Filter = "mine" | "created" | TaskStatus;
const FILTERS: Filter[] = ["mine", "created", "ASSIGNED", "IN_PROGRESS", "PENDING_REVIEW", "RETURNED", "APPROVED"];

function TasksPage() {
  const { t, lang } = useI18n();
  const { q } = Route.useSearch();
  const { data: me } = useMe();
  const [filter, setFilter] = useState<Filter | "all">("all");
  const [open, setOpen] = useState(false);
  const tasks = useQuery({
    queryKey: ["tasks"],
    queryFn: async () => must(await supabase.from("tasks").select("*").order("created_at", { ascending: false })),
  });
  const { data: profiles = [] } = useProfiles();
  const byId = new Map(profiles.map((p) => [p.id, p]));
  const today = new Date().toISOString().slice(0, 10);

  const rows = (tasks.data ?? []).filter((r) => {
    if (q && !`${r.task_no} ${r.title}`.toLowerCase().includes(q.toLowerCase())) return false;
    if (filter === "all") return true;
    if (filter === "mine") return r.assignee_id === me?.user.id;
    if (filter === "created") return r.created_by === me?.user.id;
    return r.status === filter;
  });

  return (
    <div>
      <PageHeader title="tasks" action="new_task" onAction={() => setOpen(true)} />
      <FilterChips items={FILTERS} value={filter} onChange={setFilter}
        label={(f) => (f === "mine" ? t("my_tasks") : f === "created" ? t("created_by_me") : t(`s_${f}` as TKey))} />
      <DataTable columns={["number", "title", "assignee", "priority", "status", "due"]} loading={tasks.isLoading} error={tasks.error} empty={!rows.length}>
        {rows.map((r) => (
          <TableRow key={r.id}>
            <TableCell className="font-mono text-xs">T-{r.task_no}</TableCell>
            <TableCell className="max-w-xs truncate font-medium">
              <Link to="/tasks/$id" params={{ id: r.id }} className="text-primary hover:underline">{r.title}</Link>
            </TableCell>
            <TableCell>{personName(r.assignee_id ? byId.get(r.assignee_id) : null, lang)}</TableCell>
            <TableCell>{t(`p_${r.priority}` as TKey)}</TableCell>
            <TableCell><StatusBadge status={r.status} kind="task" /></TableCell>
            <TableCell className={r.due_date && r.due_date < today && !["APPROVED", "CANCELLED"].includes(r.status) ? "text-destructive" : ""}>
              {fmtDate(r.due_date, lang)}
            </TableCell>
          </TableRow>
        ))}
      </DataTable>
      <NewTaskDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}

function NewTaskDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { data: profiles = [] } = useProfiles();
  const { data: departments = [] } = useDepartments();
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({ title: "", description: "", priority: "MEDIUM" as TaskPriority, assignee: "", department: "", due: "" });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!f.title.trim()) return;
    setBusy(true);
    const { data, error } = await supabase.rpc("task_create", {
      _title: f.title.trim().slice(0, 200), _description: f.description.slice(0, 5000), _priority: f.priority,
      _assignee: (f.assignee || null) as string, _department: (f.department || null) as string, _due: (f.due || null) as string,
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success(t("saved"));
    qc.invalidateQueries({ queryKey: ["tasks"] });
    onOpenChange(false);
    setF({ title: "", description: "", priority: "MEDIUM", assignee: "", department: "", due: "" });
    navigate({ to: "/tasks/$id", params: { id: data as string } });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader><DialogTitle>{t("new_task")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="title" className="sm:col-span-2"><Input required maxLength={200} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
          <Field label="description" className="sm:col-span-2"><Textarea rows={4} maxLength={5000} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
          <Field label="assignee">
            <NativeSelect value={f.assignee} onChange={(e) => setF({ ...f, assignee: e.target.value })}>
              <option value="">—</option>
              {profiles.filter((p) => p.is_active).map((p) => <option key={p.id} value={p.id}>{personName(p, lang)}</option>)}
            </NativeSelect>
          </Field>
          <Field label="department">
            <NativeSelect value={f.department} onChange={(e) => setF({ ...f, department: e.target.value })}>
              <option value="">—</option>
              {departments.map((d) => <option key={d.id} value={d.id}>{lang === "ar" ? d.name_ar : d.name_en}</option>)}
            </NativeSelect>
          </Field>
          <Field label="priority">
            <NativeSelect value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value as TaskPriority })}>
              {PRIORITIES.map((p) => <option key={p} value={p}>{t(`p_${p}` as TKey)}</option>)}
            </NativeSelect>
          </Field>
          <Field label="due"><Input type="date" value={f.due} onChange={(e) => setF({ ...f, due: e.target.value })} /></Field>
          <DialogFooter className="sm:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>{t("cancel")}</Button>
            <Button disabled={busy}>{t("create")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
