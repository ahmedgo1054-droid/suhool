import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowRight, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ErrorBox, Field, Loading, StatusBadge } from "@/components/page";
import { supabase } from "@/integrations/supabase/client";
import { fmtDate, maybe, money, must, personName, useMe, useProfiles, useSettings } from "@/lib/data";
import { buildQuoteDoc, QuotePdfButton } from "@/components/quote-pdf";
import { useI18n, type TKey } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/quotations/$id")({
  head: () => pageHead("Quotation", "Quotation items, VAT and approval."),
  component: QuoteDetail,
});

type QAction = "SUBMIT" | "APPROVE" | "REJECT_DRAFT" | "ACCEPT" | "REJECT" | "EXPIRE";

function QuoteDetail() {
  const { id } = Route.useParams();
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const { data: me } = useMe();
  const { data: profiles = [] } = useProfiles();
  const { data: settings = null } = useSettings();
  const byId = new Map(profiles.map((p) => [p.id, p]));
  const q = useQuery({
    queryKey: ["quotation", id],
    queryFn: async () => {
      const quote = maybe(await supabase.from("quotations").select("*, customers(*)").eq("id", id).maybeSingle());
      const items = must(await supabase.from("quotation_items").select("*").eq("quotation_id", id).order("position"));
      const events = must(await supabase.from("quotation_events").select("*").eq("quotation_id", id).order("created_at"));
      return { quote, items, events };
    },
  });
  const [item, setItem] = useState({ description: "", unit: "", qty: "1", unit_price: "", discount: "0" });
  const [meta, setMeta] = useState({ valid_until: "", payment_terms: "", notes: "" });
  useEffect(() => {
    if (q.data?.quote) setMeta({ valid_until: q.data.quote.valid_until ?? "", payment_terms: q.data.quote.payment_terms, notes: q.data.quote.notes });
  }, [q.data?.quote]);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["quotation", id] }); qc.invalidateQueries({ queryKey: ["quotations"] }); };

  if (q.isLoading) return <Loading />;
  if (q.error) return <ErrorBox error={q.error} />;
  const quote = q.data?.quote;
  if (!quote) return <ErrorBox error={t("not_found")} />;
  const draft = quote.status === "DRAFT";
  const owner = me?.user.id === quote.created_by || me?.isAdmin;
  const editable = draft && owner;

  const actions: QAction[] = [];
  if (draft && owner) actions.push("SUBMIT");
  if (quote.status === "PENDING_APPROVAL" && me?.isAdmin) actions.push("APPROVE", "REJECT_DRAFT");
  if (quote.status === "ISSUED" && owner) actions.push("ACCEPT", "REJECT", "EXPIRE");

  async function run(a: QAction) {
    const { error } = await supabase.rpc("quote_transition", { _q: id, _action: a });
    if (error) { toast.error(error.message); return; }
    toast.success(t("saved"));
    refresh();
  }

  async function addItem(e: React.FormEvent) {
    e.preventDefault();
    const qty = Number(item.qty), price = Number(item.unit_price), disc = Number(item.discount || 0);
    if (!(qty > 0) || !(price >= 0) || disc < 0 || disc > qty * price) { toast.error(t("invalid_amount")); return; }
    const { error } = await supabase.from("quotation_items").insert({
      quotation_id: id, description: item.description.trim().slice(0, 500), unit: item.unit.trim().slice(0, 30),
      qty, unit_price: price, discount: disc, position: (q.data?.items.length ?? 0) + 1,
    });
    if (error) { toast.error(error.message); return; }
    setItem({ description: "", unit: "", qty: "1", unit_price: "", discount: "0" });
    refresh();
  }

  async function removeItem(itemId: string) {
    const { error } = await supabase.from("quotation_items").delete().eq("id", itemId);
    if (error) { toast.error(error.message); return; }
    refresh();
  }

  async function saveMeta() {
    const { error } = await supabase.from("quotations").update({ valid_until: meta.valid_until || null, payment_terms: meta.payment_terms.slice(0, 2000), notes: meta.notes.slice(0, 2000) }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success(t("saved"));
    refresh();
  }

  const c = quote.customers;
  return (
    <div>
      <Link to="/quotations" className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary">
        <ArrowRight className="h-4 w-4 ltr:rotate-180" />{t("back")}
      </Link>
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="font-mono text-xs text-muted-foreground">Q-{quote.quote_no}</p>
          <h1 className="text-2xl font-bold text-primary">{c ? (lang === "ar" ? c.name_ar : c.name_en || c.name_ar) : "—"}</h1>
          <div className="mt-2"><StatusBadge status={quote.status} kind="quote" /></div>
          {quote.status === "PENDING_APPROVAL" && !me?.isAdmin && <p className="mt-2 text-sm text-muted-foreground">{t("needs_admin_approval")}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          {(() => { const { customers: cust, ...row } = quote; return <QuotePdfButton doc={buildQuoteDoc(row, q.data!.items, cust, settings)} />; })()}
          {actions.map((a) => (
            <Button key={a} size="sm" variant={a === "APPROVE" || a === "SUBMIT" ? "default" : "outline"} onClick={() => run(a)}>{t(`qa_${a}` as TKey)}</Button>
          ))}
        </div>
      </div>

      <Card className="mb-6">
        <CardHeader><CardTitle className="text-base">{t("items")}</CardTitle></CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  {(["description", "unit", "qty", "unit_price", "discount", "line_total"] as TKey[]).map((k) => <TableHead key={k} className="whitespace-nowrap text-start">{t(k)}</TableHead>)}
                  {editable && <TableHead />}
                </TableRow>
              </TableHeader>
              <TableBody>
                {q.data!.items.map((i) => (
                  <TableRow key={i.id}>
                    <TableCell>{i.description}</TableCell>
                    <TableCell>{i.unit || "—"}</TableCell>
                    <TableCell className="tabular-nums">{Number(i.qty)}</TableCell>
                    <TableCell className="tabular-nums">{money(i.unit_price, lang)}</TableCell>
                    <TableCell className="tabular-nums">{money(i.discount, lang)}</TableCell>
                    <TableCell className="tabular-nums font-medium">{money(i.line_total, lang)}</TableCell>
                    {editable && <TableCell><Button size="icon" variant="ghost" onClick={() => removeItem(i.id)} aria-label={t("delete")}><Trash2 className="h-4 w-4 text-destructive" /></Button></TableCell>}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {editable && (
            <form onSubmit={addItem} className="grid gap-2 border-t p-4 sm:grid-cols-[2fr_1fr_1fr_1fr_1fr_auto]">
              <Input required placeholder={t("description")} value={item.description} onChange={(e) => setItem({ ...item, description: e.target.value })} />
              <Input placeholder={t("unit")} value={item.unit} onChange={(e) => setItem({ ...item, unit: e.target.value })} />
              <Input required type="number" min="0.001" step="0.001" placeholder={t("qty")} value={item.qty} onChange={(e) => setItem({ ...item, qty: e.target.value })} />
              <Input required type="number" min="0" step="0.01" placeholder={t("unit_price")} value={item.unit_price} onChange={(e) => setItem({ ...item, unit_price: e.target.value })} />
              <Input type="number" min="0" step="0.01" placeholder={t("discount")} value={item.discount} onChange={(e) => setItem({ ...item, discount: e.target.value })} />
              <Button className="gap-1"><Plus className="h-4 w-4" />{t("add_item")}</Button>
            </form>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardContent className="grid gap-4 p-5 sm:grid-cols-2">
            <Field label="issue_date"><p className="text-sm">{fmtDate(quote.issue_date, lang)}</p></Field>
            <Field label="valid_until"><Input type="date" disabled={!editable} value={meta.valid_until} onChange={(e) => setMeta({ ...meta, valid_until: e.target.value })} /></Field>
            <Field label="payment_terms" className="sm:col-span-2"><Textarea rows={3} disabled={!editable} value={meta.payment_terms} onChange={(e) => setMeta({ ...meta, payment_terms: e.target.value })} /></Field>
            <Field label="notes" className="sm:col-span-2"><Textarea rows={2} disabled={!editable} value={meta.notes} onChange={(e) => setMeta({ ...meta, notes: e.target.value })} /></Field>
            {editable && <div className="sm:col-span-2"><Button variant="outline" onClick={saveMeta}>{t("save")}</Button></div>}
          </CardContent>
        </Card>
        <div className="space-y-6">
          <Card>
            <CardContent className="space-y-2 p-5 text-sm">
              <Row label="subtotal" value={money(quote.subtotal, lang)} />
              <Row label="discount" value={`- ${money(quote.discount_total, lang)}`} />
              <Row label="vat" value={`${money(quote.vat_amount, lang)} (${Number(quote.vat_rate)}%)`} />
              <div className="border-t pt-2"><Row label="grand_total" value={money(quote.grand_total, lang)} strong /></div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle className="text-base">{t("history")}</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              {q.data!.events.length === 0 && <p className="text-muted-foreground">—</p>}
              {q.data!.events.map((e) => (
                <div key={e.id}>
                  <p className="font-medium">{t(`qa_${e.event}` as TKey)}</p>
                  <p className="text-xs text-muted-foreground">{personName(e.actor_id ? byId.get(e.actor_id) : null, lang)} · {new Date(e.created_at).toLocaleString(lang === "ar" ? "ar-SA-u-ca-gregory" : "en-GB")}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, strong }: { label: TKey; value: string; strong?: boolean }) {
  const { t } = useI18n();
  return (
    <div className={`flex justify-between gap-4 ${strong ? "text-base font-bold text-primary" : ""}`}>
      <span>{t(label)}</span><span className="tabular-nums">{value}</span>
    </div>
  );
}
