import { createFileRoute, Outlet, useRouterState } from '@tanstack/react-router';
import { AdminServicesNav } from '@/components/admin-services-nav';
import { AdminRequests } from '@/components/admin-requests';
import { adminRequestsQuery } from '@/lib/admin-requests';
import { pageHead } from '@/lib/seo';
export const Route=createFileRoute('/_authenticated/admin-services')({
 head:()=>pageHead('الطلبات الإدارية','Secure administrative request submission, review and history in SUHOOLTECH.'),
 loader:({context})=>context.queryClient.ensureQueryData(adminRequestsQuery),component:Services,
});

function Services(){const path=useRouterState({select:s=>s.location.pathname});return <><AdminServicesNav/>{path.replace(/\/$/,'')==='/admin-services'?<AdminRequests/>:<Outlet/>}</>}
