import { createFileRoute } from "@tanstack/react-router";
import { ReportsCenter } from "@/components/reports";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/reports")({
  head: () => pageHead("مركز التقارير", "SUHOOLTECH branded reports for tasks, sales, HR, documents, requests, assets, purchasing and password-excluded company vault accounts."),
  component: ReportsCenter,
});
