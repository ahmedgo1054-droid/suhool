import { createFileRoute } from '@tanstack/react-router';
import { HrPage } from '@/components/hr/hr-page';
import { hrQuery } from '@/lib/hr';
import { pageHead } from '@/lib/seo';
export const Route = createFileRoute('/_authenticated/hr/employees')({
 head:()=>pageHead('HR employee files', 'SUHOOLTECH employee files, employment details and separately protected financial records.'),
 loader:({context})=>context.queryClient.ensureQueryData(hrQuery),
 component:()=> <HrPage mode="employees"/>,
});
