import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { TableCell, TableRow } from "@/components/ui/table";
import { DataTable, Field, PageHeader } from "@/components/page";
import { supabase } from "@/integrations/supabase/client";
import { useCustomers, useMe } from "@/lib/data";
import type { Database } from "@/integrations/supabase/types";
import { useI18n } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";

type Customer = Database["public"]["Tables"]["customers"]["Row"];

export const Route = createFileRoute("/_authenticated/customers")({
  head: () => pageHead("Customers", "Customer records, contacts and VAT details."),
  component: CustomersPage,
});

function CustomersPage() {
  const { t, lang } = useI18n();
  const { data: me } = useMe();
  const customers = useCustomers();
  const [editing, setEditing] = useState<Customer | "new" | null>(null);
  const canEdit = !!me && (me.isAdmin || me.is("sales"));
  const rows = customers.data ?? [];
  return (
    <div>
      <PageHeader title="customers" action={canEdit ? "new_customer" : undefined} onAction={() => setEditing("new")} />
      <DataTable columns={["name", "contact_name", "phone", "email", "vat_no", "actions"]} loading={customers.isLoading} error={customers.error} empty={!rows.length}>
        {rows.map((c) => (
          <TableRow key={c.id}>
            <TableCell className="font-medium">{lang === "ar" ? c.name_ar : c.name_en || c.name_ar}</TableCell>
            <TableCell>{c.contact_name || "—"}</TableCell>
            <TableCell dir="ltr" className="text-start">{c.phone || "—"}</TableCell>
            <TableCell dir="ltr" className="text-start">{c.email || "—"}</TableCell>
            <TableCell dir="ltr" className="text-start font-mono text-xs">{c.vat_no || "—"}</TableCell>
            <TableCell>{canEdit && <Button size="sm" variant="outline" onClick={() => setEditing(c)}>{t("edit")}</Button>}</TableCell>
          </TableRow>
        ))}
      </DataTable>
      {editing && <CustomerDialog customer={editing === "new" ? null : editing} onClose={() => setEditing(null)} />}
    </div>
  );
}

function CustomerDialog({ customer, onClose }: { customer: Customer | null; onClose: () => void }) {
  const { t } = useI18n();
  const qc = useQueryClient();
  const { data: me } = useMe();
  const [f, setF] = useState({
    name_ar: customer?.name_ar ?? "", name_en: customer?.name_en ?? "", contact_name: customer?.contact_name ?? "",
    phone: customer?.phone ?? "", email: customer?.email ?? "", vat_no: customer?.vat_no ?? "", cr_no: customer?.cr_no ?? "", address: customer?.address ?? "",
  });
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (f.vat_no && !/^\d{15}$/.test(f.vat_no.trim())) { toast.error(t("vat_invalid")); return; }
    const row = Object.fromEntries(Object.entries(f).map(([k, v]) => [k, v.trim() || null])) as typeof f;
    row.name_ar = f.name_ar.trim();
    row.name_en = f.name_en.trim();
    const { error } = customer
      ? await supabase.from("customers").update(row).eq("id", customer.id)
      : await supabase.from("customers").insert({ ...row, created_by: me!.user.id });
    if (error) { toast.error(error.message); return; }
    toast.success(t("saved"));
    qc.invalidateQueries({ queryKey: ["customers"] });
    onClose();
  }
  const input = (k: keyof typeof f, dir: "ltr" | "rtl" | undefined, req = false) => (
    <Input dir={dir} required={req} maxLength={200} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
  );
  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader><DialogTitle>{customer ? t("edit") : t("new_customer")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="name_ar">{input("name_ar", "rtl", true)}</Field>
          <Field label="name_en">{input("name_en", "ltr")}</Field>
          <Field label="contact_name">{input("contact_name", undefined)}</Field>
          <Field label="phone">{input("phone", "ltr")}</Field>
          <Field label="email">{input("email", "ltr")}</Field>
          <Field label="vat_no">{input("vat_no", "ltr")}</Field>
          <Field label="cr_no">{input("cr_no", "ltr")}</Field>
          <Field label="address">{input("address", undefined)}</Field>
          <DialogFooter className="sm:col-span-2">
            <Button type="button" variant="outline" onClick={onClose}>{t("cancel")}</Button>
            <Button>{t("save")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
