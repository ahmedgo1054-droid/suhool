import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowRight, Download, Paperclip } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { ErrorBox, Field, Loading, NativeSelect, StatusBadge } from "@/components/page";
import { supabase } from "@/integrations/supabase/client";
import { fmtDate, maybe, must, personName, useMe, useProfiles } from "@/lib/data";
import { useI18n, type TKey } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/tasks/$id")({
  head: () => pageHead("Task details", "Task timeline, comments and attachments."),
  component: TaskDetail,
});

type Action = "START" | "SUBMIT" | "APPROVE" | "RETURN" | "TRANSFER" | "CANCEL" | "ASSIGN";

function TaskDetail() {
  const { id } = Route.useParams();
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const { data: me } = useMe();
  const { data: profiles = [] } = useProfiles();
  const byId = new Map(profiles.map((p) => [p.id, p]));
  const [dialog, setDialog] = useState<Action | null>(null);
  const [comment, setComment] = useState("");

  const q = useQuery({
    queryKey: ["task", id],
    queryFn: async () => {
      const task = maybe(await supabase.from("tasks").select("*").eq("id", id).maybeSingle());
      const history = must(await supabase.from("task_history").select("*").eq("task_id", id).order("created_at"));
      const comments = must(await supabase.from("task_comments").select("*").eq("task_id", id).order("created_at"));
      const files = must(await supabase.from("attachments").select("*").eq("task_id", id).order("created_at"));
      return { task, history, comments, files };
    },
  });
  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["task", id] });
    qc.invalidateQueries({ queryKey: ["tasks"] });
  };

  if (q.isLoading) return <Loading />;
  if (q.error) return <ErrorBox error={q.error} />;
  const task = q.data?.task;
  if (!task) return <ErrorBox error={t("not_found")} />;

  const uid = me?.user.id;
  const isAssignee = uid === task.assignee_id;
  const isCreator = uid === task.created_by;
  const closed = task.status === "APPROVED" || task.status === "CANCELLED";
  const actions: Action[] = [];
  if (isAssignee && ["ASSIGNED", "TRANSFERRED", "RETURNED"].includes(task.status)) actions.push("START");
  if (isAssignee && ["IN_PROGRESS", "RETURNED", "ASSIGNED", "TRANSFERRED"].includes(task.status)) actions.push("SUBMIT");
  if (isCreator && task.status === "PENDING_REVIEW") actions.push("APPROVE", "RETURN");
  if ((isAssignee || me?.isAdmin) && !closed && task.status !== "PENDING_REVIEW") actions.push("TRANSFER");
  if ((isCreator || me?.isAdmin || me?.is("manager")) && !closed && !task.assignee_id) actions.push("ASSIGN");
  if ((isCreator || me?.isAdmin) && !closed) actions.push("CANCEL");

  async function run(action: Action, toUser?: string, reason?: string) {
    const { error } = await supabase.rpc("task_transition", { _task: id, _action: action, _to_user: (toUser || null) as string, _reason: (reason || null) as string });
    if (error) { toast.error(error.message); return; }
    toast.success(t("saved"));
    setDialog(null);
    refresh();
  }

  async function addComment(e: React.FormEvent) {
    e.preventDefault();
    if (!comment.trim() || !uid) return;
    const { error } = await supabase.from("task_comments").insert({ task_id: id, author_id: uid, body: comment.trim().slice(0, 4000) });
    if (error) { toast.error(error.message); return; }
    setComment("");
    refresh();
  }

  async function upload(file: File) {
    if (!uid) return;
    if (file.size > 20 * 1024 * 1024) { toast.error(t("file_too_large")); return; }
    const path = `${id}/${crypto.randomUUID()}-${file.name.replace(/[^\w.\-]+/g, "_")}`;
    const up = await supabase.storage.from("task-attachments").upload(path, file);
    if (up.error) { toast.error(up.error.message); return; }
    const { error } = await supabase.from("attachments").insert({ task_id: id, uploaded_by: uid, storage_path: path, file_name: file.name, size_bytes: file.size, mime_type: file.type || null });
    if (error) { toast.error(error.message); return; }
    toast.success(t("saved"));
    refresh();
  }

  async function download(path: string) {
    const { data, error } = await supabase.storage.from("task-attachments").createSignedUrl(path, 60);
    if (error) { toast.error(error.message); return; }
    window.open(data.signedUrl, "_blank", "noopener");
  }

  return (
    <div>
      <Link to="/tasks" className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary">
        <ArrowRight className="h-4 w-4 ltr:rotate-180" />{t("back")}
      </Link>
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="font-mono text-xs text-muted-foreground">T-{task.task_no}</p>
          <h1 className="text-2xl font-bold text-primary">{task.title}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
            <StatusBadge status={task.status} kind="task" />
            <span className="text-muted-foreground">{t(`p_${task.priority}` as TKey)}</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {actions.map((a) => (
            <Button key={a} size="sm" variant={a === "APPROVE" || a === "SUBMIT" || a === "START" ? "default" : a === "CANCEL" ? "destructive" : "outline"}
              onClick={() => (["TRANSFER", "RETURN", "ASSIGN", "CANCEL"].includes(a) ? setDialog(a) : run(a))}>
              {t(`a_${a}` as TKey)}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardContent className="grid gap-4 p-5 text-sm sm:grid-cols-2">
              <Info label="created_by" value={personName(byId.get(task.created_by), lang)} />
              <Info label="assignee" value={personName(task.assignee_id ? byId.get(task.assignee_id) : null, lang)} />
              <Info label="due" value={fmtDate(task.due_date, lang)} />
              <Info label="date" value={fmtDate(task.created_at, lang)} />
              <div className="sm:col-span-2">
                <p className="text-xs text-muted-foreground">{t("description")}</p>
                <p className="mt-1 whitespace-pre-wrap">{task.description || "—"}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">{t("comments")}</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {q.data!.comments.map((c) => (
                <div key={c.id} className="rounded-md border p-3">
                  <p className="text-xs text-muted-foreground">{personName(byId.get(c.author_id), lang)} · {new Date(c.created_at).toLocaleString(lang === "ar" ? "ar-SA-u-ca-gregory" : "en-GB")}</p>
                  <p className="mt-1 whitespace-pre-wrap text-sm">{c.body}</p>
                </div>
              ))}
              <form onSubmit={addComment} className="space-y-2">
                <Textarea rows={3} maxLength={4000} value={comment} onChange={(e) => setComment(e.target.value)} placeholder={t("add_comment")} />
                <Button size="sm" disabled={!comment.trim()}>{t("add_comment")}</Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader><CardTitle className="text-base">{t("attachments")}</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {q.data!.files.map((f) => (
                <button key={f.id} onClick={() => download(f.storage_path)} className="flex w-full items-center gap-2 rounded-md border p-2 text-start text-sm hover:bg-muted">
                  <Download className="h-4 w-4 shrink-0 text-accent-brand" />
                  <span className="truncate">{f.file_name}</span>
                </button>
              ))}
              <label className="flex cursor-pointer items-center justify-center gap-2 rounded-md border border-dashed p-3 text-sm text-muted-foreground hover:bg-muted">
                <Paperclip className="h-4 w-4" />{t("upload")}
                <input type="file" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); e.target.value = ""; }} />
              </label>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">{t("history")}</CardTitle></CardHeader>
            <CardContent>
              <ol className="space-y-3 border-s ps-4">
                {q.data!.history.map((h) => (
                  <li key={h.id} className="relative text-sm">
                    <span className="absolute -start-[21px] top-1.5 h-2.5 w-2.5 rounded-full bg-accent-brand" />
                    <p className="font-medium">{t(`a_${h.action}` as TKey)}{h.to_status && <> · <StatusBadge status={h.to_status} kind="task" /></>}</p>
                    <p className="text-xs text-muted-foreground">
                      {personName(h.actor_id ? byId.get(h.actor_id) : null, lang)}
                      {h.to_user && h.to_user !== h.from_user && <> → {personName(byId.get(h.to_user), lang)}</>}
                      {" · "}{new Date(h.created_at).toLocaleString(lang === "ar" ? "ar-SA-u-ca-gregory" : "en-GB")}
                    </p>
                    {h.reason && <p className="mt-1 text-xs">{t("reason")}: {h.reason}</p>}
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        </div>
      </div>

      <ActionDialog action={dialog} onClose={() => setDialog(null)} onRun={run} excludeId={task.assignee_id} />
    </div>
  );
}

function Info({ label, value }: { label: TKey; value: string }) {
  const { t } = useI18n();
  return (
    <div>
      <p className="text-xs text-muted-foreground">{t(label)}</p>
      <p className="mt-0.5 font-medium">{value}</p>
    </div>
  );
}

function ActionDialog({ action, onClose, onRun, excludeId }: { action: Action | null; onClose: () => void; onRun: (a: Action, u?: string, r?: string) => void; excludeId: string | null }) {
  const { t, lang } = useI18n();
  const { data: profiles = [] } = useProfiles();
  const [user, setUser] = useState("");
  const [reason, setReason] = useState("");
  const needsUser = action === "TRANSFER" || action === "ASSIGN";
  const needsReason = action === "TRANSFER" || action === "RETURN";
  return (
    <Dialog open={!!action} onOpenChange={(v) => { if (!v) { onClose(); setUser(""); setReason(""); } }}>
      <DialogContent>
        <DialogHeader><DialogTitle>{action && t(`a_${action}` as TKey)}</DialogTitle></DialogHeader>
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); if (action) onRun(action, user, reason); }}>
          {needsUser && (
            <Field label="transfer_to">
              <NativeSelect required value={user} onChange={(e) => setUser(e.target.value)}>
                <option value="">—</option>
                {profiles.filter((p) => p.is_active && p.id !== excludeId).map((p) => <option key={p.id} value={p.id}>{personName(p, lang)}</option>)}
              </NativeSelect>
            </Field>
          )}
          <Field label="reason"><Textarea required={needsReason} rows={3} maxLength={1000} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>{t("cancel")}</Button>
            <Button variant={action === "CANCEL" ? "destructive" : "default"}>{t("confirm")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
