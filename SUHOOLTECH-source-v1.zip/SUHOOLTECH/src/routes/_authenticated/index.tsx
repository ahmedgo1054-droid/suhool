import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, FileText, FolderOpen, Grid2X2, ListChecks, ShieldCheck, Users, LockKeyhole } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { personName, useMe } from "@/lib/data";
import { useI18n, type TKey } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";
import { availableSystems, futureSystems, isSystemCode, portalQueryOptions, type System, type SystemCode } from "@/lib/systems";
import logo from "@/assets/suhool-logo.png.asset.json";

export const Route = createFileRoute("/_authenticated/")({
  head: () => pageHead("بوابة سهول تيك", "Your authorized SUHOOLTECH systems: tasks, projects, sales and quotations."),
  loader: ({ context }) => context.queryClient.ensureQueryData(portalQueryOptions),
  component: Portal,
});

const icons = { tasks: ListChecks, quotes: FileText, hr: Users, docs: FolderOpen, admin_services: ShieldCheck, vault: LockKeyhole };
const destinations: Partial<Record<SystemCode, "/tasks" | "/quotations" | "/hr" | "/docs" | "/admin-services" | "/vault">> = { tasks: "/tasks", quotes: "/quotations", hr: "/hr", docs: "/docs", admin_services: "/admin-services", vault: "/vault" };

function Portal() {
  const { t, lang } = useI18n();
  const { data: me } = useMe();
  const { data } = useSuspenseQuery(portalQueryOptions);
  const active = availableSystems(data.systems, data.access);
  const upcoming = futureSystems(data.systems);
  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <section className="grid gap-6 border-b pb-7 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
        <div className="min-w-0">
          <p className="mb-3 flex items-center gap-2 text-sm font-medium text-accent-brand"><Grid2X2 className="h-4 w-4" />{t("portal_brand")}</p>
          <h1 className="text-3xl font-semibold text-primary">{t("portal_title")}</h1>
          <p className="mt-4 break-words text-base">{t("portal_welcome")} <span className="font-semibold">{personName(me?.profile, lang)}</span></p>
          <p className="mt-1 text-sm text-muted-foreground">{me?.roles.map((role) => t(`r_${role}` as TKey)).join(lang === "ar" ? "، " : ", ")}</p>
        </div>
        <img src={logo.url} alt={t("portal_brand")} className="h-16 w-40 max-w-full object-contain sm:h-20 sm:w-48" />
      </section>
      <section aria-labelledby="available-heading">
        <div className="mb-4 flex items-center gap-3"><h2 id="available-heading" className="text-lg font-semibold">{t("portal_available")}</h2><span className="grid h-6 min-w-6 place-items-center rounded-md bg-accent px-1.5 text-xs font-semibold text-accent-foreground">{active.length}</span></div>
        {active.length === 0 ? <p className="border-s-2 border-accent-brand bg-muted p-5 text-sm text-muted-foreground">{t("portal_no_access")}</p> : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{active.map((system) => <SystemCard key={system.id} system={system} />)}</div>
        )}
      </section>
      {upcoming.length > 0 && <section aria-labelledby="upcoming-heading">
        <h2 id="upcoming-heading" className="mb-4 text-lg font-semibold">{t("portal_future")}</h2>
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{upcoming.map((system) => <SystemCard key={system.id} system={system} />)}</div>
      </section>}
    </div>
  );
}

function SystemCard({ system }: { system: System }) {
  const { t, dir } = useI18n();
  if (!isSystemCode(system.code)) return null;
  const Icon = icons[system.code];
  const soon = system.status === "coming_soon";
  const to = soon ? undefined : destinations[system.code];
  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;
  return (
    <Card className={`h-full rounded-lg transition-colors ${soon ? "bg-muted/40" : "hover:border-accent-brand/50"}`}>
      <CardContent className="flex h-full flex-col p-6">
        <div className="mb-5 flex items-center justify-between gap-3">
          <div className={`grid h-12 w-12 shrink-0 place-items-center rounded-lg ${soon ? "bg-secondary text-muted-foreground" : "bg-accent text-accent-foreground"}`}><Icon className="h-6 w-6" /></div>
          <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${soon ? "text-muted-foreground" : "text-accent-brand"}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{t(soon ? "portal_soon" : "portal_active")}</span>
        </div>
        <h3 className="break-words text-lg font-semibold text-primary">{t(`portal_${system.code}` as TKey)}</h3>
        <p className="mb-6 mt-2 text-sm leading-6 text-muted-foreground">{t(`portal_${system.code}_desc` as TKey)}</p>
        {to && <Button asChild variant="outline" className="mt-auto w-full justify-between border-border bg-background"><Link to={to}>{t("portal_enter")}<Arrow className="h-4 w-4 text-accent-brand" /></Link></Button>}
      </CardContent>
    </Card>
  );
}
