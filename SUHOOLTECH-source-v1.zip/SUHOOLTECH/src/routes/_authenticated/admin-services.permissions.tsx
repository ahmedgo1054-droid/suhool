import { createFileRoute } from '@tanstack/react-router';
import { OpsPermissions } from '@/components/admin-ops';
import { adminOpsQuery } from '@/lib/admin-ops';
import { pageHead } from '@/lib/seo';
export const Route=createFileRoute('/_authenticated/admin-services/permissions')({head:()=>pageHead('Asset and purchasing permissions','SUHOOLTECH separate asset management, purchase approval and procurement permissions.'),loader:({context})=>context.queryClient.ensureQueryData(adminOpsQuery),component:OpsPermissions});
