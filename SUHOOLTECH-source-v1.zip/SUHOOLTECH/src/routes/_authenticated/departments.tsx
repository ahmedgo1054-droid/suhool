import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { TableCell, TableRow } from "@/components/ui/table";
import { DataTable, Field, NativeSelect, PageHeader } from "@/components/page";
import { supabase } from "@/integrations/supabase/client";
import { deptName, personName, useDepartments, useMe, useProfiles, type Department } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/departments")({
  head: () => pageHead("Departments", "Company departments and their managers."),
  component: DepartmentsPage,
});

function DepartmentsPage() {
  const { t, lang } = useI18n();
  const { data: me } = useMe();
  const deps = useDepartments();
  const { data: profiles = [] } = useProfiles();
  const byId = new Map(profiles.map((p) => [p.id, p]));
  const [editing, setEditing] = useState<Department | "new" | null>(null);
  const rows = deps.data ?? [];
  return (
    <div>
      <PageHeader title="departments" action={me?.isAdmin ? "new_department" : undefined} onAction={() => setEditing("new")} />
      <DataTable columns={me?.isAdmin ? ["name", "manager", "members", "actions"] : ["name", "manager", "members"]} loading={deps.isLoading} error={deps.error} empty={!rows.length}>
        {rows.map((d) => (
          <TableRow key={d.id}>
            <TableCell className="font-medium">{deptName(d, lang)}</TableCell>
            <TableCell>{personName(d.manager_id ? byId.get(d.manager_id) : null, lang)}</TableCell>
            <TableCell>{profiles.filter((p) => p.department_id === d.id).length}</TableCell>
            {me?.isAdmin && <TableCell><Button size="sm" variant="outline" onClick={() => setEditing(d)}>{t("edit")}</Button></TableCell>}
          </TableRow>
        ))}
      </DataTable>
      {editing && <DeptDialog dept={editing === "new" ? null : editing} onClose={() => setEditing(null)} />}
    </div>
  );
}

function DeptDialog({ dept, onClose }: { dept: Department | null; onClose: () => void }) {
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const { data: profiles = [] } = useProfiles();
  const [f, setF] = useState({ name_ar: dept?.name_ar ?? "", name_en: dept?.name_en ?? "", manager_id: dept?.manager_id ?? "" });
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const row = { name_ar: f.name_ar.trim(), name_en: f.name_en.trim(), manager_id: f.manager_id || null };
    const { error } = dept ? await supabase.from("departments").update(row).eq("id", dept.id) : await supabase.from("departments").insert(row);
    if (error) { toast.error(error.message); return; }
    toast.success(t("saved"));
    qc.invalidateQueries({ queryKey: ["departments"] });
    onClose();
  }
  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>{dept ? t("edit") : t("new_department")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <Field label="name_ar"><Input dir="rtl" required maxLength={120} value={f.name_ar} onChange={(e) => setF({ ...f, name_ar: e.target.value })} /></Field>
          <Field label="name_en"><Input dir="ltr" required maxLength={120} value={f.name_en} onChange={(e) => setF({ ...f, name_en: e.target.value })} /></Field>
          <Field label="manager">
            <NativeSelect value={f.manager_id} onChange={(e) => setF({ ...f, manager_id: e.target.value })}>
              <option value="">—</option>
              {profiles.filter((p) => p.is_active).map((p) => <option key={p.id} value={p.id}>{personName(p, lang)}</option>)}
            </NativeSelect>
          </Field>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>{t("cancel")}</Button>
            <Button>{t("save")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
