import { createFileRoute } from "@tanstack/react-router";
import { SystemAccessPage } from "@/components/system-access";
import { ErrorBox } from "@/components/page";
import { useI18n } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";
import { systemAccessQuery } from "@/lib/system-access";

export const Route = createFileRoute("/_authenticated/system-access")({
  head: () => pageHead("صلاحيات دخول الأنظمة", "Administrator control of user access and roles across SUHOOLTECH tasks, quotations, HR, documents and administrative services."),
  loader: ({ context }) => context.queryClient.ensureQueryData(systemAccessQuery),
  component: SystemAccessPage,
  errorComponent: AccessError,
});
function AccessError() {
  const { t } = useI18n();
  return <ErrorBox error={t("access_denied")} />;
}