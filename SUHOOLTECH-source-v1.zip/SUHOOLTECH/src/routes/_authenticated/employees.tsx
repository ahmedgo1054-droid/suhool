import { createFileRoute, Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { TableCell, TableRow } from "@/components/ui/table";
import { DataTable, ErrorBox, Field, FilterChips, NativeSelect, PageHeader } from "@/components/page";
import { createEmployee, setEmployeeActive, updateEmployee } from "@/lib/admin.functions";
import { deptName, personName, ROLES, useDepartments, useMe, useProfiles, type ProfileWithRoles, type Role } from "@/lib/data";
import { useI18n, type TKey } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/employees")({
  head: () => pageHead("Employees", "Manage employee accounts, departments and roles."),
  component: EmployeesPage,
});

function EmployeesPage() {
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const { data: me } = useMe();
  const profiles = useProfiles();
  const { data: departments = [] } = useDepartments();
  const toggleActive = useServerFn(setEmployeeActive);
  const [filter, setFilter] = useState<Role | "all">("all");
  const [editing, setEditing] = useState<ProfileWithRoles | "new" | null>(null);

  if (me && !me.isAdmin) return <ErrorBox error={t("admins_only")} />;
  const rows = (profiles.data ?? []).filter((p) => filter === "all" || p.roles.includes(filter));
  const dep = new Map(departments.map((d) => [d.id, d]));

  async function setActive(p: ProfileWithRoles, active: boolean) {
    try {
      await toggleActive({ data: { id: p.id, active } });
      toast.success(t("saved"));
      qc.invalidateQueries({ queryKey: ["profiles"] });
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <div>
      <PageHeader title="employees" action="new_employee" onAction={() => setEditing("new")} />
      <Button variant="outline" asChild className="mb-4"><Link to="/system-access">{t("access_edit")}</Link></Button>
      <FilterChips items={ROLES} value={filter} onChange={setFilter} label={(r) => t(`r_${r}` as TKey)} />
      <DataTable columns={["name", "email", "department", "role", "status", "actions"]} loading={profiles.isLoading} error={profiles.error} empty={!rows.length}>
        {rows.map((p) => (
          <TableRow key={p.id}>
            <TableCell className="font-medium">{personName(p, lang)}</TableCell>
            <TableCell dir="ltr" className="text-start">{p.email}</TableCell>
            <TableCell>{deptName(p.department_id ? dep.get(p.department_id) : null, lang)}</TableCell>
            <TableCell>{p.roles.map((r) => t(`r_${r}` as TKey)).join("، ")}</TableCell>
            <TableCell>
              <span className={p.is_active ? "text-chart-4" : "text-destructive"}>{t(p.is_active ? "active" : "suspended")}</span>
            </TableCell>
            <TableCell className="space-x-2 whitespace-nowrap rtl:space-x-reverse">
              <Button size="sm" variant="outline" onClick={() => setEditing(p)}>{t("edit")}</Button>
              {p.id !== me?.user.id && (
                <Button size="sm" variant={p.is_active ? "destructive" : "default"} onClick={() => setActive(p, !p.is_active)}>
                  {t(p.is_active ? "suspend" : "reactivate")}
                </Button>
              )}
            </TableCell>
          </TableRow>
        ))}
      </DataTable>
      {editing && <EmployeeDialog key={editing === "new" ? "new" : editing.id} employee={editing === "new" ? null : editing} onClose={() => setEditing(null)} />}
    </div>
  );
}

function EmployeeDialog({ employee, onClose }: { employee: ProfileWithRoles | null; onClose: () => void }) {
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const { data: departments = [] } = useDepartments();
  const create = useServerFn(createEmployee);
  const update = useServerFn(updateEmployee);
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({
    email: employee?.email ?? "", password: "",
    full_name_ar: employee?.full_name_ar ?? "", full_name_en: employee?.full_name_en ?? "",
    phone: employee?.phone ?? "", department_id: employee?.department_id ?? "",
    role: (employee?.roles[0] ?? "employee") as Role,
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (employee) await update({ data: { id: employee.id, full_name_ar: f.full_name_ar, full_name_en: f.full_name_en, phone: f.phone, department_id: f.department_id || null, role: f.role } });
      else await create({ data: { ...f, department_id: f.department_id || null } });
      toast.success(t("saved"));
      qc.invalidateQueries({ queryKey: ["profiles"] });
      qc.invalidateQueries({ queryKey: ["me"] });
      onClose();
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader><DialogTitle>{employee ? t("edit") : t("new_employee")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <Field label="full_name_ar"><Input dir="rtl" maxLength={120} value={f.full_name_ar} onChange={(e) => setF({ ...f, full_name_ar: e.target.value })} /></Field>
          <Field label="full_name_en"><Input dir="ltr" maxLength={120} value={f.full_name_en} onChange={(e) => setF({ ...f, full_name_en: e.target.value })} /></Field>
          <Field label="email"><Input type="email" dir="ltr" required disabled={!!employee} value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
          {!employee && <Field label="temp_password"><Input type="text" dir="ltr" required minLength={8} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></Field>}
          <Field label="phone"><Input dir="ltr" maxLength={30} value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
          <Field label="department">
            <NativeSelect value={f.department_id} onChange={(e) => setF({ ...f, department_id: e.target.value })}>
              <option value="">—</option>
              {departments.map((d) => <option key={d.id} value={d.id}>{deptName(d, lang)}</option>)}
            </NativeSelect>
          </Field>
          <Field label="role">
            <NativeSelect value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as Role })}>
              {ROLES.map((r) => <option key={r} value={r}>{t(`r_${r}` as TKey)}</option>)}
            </NativeSelect>
          </Field>
          <DialogFooter className="sm:col-span-2">
            <Button type="button" variant="outline" onClick={onClose}>{t("cancel")}</Button>
            <Button disabled={busy}>{t("save")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
