import { createFileRoute } from '@tanstack/react-router';
import { HrPage } from '@/components/hr/hr-page';
import { hrQuery } from '@/lib/hr';
import { pageHead } from '@/lib/seo';
export const Route = createFileRoute('/_authenticated/hr/')({
 head:()=>pageHead('Human resources', 'SUHOOLTECH HR overview with actual employee, leave and attendance statistics.'),
 loader:({context})=>context.queryClient.ensureQueryData(hrQuery),
 component:()=> <HrPage mode="overview"/>,
});
