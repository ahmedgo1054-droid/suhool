import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ErrorBox, Field, Loading, PageHeader } from "@/components/page";
import { supabase } from "@/integrations/supabase/client";
import { useMe, useSettings } from "@/lib/data";
import { backupCompanyVaultKeys, exportCompanyVaultKeys } from "@/lib/company-vault-backup.functions";
import { useI18n, type TKey } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => pageHead("Settings", "Company details, VAT, numbering and terms."),
  component: SettingsPage,
});

const TEXT: { k: string; label: TKey; dir?: "ltr" | "rtl" }[] = [
  { k: "name_ar", label: "company_name_ar", dir: "rtl" }, { k: "name_en", label: "company_name_en", dir: "ltr" },
  { k: "cr_no", label: "cr_no", dir: "ltr" }, { k: "vat_no", label: "vat_no", dir: "ltr" },
  { k: "phone", label: "phone", dir: "ltr" }, { k: "email", label: "email", dir: "ltr" },
  { k: "address_ar", label: "address_ar", dir: "rtl" }, { k: "address_en", label: "address_en", dir: "ltr" },
];
const LONG: { k: string; label: TKey; dir: "ltr" | "rtl" }[] = [
  { k: "payment_terms_ar", label: "payment_terms_ar", dir: "rtl" }, { k: "payment_terms_en", label: "payment_terms_en", dir: "ltr" },
  { k: "terms_ar", label: "terms_ar", dir: "rtl" }, { k: "terms_en", label: "terms_en", dir: "ltr" },
];

function SettingsPage() {
  const { t } = useI18n();
  const qc = useQueryClient();
  const { data: me } = useMe();
  const s = useSettings();
  const [f, setF] = useState<Record<string, string>>({});
  useEffect(() => {
    if (s.data) setF(Object.fromEntries(Object.entries(s.data).map(([k, v]) => [k, v == null ? "" : String(v)])));
  }, [s.data]);
  if (me && !me.isAdmin) return <ErrorBox error={t("admins_only")} />;
  if (s.isLoading) return <Loading />;
  if (s.error) return <ErrorBox error={s.error} />;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const vat = Number(f["vat_rate"]), days = parseInt(f["quote_validity_days"] ?? "", 10);
    if (!(vat >= 0 && vat <= 100) || !(days > 0)) { toast.error(t("invalid_amount")); return; }
    const row: Record<string, unknown> = { vat_rate: vat, quote_validity_days: days, task_prefix: f["task_prefix"] ?? "T-", quote_prefix: f["quote_prefix"] ?? "Q-" };
    for (const x of [...TEXT, ...LONG]) row[x.k] = f[x.k]?.trim() || (x.k.startsWith("name_") || x.k.includes("terms") ? "" : null);
    const { error } = await supabase.from("company_settings").update(row as never).eq("id", true);
    if (error) { toast.error(error.message); return; }
    toast.success(t("saved"));
    qc.invalidateQueries({ queryKey: ["settings"] });
  }
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });

  return (
    <form onSubmit={save}>
      <PageHeader title="settings"><Button>{t("save")}</Button></PageHeader>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">{t("settings_company")}</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            {TEXT.map((x) => <Field key={x.k} label={x.label}><Input dir={x.dir} maxLength={200} value={f[x.k] ?? ""} onChange={set(x.k)} /></Field>)}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">{t("settings_tax")}</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <Field label="vat_rate"><Input type="number" min="0" max="100" step="0.01" dir="ltr" value={f["vat_rate"] ?? ""} onChange={set("vat_rate")} /></Field>
            <Field label="validity_days"><Input type="number" min="1" dir="ltr" value={f["quote_validity_days"] ?? ""} onChange={set("quote_validity_days")} /></Field>
            <Field label="task_prefix"><Input dir="ltr" maxLength={10} value={f["task_prefix"] ?? ""} onChange={set("task_prefix")} /></Field>
            <Field label="quote_prefix"><Input dir="ltr" maxLength={10} value={f["quote_prefix"] ?? ""} onChange={set("quote_prefix")} /></Field>
          </CardContent>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle className="text-base">{t("settings_terms")}</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            {LONG.map((x) => <Field key={x.k} label={x.label}><Textarea dir={x.dir} rows={3} maxLength={4000} value={f[x.k] ?? ""} onChange={set(x.k)} /></Field>)}
          </CardContent>
        </Card>
        <VaultKeyBackupCard />
      </div>
    </form>
  );
}

function VaultKeyBackupCard() {
  const { t } = useI18n();
  const backup = useServerFn(backupCompanyVaultKeys);
  const exportKeys = useServerFn(exportCompanyVaultKeys);
  const [busy, setBusy] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [code, setCode] = useState("");
  const [factor, setFactor] = useState("");
  const [keys, setKeys] = useState<{ v1: string | null; v2: string } | null>(null);
  useEffect(() => {
    let active = true;
    void supabase.auth.mfa.listFactors().then(({ data }) => { if (active) setFactor(data?.totp.find((f) => f.status === "verified")?.id ?? ""); });
    return () => { active = false; };
  }, []);

  async function runBackup() {
    setBusy(true);
    try { await backup(); toast.success(t("kb_backed_up")); }
    catch { toast.error(t("kb_failed")); }
    finally { setBusy(false); }
  }
  async function runExport() {
    if (!factor || code.length !== 6) return;
    setBusy(true);
    try { setKeys(await exportKeys({ data: { factorId: factor, code } })); }
    catch { toast.error(t("kb_failed")); setExporting(false); }
    finally { setBusy(false); setCode(""); }
  }
  function close() { setExporting(false); setCode(""); setKeys(null); }

  return (
    <Card className="lg:col-span-2">
      <CardHeader><CardTitle className="text-base">{t("kb_title")}</CardTitle></CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">{t("kb_desc")}</p>
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant="outline" disabled={busy} onClick={() => void runBackup()}>{t("kb_backup")}</Button>
          <Button type="button" variant="outline" disabled={busy || !factor} onClick={() => setExporting(true)}>{t("kb_export")}</Button>
        </div>
        <Dialog open={exporting} onOpenChange={(v) => !v && close()}>
          <DialogContent>
            <DialogHeader><DialogTitle>{t("kb_export")}</DialogTitle><DialogDescription>{t("kb_export_warning")}</DialogDescription></DialogHeader>
            {!keys ? (
              <div className="space-y-4">
                <Field label="v_code"><Input aria-label={t("v_code")} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))} inputMode="numeric" autoComplete="one-time-code" maxLength={6} /></Field>
                <Button disabled={busy || code.length !== 6} onClick={() => void runExport()}>{t("v_verify")}</Button>
              </div>
            ) : (
              <div className="space-y-3" dir="ltr">
                {keys.v1 && <div><p className="text-sm font-medium">{t("kb_v1")}</p><p className="select-all break-all rounded-md border bg-muted p-3 font-mono text-sm">{keys.v1}</p></div>}
                <div><p className="text-sm font-medium">{t("kb_v2")}</p><p className="select-all break-all rounded-md border bg-muted p-3 font-mono text-sm">{keys.v2}</p></div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
