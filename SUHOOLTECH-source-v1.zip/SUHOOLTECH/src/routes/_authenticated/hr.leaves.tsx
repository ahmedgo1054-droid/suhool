import { createFileRoute } from '@tanstack/react-router';
import { HrPage } from '@/components/hr/hr-page';
import { hrQuery } from '@/lib/hr';
import { pageHead } from '@/lib/seo';
export const Route = createFileRoute('/_authenticated/hr/leaves')({
 head:()=>pageHead('HR leave requests', 'SUHOOLTECH leave requests, approval decisions and management-allocated balances.'),
 loader:({context})=>context.queryClient.ensureQueryData(hrQuery),
 component:()=> <HrPage mode="leaves"/>,
});
