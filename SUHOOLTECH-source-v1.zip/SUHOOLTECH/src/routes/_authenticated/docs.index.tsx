import { createFileRoute } from '@tanstack/react-router';
import { DocumentLibrary } from '@/components/documents';
import { documentsQuery } from '@/lib/documents';
import { pageHead } from '@/lib/seo';
export const Route = createFileRoute('/_authenticated/docs/')({
  head: () => pageHead('المستندات والمسودات', 'Private SUHOOLTECH document library, categories and draft review.'),
  loader: ({ context }) => context.queryClient.ensureQueryData(documentsQuery),
  component: DocumentLibrary,
});