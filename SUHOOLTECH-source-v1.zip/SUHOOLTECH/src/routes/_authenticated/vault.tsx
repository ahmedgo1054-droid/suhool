import { createFileRoute } from '@tanstack/react-router';
import { PersonalVault, personalVaultQuery } from '@/components/personal-vault';
import { pageHead } from '@/lib/seo';
export const Route = createFileRoute('/_authenticated/vault')({
  head: () => pageHead('خزنة كلمات المرور', 'SUHOOLTECH independent personal and company encrypted vaults, record permissions and verified sensitive reports.'),
  loader: ({ context }) => context.queryClient.ensureQueryData(personalVaultQuery),
  component: PersonalVault,
});