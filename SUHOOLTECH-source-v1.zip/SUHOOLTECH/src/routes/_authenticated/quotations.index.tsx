import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TableCell, TableRow } from "@/components/ui/table";
import { DataTable, Field, FilterChips, NativeSelect, PageHeader, StatusBadge } from "@/components/page";
import { supabase } from "@/integrations/supabase/client";
import { fmtDate, money, must, useCustomers, useMe, type QuoteStatus } from "@/lib/data";
import { useI18n, type TKey } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/_authenticated/quotations/")({
  head: () => pageHead("Quotations", "Prepare, approve and issue quotations."),
  component: QuotationsPage,
});

const STATUSES: QuoteStatus[] = ["DRAFT", "PENDING_APPROVAL", "ISSUED", "ACCEPTED", "REJECTED", "EXPIRED"];

function QuotationsPage() {
  const { t, lang } = useI18n();
  const { data: me } = useMe();
  const [filter, setFilter] = useState<QuoteStatus | "all">("all");
  const [open, setOpen] = useState(false);
  const quotes = useQuery({
    queryKey: ["quotations"],
    queryFn: async () => must(await supabase.from("quotations").select("*, customers(name_ar, name_en)").order("created_at", { ascending: false })),
  });
  const rows = (quotes.data ?? []).filter((q) => filter === "all" || q.status === filter);
  const canCreate = !!me && (me.isAdmin || me.is("sales"));
  return (
    <div>
      <PageHeader title="quotations" action={canCreate ? "new_quotation" : undefined} onAction={() => setOpen(true)} />
      <FilterChips items={STATUSES} value={filter} onChange={setFilter} label={(s) => t(`q_${s}` as TKey)} />
      <DataTable columns={["number", "customer", "date", "total", "status"]} loading={quotes.isLoading} error={quotes.error} empty={!rows.length}>
        {rows.map((q) => (
          <TableRow key={q.id}>
            <TableCell className="font-mono text-xs">
              <Link to="/quotations/$id" params={{ id: q.id }} className="text-primary hover:underline">Q-{q.quote_no}</Link>
            </TableCell>
            <TableCell>{q.customers ? (lang === "ar" ? q.customers.name_ar : q.customers.name_en || q.customers.name_ar) : "—"}</TableCell>
            <TableCell>{fmtDate(q.issue_date, lang)}</TableCell>
            <TableCell className="tabular-nums">{money(q.grand_total, lang)}</TableCell>
            <TableCell><StatusBadge status={q.status} kind="quote" /></TableCell>
          </TableRow>
        ))}
      </DataTable>
      <NewQuoteDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}

function NewQuoteDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const { data: me } = useMe();
  const { data: customers = [] } = useCustomers();
  const [customer, setCustomer] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const { data, error } = await supabase.from("quotations").insert({ customer_id: customer, created_by: me!.user.id }).select("id").single();
    if (error) { toast.error(error.message); return; }
    onOpenChange(false);
    navigate({ to: "/quotations/$id", params: { id: data.id } });
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>{t("new_quotation")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <Field label="customer">
            <NativeSelect required value={customer} onChange={(e) => setCustomer(e.target.value)}>
              <option value="">—</option>
              {customers.map((c) => <option key={c.id} value={c.id}>{lang === "ar" ? c.name_ar : c.name_en || c.name_ar}</option>)}
            </NativeSelect>
          </Field>
          {!customers.length && <p className="text-sm text-muted-foreground">{t("add_customer_first")}</p>}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>{t("cancel")}</Button>
            <Button disabled={!customer}>{t("create")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
