import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getSetupStatus, createInitialAdmin } from "@/lib/setup.functions";
import { Languages, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useI18n } from "@/lib/i18n";
import { pageHead } from "@/lib/seo";
import { supabase } from "@/integrations/supabase/client";
import logo from "@/assets/suhool-logo.png.asset.json";

export const Route = createFileRoute("/login")({
  head: () => pageHead("Sign in", "Sign in to SUHOOLTECH."),
  component: Login,
});

function Login() {
  const { t, toggle, dir } = useI18n();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [name, setName] = useState("");
  useEffect(() => { getSetupStatus().then((r) => setNeedsSetup(r.needsSetup)).catch(() => {}); }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    if (needsSetup) {
      try {
        await createInitialAdmin({ data: { email, password, name } });
        setNeedsSetup(false);
      } catch (err) {
        setBusy(false);
        setError(err instanceof Error ? err.message : String(err));
        return;
      }
    }
    const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (error || !data.user) {
      setBusy(false);
      setError(/banned/i.test(error?.message ?? "") ? t("account_suspended") : t("login_error"));
      return;
    }
    const { data: p } = await supabase.from("profiles").select("is_active").eq("id", data.user.id).maybeSingle();
    if (p && !p.is_active) {
      await supabase.auth.signOut();
      setBusy(false);
      setError(t("account_suspended"));
      return;
    }
    navigate({ to: "/" });
  }

  return (
    <div dir={dir} className="flex min-h-screen items-center justify-center bg-workspace px-4 py-8">
      <Card className="w-full max-w-md border-t-2 border-t-accent-brand shadow-surface">
        <CardContent className="p-6 sm:p-8">
          <div className="flex justify-end">
            <Button variant="ghost" size="sm" onClick={toggle} className="gap-2">
              <Languages className="h-4 w-4" />{t("switchLang")}
            </Button>
          </div>
          <img src={logo.url} alt={t("portal_brand")} className="mx-auto mt-3 h-20 w-auto object-contain" />
          {needsSetup ? (
            <div className="mt-4 text-center"><p className="font-semibold">{t("setup_title")}</p><p className="text-sm text-muted-foreground">{t("setup_sub")}</p></div>
          ) : <p className="mt-4 text-center text-sm text-muted-foreground">{t("login_sub")}</p>}
          <form className="mt-7 space-y-5" onSubmit={submit}>
            {needsSetup && (
              <div className="space-y-2">
                <Label htmlFor="name">{t("setup_name")}</Label>
                <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} />
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="email">{t("email")}</Label>
              <Input id="email" type="email" dir="ltr" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">{t("password")}</Label>
              <Input id="password" type="password" dir="ltr" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button className="w-full" disabled={busy}>
              {busy && <Loader2 className="h-4 w-4 animate-spin" />}{needsSetup ? t("setup_create") : t("login")}
            </Button>
            {!needsSetup && <p className="text-center text-xs text-muted-foreground">{t("login_note")}</p>}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
