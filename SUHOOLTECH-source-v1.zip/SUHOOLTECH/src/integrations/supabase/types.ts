export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      admin_assets: {
        Row: {
          asset_tag: string
          category: string
          condition: string
          created_at: string
          created_by: string
          id: string
          location: string
          name: string
          notes: string
          serial_no: string
          status: string
          updated_at: string
        }
        Insert: {
          asset_tag: string
          category?: string
          condition?: string
          created_at?: string
          created_by: string
          id?: string
          location?: string
          name: string
          notes?: string
          serial_no?: string
          status?: string
          updated_at?: string
        }
        Update: {
          asset_tag?: string
          category?: string
          condition?: string
          created_at?: string
          created_by?: string
          id?: string
          location?: string
          name?: string
          notes?: string
          serial_no?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_assets_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_custody: {
        Row: {
          asset_id: string
          assigned_at: string
          assigned_by: string
          custodian_id: string
          id: string
          issue_condition: string
          issue_note: string
          return_condition: string | null
          return_note: string
          returned_at: string | null
          returned_by: string | null
        }
        Insert: {
          asset_id: string
          assigned_at?: string
          assigned_by: string
          custodian_id: string
          id?: string
          issue_condition: string
          issue_note?: string
          return_condition?: string | null
          return_note?: string
          returned_at?: string | null
          returned_by?: string | null
        }
        Update: {
          asset_id?: string
          assigned_at?: string
          assigned_by?: string
          custodian_id?: string
          id?: string
          issue_condition?: string
          issue_note?: string
          return_condition?: string | null
          return_note?: string
          returned_at?: string | null
          returned_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "admin_custody_asset_id_fkey"
            columns: ["asset_id"]
            isOneToOne: false
            referencedRelation: "admin_assets"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_custody_assigned_by_fkey"
            columns: ["assigned_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_custody_custodian_id_fkey"
            columns: ["custodian_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_custody_returned_by_fkey"
            columns: ["returned_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_ops_events: {
        Row: {
          action: string
          actor_id: string
          asset_id: string | null
          created_at: string
          diff: Json
          id: string
          note: string
          purchase_id: string | null
        }
        Insert: {
          action: string
          actor_id: string
          asset_id?: string | null
          created_at?: string
          diff?: Json
          id?: string
          note?: string
          purchase_id?: string | null
        }
        Update: {
          action?: string
          actor_id?: string
          asset_id?: string | null
          created_at?: string
          diff?: Json
          id?: string
          note?: string
          purchase_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "admin_ops_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_ops_events_asset_id_fkey"
            columns: ["asset_id"]
            isOneToOne: false
            referencedRelation: "admin_assets"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_ops_events_purchase_id_fkey"
            columns: ["purchase_id"]
            isOneToOne: false
            referencedRelation: "admin_purchases"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_ops_permissions: {
        Row: {
          approve_purchases: boolean
          manage_assets: boolean
          manage_purchases: boolean
          user_id: string
        }
        Insert: {
          approve_purchases?: boolean
          manage_assets?: boolean
          manage_purchases?: boolean
          user_id: string
        }
        Update: {
          approve_purchases?: boolean
          manage_assets?: boolean
          manage_purchases?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_ops_permissions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_purchase_items: {
        Row: {
          description: string
          id: string
          line_total: number
          position: number
          purchase_id: string
          qty: number
          unit: string
          unit_price: number
        }
        Insert: {
          description: string
          id?: string
          line_total: number
          position: number
          purchase_id: string
          qty: number
          unit?: string
          unit_price: number
        }
        Update: {
          description?: string
          id?: string
          line_total?: number
          position?: number
          purchase_id?: string
          qty?: number
          unit?: string
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "admin_purchase_items_purchase_id_fkey"
            columns: ["purchase_id"]
            isOneToOne: false
            referencedRelation: "admin_purchases"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_purchases: {
        Row: {
          created_at: string
          decided_at: string | null
          decided_by: string | null
          decision_note: string
          id: string
          order_reference: string
          ordered_at: string | null
          ordered_by: string | null
          purchase_no: number
          reason: string
          receipt_note: string
          received_at: string | null
          received_by: string | null
          requester_id: string
          status: string
          supplier: string
          title: string
          total: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string
          id?: string
          order_reference?: string
          ordered_at?: string | null
          ordered_by?: string | null
          purchase_no?: never
          reason?: string
          receipt_note?: string
          received_at?: string | null
          received_by?: string | null
          requester_id: string
          status?: string
          supplier?: string
          title: string
          total?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string
          id?: string
          order_reference?: string
          ordered_at?: string | null
          ordered_by?: string | null
          purchase_no?: never
          reason?: string
          receipt_note?: string
          received_at?: string | null
          received_by?: string | null
          requester_id?: string
          status?: string
          supplier?: string
          title?: string
          total?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_purchases_decided_by_fkey"
            columns: ["decided_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_purchases_ordered_by_fkey"
            columns: ["ordered_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_purchases_received_by_fkey"
            columns: ["received_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_purchases_requester_id_fkey"
            columns: ["requester_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_request_events: {
        Row: {
          action: string
          actor_id: string
          created_at: string
          from_status: string | null
          id: string
          note: string
          request_id: string
          to_status: string | null
        }
        Insert: {
          action: string
          actor_id: string
          created_at?: string
          from_status?: string | null
          id?: string
          note?: string
          request_id: string
          to_status?: string | null
        }
        Update: {
          action?: string
          actor_id?: string
          created_at?: string
          from_status?: string | null
          id?: string
          note?: string
          request_id?: string
          to_status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "admin_request_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_request_events_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "admin_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_request_types: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          name_ar: string
          name_en: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          name_ar: string
          name_en: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          name_ar?: string
          name_en?: string
        }
        Relationships: []
      }
      admin_requests: {
        Row: {
          created_at: string
          decided_at: string | null
          decided_by: string | null
          decision_note: string
          description: string
          id: string
          priority: string
          request_no: number
          requester_id: string
          status: string
          title: string
          type_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string
          description?: string
          id?: string
          priority?: string
          request_no?: never
          requester_id: string
          status?: string
          title: string
          type_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string
          description?: string
          id?: string
          priority?: string
          request_no?: never
          requester_id?: string
          status?: string
          title?: string
          type_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_requests_decided_by_fkey"
            columns: ["decided_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_requests_requester_id_fkey"
            columns: ["requester_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_requests_type_id_fkey"
            columns: ["type_id"]
            isOneToOne: false
            referencedRelation: "admin_request_types"
            referencedColumns: ["id"]
          },
        ]
      }
      attachments: {
        Row: {
          created_at: string
          file_name: string
          id: string
          mime_type: string | null
          size_bytes: number
          storage_path: string
          task_id: string
          uploaded_by: string
        }
        Insert: {
          created_at?: string
          file_name: string
          id?: string
          mime_type?: string | null
          size_bytes?: number
          storage_path: string
          task_id: string
          uploaded_by: string
        }
        Update: {
          created_at?: string
          file_name?: string
          id?: string
          mime_type?: string | null
          size_bytes?: number
          storage_path?: string
          task_id?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "attachments_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "attachments_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          diff: Json | null
          entity: string
          entity_id: string | null
          id: string
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          diff?: Json | null
          entity: string
          entity_id?: string | null
          id?: string
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          diff?: Json | null
          entity?: string
          entity_id?: string | null
          id?: string
        }
        Relationships: []
      }
      company_settings: {
        Row: {
          address_ar: string | null
          address_en: string | null
          cr_no: string | null
          email: string | null
          id: boolean
          logo_path: string | null
          name_ar: string
          name_en: string
          payment_terms_ar: string
          payment_terms_en: string
          phone: string | null
          quote_prefix: string
          quote_validity_days: number
          task_prefix: string
          terms_ar: string
          terms_en: string
          updated_at: string
          vat_no: string | null
          vat_rate: number
        }
        Insert: {
          address_ar?: string | null
          address_en?: string | null
          cr_no?: string | null
          email?: string | null
          id?: boolean
          logo_path?: string | null
          name_ar?: string
          name_en?: string
          payment_terms_ar?: string
          payment_terms_en?: string
          phone?: string | null
          quote_prefix?: string
          quote_validity_days?: number
          task_prefix?: string
          terms_ar?: string
          terms_en?: string
          updated_at?: string
          vat_no?: string | null
          vat_rate?: number
        }
        Update: {
          address_ar?: string | null
          address_en?: string | null
          cr_no?: string | null
          email?: string | null
          id?: boolean
          logo_path?: string | null
          name_ar?: string
          name_en?: string
          payment_terms_ar?: string
          payment_terms_en?: string
          phone?: string | null
          quote_prefix?: string
          quote_validity_days?: number
          task_prefix?: string
          terms_ar?: string
          terms_en?: string
          updated_at?: string
          vat_no?: string | null
          vat_rate?: number
        }
        Relationships: []
      }
      company_vault_authorizations: {
        Row: {
          action: string
          actor_id: string
          expires_at: string
          record_id: string
          token: string
        }
        Insert: {
          action: string
          actor_id: string
          expires_at?: string
          record_id: string
          token: string
        }
        Update: {
          action?: string
          actor_id?: string
          expires_at?: string
          record_id?: string
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_vault_authorizations_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      company_vault_favorites: {
        Row: {
          record_id: string
          user_id: string
        }
        Insert: {
          record_id: string
          user_id: string
        }
        Update: {
          record_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_vault_favorites_record_id_fkey"
            columns: ["record_id"]
            isOneToOne: false
            referencedRelation: "vault_records"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_vault_favorites_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      company_vault_kek_backups: {
        Row: {
          blob: Json
          created_at: string
          created_by: string | null
          id: string
        }
        Insert: {
          blob: Json
          created_at?: string
          created_by?: string | null
          id?: string
        }
        Update: {
          blob?: Json
          created_at?: string
          created_by?: string | null
          id?: string
        }
        Relationships: []
      }
      customers: {
        Row: {
          address: string | null
          contact_name: string | null
          cr_no: string | null
          created_at: string
          created_by: string | null
          email: string | null
          id: string
          name_ar: string
          name_en: string
          phone: string | null
          updated_at: string
          vat_no: string | null
        }
        Insert: {
          address?: string | null
          contact_name?: string | null
          cr_no?: string | null
          created_at?: string
          created_by?: string | null
          email?: string | null
          id?: string
          name_ar: string
          name_en?: string
          phone?: string | null
          updated_at?: string
          vat_no?: string | null
        }
        Update: {
          address?: string | null
          contact_name?: string | null
          cr_no?: string | null
          created_at?: string
          created_by?: string | null
          email?: string | null
          id?: string
          name_ar?: string
          name_en?: string
          phone?: string | null
          updated_at?: string
          vat_no?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "customers_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      departments: {
        Row: {
          created_at: string
          id: string
          manager_id: string | null
          name_ar: string
          name_en: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          manager_id?: string | null
          name_ar: string
          name_en: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          manager_id?: string | null
          name_ar?: string
          name_en?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "departments_manager_fk"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      document_access: {
        Row: {
          document_id: string
          id: string
          role: string
          user_id: string
        }
        Insert: {
          document_id: string
          id?: string
          role: string
          user_id: string
        }
        Update: {
          document_id?: string
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "document_access_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_access_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      document_categories: {
        Row: {
          created_at: string
          id: string
          name_ar: string
          name_en: string
        }
        Insert: {
          created_at?: string
          id?: string
          name_ar: string
          name_en: string
        }
        Update: {
          created_at?: string
          id?: string
          name_ar?: string
          name_en?: string
        }
        Relationships: []
      }
      document_events: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          document_id: string
          from_status: string | null
          id: string
          note: string
          to_status: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          document_id: string
          from_status?: string | null
          id?: string
          note?: string
          to_status?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          document_id?: string
          from_status?: string | null
          id?: string
          note?: string
          to_status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "document_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_events_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
      document_versions: {
        Row: {
          created_at: string
          document_id: string
          file_name: string
          id: string
          mime_type: string
          ready: boolean
          size_bytes: number
          storage_path: string
          uploaded_by: string
          version: number
        }
        Insert: {
          created_at?: string
          document_id: string
          file_name: string
          id?: string
          mime_type?: string
          ready?: boolean
          size_bytes: number
          storage_path: string
          uploaded_by: string
          version: number
        }
        Update: {
          created_at?: string
          document_id?: string
          file_name?: string
          id?: string
          mime_type?: string
          ready?: boolean
          size_bytes?: number
          storage_path?: string
          uploaded_by?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "document_versions_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_versions_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      documents: {
        Row: {
          category_id: string | null
          created_at: string
          description: string
          id: string
          owner_id: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          description?: string
          id?: string
          owner_id: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          category_id?: string | null
          created_at?: string
          description?: string
          id?: string
          owner_id?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "documents_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "document_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      hr_attendance: {
        Row: {
          check_in: string | null
          check_out: string | null
          correction_reason: string | null
          employee_id: string
          id: string
          late_minutes: number
          status: string
          updated_at: string
          work_date: string
        }
        Insert: {
          check_in?: string | null
          check_out?: string | null
          correction_reason?: string | null
          employee_id: string
          id?: string
          late_minutes?: number
          status?: string
          updated_at?: string
          work_date: string
        }
        Update: {
          check_in?: string | null
          check_out?: string | null
          correction_reason?: string | null
          employee_id?: string
          id?: string
          late_minutes?: number
          status?: string
          updated_at?: string
          work_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "hr_attendance_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "hr_employees"
            referencedColumns: ["id"]
          },
        ]
      }
      hr_audit_logs: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          diff: Json | null
          entity: string
          entity_id: string | null
          id: string
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          diff?: Json | null
          entity: string
          entity_id?: string | null
          id?: string
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          diff?: Json | null
          entity?: string
          entity_id?: string | null
          id?: string
        }
        Relationships: []
      }
      hr_employees: {
        Row: {
          contract_type: string
          created_at: string
          employee_no: string
          employment_status: string
          id: string
          job_title: string
          start_date: string
          updated_at: string
        }
        Insert: {
          contract_type?: string
          created_at?: string
          employee_no: string
          employment_status?: string
          id: string
          job_title: string
          start_date: string
          updated_at?: string
        }
        Update: {
          contract_type?: string
          created_at?: string
          employee_no?: string
          employment_status?: string
          id?: string
          job_title?: string
          start_date?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "hr_employees_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      hr_finances: {
        Row: {
          allowances: number
          id: string
          salary: number
          updated_at: string
        }
        Insert: {
          allowances?: number
          id: string
          salary?: number
          updated_at?: string
        }
        Update: {
          allowances?: number
          id?: string
          salary?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "hr_finances_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "hr_employees"
            referencedColumns: ["id"]
          },
        ]
      }
      hr_leave_balances: {
        Row: {
          employee_id: string
          entitlement: number
          id: string
          type_id: string
          year: number
        }
        Insert: {
          employee_id: string
          entitlement: number
          id?: string
          type_id: string
          year: number
        }
        Update: {
          employee_id?: string
          entitlement?: number
          id?: string
          type_id?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "hr_leave_balances_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "hr_employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "hr_leave_balances_type_id_fkey"
            columns: ["type_id"]
            isOneToOne: false
            referencedRelation: "hr_leave_types"
            referencedColumns: ["id"]
          },
        ]
      }
      hr_leave_types: {
        Row: {
          id: string
          name_ar: string
          name_en: string
          tracks_balance: boolean
        }
        Insert: {
          id?: string
          name_ar: string
          name_en: string
          tracks_balance?: boolean
        }
        Update: {
          id?: string
          name_ar?: string
          name_en?: string
          tracks_balance?: boolean
        }
        Relationships: []
      }
      hr_leaves: {
        Row: {
          created_at: string
          days: number | null
          decided_at: string | null
          decided_by: string | null
          decision_note: string | null
          employee_id: string
          end_date: string
          id: string
          reason: string
          start_date: string
          status: string
          type_id: string
        }
        Insert: {
          created_at?: string
          days?: number | null
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string | null
          employee_id: string
          end_date: string
          id?: string
          reason?: string
          start_date: string
          status?: string
          type_id: string
        }
        Update: {
          created_at?: string
          days?: number | null
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string | null
          employee_id?: string
          end_date?: string
          id?: string
          reason?: string
          start_date?: string
          status?: string
          type_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "hr_leaves_decided_by_fkey"
            columns: ["decided_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "hr_leaves_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "hr_employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "hr_leaves_type_id_fkey"
            columns: ["type_id"]
            isOneToOne: false
            referencedRelation: "hr_leave_types"
            referencedColumns: ["id"]
          },
        ]
      }
      hr_permissions: {
        Row: {
          approve_leaves: boolean
          correct_attendance: boolean
          id: string
          manage_employees: boolean
          user_id: string
          view_salary: boolean
        }
        Insert: {
          approve_leaves?: boolean
          correct_attendance?: boolean
          id?: string
          manage_employees?: boolean
          user_id: string
          view_salary?: boolean
        }
        Update: {
          approve_leaves?: boolean
          correct_attendance?: boolean
          id?: string
          manage_employees?: boolean
          user_id?: string
          view_salary?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "hr_permissions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      hr_policy: {
        Row: {
          grace_minutes: number
          id: boolean
          timezone: string
          updated_at: string
          work_days: number[]
          work_start: string | null
        }
        Insert: {
          grace_minutes?: number
          id?: boolean
          timezone?: string
          updated_at?: string
          work_days?: number[]
          work_start?: string | null
        }
        Update: {
          grace_minutes?: number
          id?: boolean
          timezone?: string
          updated_at?: string
          work_days?: number[]
          work_start?: string | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body_ar: string
          body_en: string
          created_at: string
          id: string
          link: string | null
          read_at: string | null
          title_ar: string
          title_en: string
          user_id: string
        }
        Insert: {
          body_ar?: string
          body_en?: string
          created_at?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title_ar: string
          title_en: string
          user_id: string
        }
        Update: {
          body_ar?: string
          body_en?: string
          created_at?: string
          id?: string
          link?: string | null
          read_at?: string | null
          title_ar?: string
          title_en?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      personal_vault_authorizations: {
        Row: {
          action: string
          expires_at: string
          owner_id: string
          record_id: string | null
          token: string
        }
        Insert: {
          action: string
          expires_at?: string
          owner_id: string
          record_id?: string | null
          token: string
        }
        Update: {
          action?: string
          expires_at?: string
          owner_id?: string
          record_id?: string | null
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "personal_vault_authorizations_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      personal_vault_events: {
        Row: {
          action: string
          created_at: string
          id: string
          owner_id: string
          record_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          owner_id: string
          record_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          owner_id?: string
          record_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "personal_vault_events_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      personal_vault_keys: {
        Row: {
          created_at: string
          owner_id: string
          password_wrap: Json
          recovery_wrap: Json
          revision: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          owner_id: string
          password_wrap: Json
          recovery_wrap: Json
          revision?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          owner_id?: string
          password_wrap?: Json
          recovery_wrap?: Json
          revision?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "personal_vault_keys_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      personal_vault_records: {
        Row: {
          created_at: string
          envelope: Json
          id: string
          owner_id: string
          revision: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          envelope: Json
          id?: string
          owner_id: string
          revision?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          envelope?: Json
          id?: string
          owner_id?: string
          revision?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "personal_vault_records_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          department_id: string | null
          email: string
          full_name_ar: string
          full_name_en: string
          id: string
          is_active: boolean
          phone: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          department_id?: string | null
          email: string
          full_name_ar?: string
          full_name_en?: string
          id: string
          is_active?: boolean
          phone?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          department_id?: string | null
          email?: string
          full_name_ar?: string
          full_name_en?: string
          id?: string
          is_active?: boolean
          phone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      quotation_events: {
        Row: {
          actor_id: string | null
          created_at: string
          event: string
          id: string
          note: string | null
          quotation_id: string
        }
        Insert: {
          actor_id?: string | null
          created_at?: string
          event: string
          id?: string
          note?: string | null
          quotation_id: string
        }
        Update: {
          actor_id?: string | null
          created_at?: string
          event?: string
          id?: string
          note?: string | null
          quotation_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "quotation_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotation_events_quotation_id_fkey"
            columns: ["quotation_id"]
            isOneToOne: false
            referencedRelation: "quotations"
            referencedColumns: ["id"]
          },
        ]
      }
      quotation_items: {
        Row: {
          description: string
          discount: number
          id: string
          line_total: number
          position: number
          qty: number
          quotation_id: string
          unit: string
          unit_price: number
        }
        Insert: {
          description: string
          discount?: number
          id?: string
          line_total?: number
          position?: number
          qty: number
          quotation_id: string
          unit?: string
          unit_price: number
        }
        Update: {
          description?: string
          discount?: number
          id?: string
          line_total?: number
          position?: number
          qty?: number
          quotation_id?: string
          unit?: string
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "quotation_items_quotation_id_fkey"
            columns: ["quotation_id"]
            isOneToOne: false
            referencedRelation: "quotations"
            referencedColumns: ["id"]
          },
        ]
      }
      quotations: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          created_by: string
          customer_id: string
          discount_total: number
          grand_total: number
          id: string
          issue_date: string
          notes: string
          payment_terms: string
          quote_no: number
          snapshot: Json | null
          status: Database["public"]["Enums"]["quote_status"]
          subtotal: number
          updated_at: string
          valid_until: string | null
          vat_amount: number
          vat_rate: number
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by: string
          customer_id: string
          discount_total?: number
          grand_total?: number
          id?: string
          issue_date?: string
          notes?: string
          payment_terms?: string
          quote_no?: number
          snapshot?: Json | null
          status?: Database["public"]["Enums"]["quote_status"]
          subtotal?: number
          updated_at?: string
          valid_until?: string | null
          vat_amount?: number
          vat_rate?: number
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by?: string
          customer_id?: string
          discount_total?: number
          grand_total?: number
          id?: string
          issue_date?: string
          notes?: string
          payment_terms?: string
          quote_no?: number
          snapshot?: Json | null
          status?: Database["public"]["Enums"]["quote_status"]
          subtotal?: number
          updated_at?: string
          valid_until?: string | null
          vat_amount?: number
          vat_rate?: number
        }
        Relationships: [
          {
            foreignKeyName: "quotations_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotations_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotations_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      systems: {
        Row: {
          code: string
          created_at: string
          id: string
          name_ar: string
          name_en: string
          position: number
          status: string
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          name_ar: string
          name_en: string
          position?: number
          status?: string
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          name_ar?: string
          name_en?: string
          position?: number
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      task_comments: {
        Row: {
          author_id: string
          body: string
          created_at: string
          id: string
          task_id: string
        }
        Insert: {
          author_id: string
          body: string
          created_at?: string
          id?: string
          task_id: string
        }
        Update: {
          author_id?: string
          body?: string
          created_at?: string
          id?: string
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_comments_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "task_comments_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      task_history: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          from_status: Database["public"]["Enums"]["task_status"] | null
          from_user: string | null
          id: string
          reason: string | null
          task_id: string
          to_status: Database["public"]["Enums"]["task_status"] | null
          to_user: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          from_status?: Database["public"]["Enums"]["task_status"] | null
          from_user?: string | null
          id?: string
          reason?: string | null
          task_id: string
          to_status?: Database["public"]["Enums"]["task_status"] | null
          to_user?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          from_status?: Database["public"]["Enums"]["task_status"] | null
          from_user?: string | null
          id?: string
          reason?: string | null
          task_id?: string
          to_status?: Database["public"]["Enums"]["task_status"] | null
          to_user?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "task_history_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "task_history_from_user_fkey"
            columns: ["from_user"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "task_history_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "task_history_to_user_fkey"
            columns: ["to_user"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          approved_at: string | null
          assignee_id: string | null
          completed_at: string | null
          created_at: string
          created_by: string
          department_id: string | null
          description: string
          due_date: string | null
          id: string
          priority: Database["public"]["Enums"]["task_priority"]
          status: Database["public"]["Enums"]["task_status"]
          task_no: number
          title: string
          updated_at: string
        }
        Insert: {
          approved_at?: string | null
          assignee_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by: string
          department_id?: string | null
          description?: string
          due_date?: string | null
          id?: string
          priority?: Database["public"]["Enums"]["task_priority"]
          status?: Database["public"]["Enums"]["task_status"]
          task_no?: number
          title: string
          updated_at?: string
        }
        Update: {
          approved_at?: string | null
          assignee_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string
          department_id?: string | null
          description?: string
          due_date?: string | null
          id?: string
          priority?: Database["public"]["Enums"]["task_priority"]
          status?: Database["public"]["Enums"]["task_status"]
          task_no?: number
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_assignee_id_fkey"
            columns: ["assignee_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_system_access: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          system_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          system_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          system_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_system_access_system_id_fkey"
            columns: ["system_id"]
            isOneToOne: false
            referencedRelation: "systems"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_system_access_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      vault_audit_events: {
        Row: {
          action: string
          actor_id: string
          created_at: string
          details: Json
          id: string
          record_id: string | null
          record_reference: string | null
        }
        Insert: {
          action: string
          actor_id: string
          created_at?: string
          details?: Json
          id?: string
          record_id?: string | null
          record_reference?: string | null
        }
        Update: {
          action?: string
          actor_id?: string
          created_at?: string
          details?: Json
          id?: string
          record_id?: string | null
          record_reference?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "vault_audit_events_actor_id_fkey"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vault_audit_events_record_id_fkey"
            columns: ["record_id"]
            isOneToOne: false
            referencedRelation: "vault_records"
            referencedColumns: ["id"]
          },
        ]
      }
      vault_ciphertexts: {
        Row: {
          envelope: Json
          key_version: string
          record_id: string
          revision: number
          wrapped_key: Json
        }
        Insert: {
          envelope: Json
          key_version: string
          record_id: string
          revision?: number
          wrapped_key: Json
        }
        Update: {
          envelope?: Json
          key_version?: string
          record_id?: string
          revision?: number
          wrapped_key?: Json
        }
        Relationships: [
          {
            foreignKeyName: "vault_ciphertexts_record_id_fkey"
            columns: ["record_id"]
            isOneToOne: true
            referencedRelation: "vault_records"
            referencedColumns: ["id"]
          },
        ]
      }
      vault_record_grants: {
        Row: {
          can_delete: boolean
          can_edit: boolean
          can_manage_grants: boolean
          can_reveal: boolean
          can_sensitive_print: boolean
          can_view: boolean
          record_id: string
          user_id: string
        }
        Insert: {
          can_delete?: boolean
          can_edit?: boolean
          can_manage_grants?: boolean
          can_reveal?: boolean
          can_sensitive_print?: boolean
          can_view?: boolean
          record_id: string
          user_id: string
        }
        Update: {
          can_delete?: boolean
          can_edit?: boolean
          can_manage_grants?: boolean
          can_reveal?: boolean
          can_sensitive_print?: boolean
          can_view?: boolean
          record_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vault_record_grants_record_id_fkey"
            columns: ["record_id"]
            isOneToOne: false
            referencedRelation: "vault_records"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vault_record_grants_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      vault_records: {
        Row: {
          category: string
          created_at: string
          customer_id: string | null
          device_type: string
          id: string
          name: string
          owner_id: string
          project: string
          review_at: string | null
          revision: number
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          customer_id?: string | null
          device_type?: string
          id?: string
          name: string
          owner_id: string
          project?: string
          review_at?: string | null
          revision?: number
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          customer_id?: string | null
          device_type?: string
          id?: string
          name?: string
          owner_id?: string
          project?: string
          review_at?: string | null
          revision?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "vault_records_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vault_records_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_asset_can: { Args: { _id: string }; Returns: boolean }
      admin_ops_can: { Args: { _permission: string }; Returns: boolean }
      admin_ops_command: {
        Args: { _action: string; _data?: Json }
        Returns: Json
      }
      admin_purchase_can: { Args: { _id: string }; Returns: boolean }
      admin_request_can: { Args: { _id: string }; Returns: boolean }
      admin_request_command: {
        Args: { _action: string; _data?: Json }
        Returns: Json
      }
      admin_services_member: { Args: never; Returns: boolean }
      admin_services_reviewer: { Args: never; Returns: boolean }
      can_see_task: { Args: { _task_id: string }; Returns: boolean }
      company_vault_command: {
        Args: {
          _action: string
          _actor: string
          _data?: Json
          _id: string
          _token: string
        }
        Returns: Json
      }
      company_vault_sharing_candidates: {
        Args: never
        Returns: {
          email: string
          full_name_ar: string
          full_name_en: string
          id: string
        }[]
      }
      docs_can: {
        Args: { _id: string; _permission?: string }
        Returns: boolean
      }
      docs_command: { Args: { _action: string; _data?: Json }; Returns: Json }
      docs_member: { Args: never; Returns: boolean }
      docs_upload_allowed: { Args: { _path: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      hr_can: { Args: { _permission?: string }; Returns: boolean }
      hr_command: { Args: { _action: string; _data?: Json }; Returns: Json }
      is_active_user: { Args: { _user_id: string }; Returns: boolean }
      my_department: { Args: never; Returns: string }
      notify: {
        Args: {
          _bar: string
          _ben: string
          _link: string
          _tar: string
          _ten: string
          _user: string
        }
        Returns: undefined
      }
      personal_vault_command: {
        Args: { _action: string; _data: Json }
        Returns: Json
      }
      personal_vault_status: { Args: never; Returns: Json }
      quote_recalc: { Args: { _q: string }; Returns: undefined }
      quote_transition: {
        Args: { _action: string; _note?: string; _q: string }
        Returns: undefined
      }
      task_create: {
        Args: {
          _assignee: string
          _department: string
          _description: string
          _due: string
          _priority: Database["public"]["Enums"]["task_priority"]
          _title: string
        }
        Returns: string
      }
      task_transition: {
        Args: {
          _action: string
          _reason?: string
          _task: string
          _to_user?: string
        }
        Returns: undefined
      }
      vault_can: {
        Args: { _permission: string; _record: string }
        Returns: boolean
      }
      vault_member: { Args: never; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "manager" | "sales" | "employee"
      quote_status:
        | "DRAFT"
        | "PENDING_APPROVAL"
        | "ISSUED"
        | "ACCEPTED"
        | "REJECTED"
        | "EXPIRED"
      task_priority: "LOW" | "MEDIUM" | "HIGH" | "URGENT"
      task_status:
        | "NEW"
        | "ASSIGNED"
        | "IN_PROGRESS"
        | "PENDING_REVIEW"
        | "APPROVED"
        | "TRANSFERRED"
        | "RETURNED"
        | "CANCELLED"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "manager", "sales", "employee"],
      quote_status: [
        "DRAFT",
        "PENDING_APPROVAL",
        "ISSUED",
        "ACCEPTED",
        "REJECTED",
        "EXPIRED",
      ],
      task_priority: ["LOW", "MEDIUM", "HIGH", "URGENT"],
      task_status: [
        "NEW",
        "ASSIGNED",
        "IN_PROGRESS",
        "PENDING_REVIEW",
        "APPROVED",
        "TRANSFERRED",
        "RETURNED",
        "CANCELLED",
      ],
    },
  },
} as const
