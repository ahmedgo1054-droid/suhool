import { useState } from "react";
import { useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Search, ShieldCheck, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { PageHeader, NativeSelect } from "@/components/page";
import { personName, ROLES, type Role } from "@/lib/data";
import { useI18n, type TKey } from "@/lib/i18n";
import { systemAccessQuery } from "@/lib/system-access";
import { setSystemAccess } from "@/lib/system-access.functions";
import { isSystemCode } from "@/lib/systems";

export function SystemAccessPage() {
  const { t, lang } = useI18n();
  const { data } = useSuspenseQuery(systemAccessQuery);
  const qc = useQueryClient();
  const save = useServerFn(setSystemAccess);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [selected, setSelected] = useState(data.profiles[0]?.id ?? "");
  const [busy, setBusy] = useState<string | null>(null);
  const [revoke, setRevoke] = useState<string | null>(null);
  const profiles = data.profiles.filter(p => `${p.full_name_ar} ${p.full_name_en} ${p.email}`.toLowerCase().includes(search.toLowerCase()) && (status === "all" || p.is_active === (status === "active")));
  const user = data.profiles.find(p => p.id === selected);
  const systems = data.systems.filter(s => isSystemCode(s.code));
  const systemName = (code: string) => t(`portal_${code}` as TKey);

  async function update(systemId: string, role: Role | null) {
    if (!user || busy) return;
    setBusy(systemId);
    try {
      await save({ data: { userId: user.id, systemId, role } });
      await Promise.all([qc.invalidateQueries({ queryKey: ["system-access"] }), qc.invalidateQueries({ queryKey: ["portal-systems"] }), qc.invalidateQueries({ queryKey: ["hr"] }), qc.invalidateQueries({ queryKey: ["documents"] }), qc.invalidateQueries({ queryKey: ["admin-requests"] }), qc.invalidateQueries({ queryKey: ["admin-ops"] })]);
      setRevoke(null);
      toast.success(t("access_saved"));
    } catch {
      toast.error(t("access_failed"));
    } finally { setBusy(null); }
  }

  return <div className="mx-auto max-w-6xl">
    <PageHeader title="access_title"><ShieldCheck className="h-6 w-6 text-accent-brand" /></PageHeader>
    <div className="grid gap-8 lg:grid-cols-[minmax(240px,320px)_minmax(0,1fr)]">
      <section aria-label={t("access_user")} className="min-w-0 lg:border-e lg:pe-6">
        <div className="relative mb-3"><Search className="absolute start-3 top-3 h-4 w-4 text-muted-foreground" /><Input aria-label={t("search")} placeholder={t("search")} className="ps-9" value={search} onChange={e => setSearch(e.target.value)} /></div>
        <NativeSelect aria-label={t("status")} value={status} onChange={e => setStatus(e.target.value)} className="mb-4"><option value="all">{t("filter_all")}</option><option value="active">{t("active")}</option><option value="suspended">{t("suspended")}</option></NativeSelect>
        <div className="max-h-52 space-y-2 overflow-y-auto pe-1 lg:max-h-[65dvh]">{profiles.map(p => <Button key={p.id} variant={p.id === selected ? "secondary" : "ghost"} aria-pressed={p.id === selected} disabled={!!busy} onClick={() => setSelected(p.id)} className={`h-auto w-full justify-start gap-3 whitespace-normal border p-3 text-start ${p.id === selected ? "border-accent-brand/40 bg-accent/60" : "bg-background"}`}>
          <div className="min-w-0 flex-1"><span className="block break-words font-semibold">{personName(p, lang)}</span><span dir="ltr" className="block break-all text-xs font-normal text-muted-foreground">{p.email}</span><span className="mt-1 block text-xs font-normal text-muted-foreground">{t(p.is_active ? "active" : "suspended")} · {data.access.filter(a => a.user_id === p.id).length} {t("access_granted")}</span></div>
        </Button>)}{!profiles.length && <p className="py-8 text-center text-sm text-muted-foreground">{t("access_empty")}</p>}</div>
      </section>
      <section className="min-w-0" aria-label={t("access_edit")}>
        {user ? <><div className="mb-5 border-b pb-5"><h2 className="break-words text-xl font-semibold text-primary">{personName(user, lang)}</h2><p dir="ltr" className="mt-1 break-all text-sm text-muted-foreground">{user.email}</p><span className={`mt-2 inline-block text-xs ${user.is_active ? "text-accent-brand" : "text-destructive"}`}>{t(user.is_active ? "active" : "suspended")}</span></div>
          <div className="divide-y">{systems.map(system => {
            const membership = data.access.find(a => a.user_id === user.id && a.system_id === system.id);
            return <div key={system.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 py-5 sm:grid-cols-[minmax(0,1fr)_220px]" data-system={system.code}>
              <div className="min-w-0 flex-1"><h3 className="font-semibold">{systemName(system.code)}</h3><span className="text-xs text-muted-foreground">{t(membership ? "access_enabled" : "access_none")}</span></div>
              <div className="col-span-2 grid w-full grid-cols-[minmax(0,1fr)_16px_36px] items-center gap-3 sm:col-span-1">
                <NativeSelect aria-label={`${t("access_role")} — ${systemName(system.code)}`} disabled={!membership || !!busy} value={membership?.role ?? "employee"} onChange={e => update(system.id, e.target.value as Role)}>{ROLES.map(role => <option key={role} value={role}>{t(`access_system_${role}` as TKey)}</option>)}</NativeSelect>
                <span className="h-4 w-4">{busy === system.id && <Loader2 className="h-4 w-4 animate-spin text-accent-brand" />}</span>
                <Switch aria-label={`${t("access_enabled")} — ${systemName(system.code)}`} checked={!!membership} disabled={!!busy} onCheckedChange={enabled => enabled ? update(system.id, "employee") : setRevoke(system.id)} />
              </div>
            </div>;
          })}</div></> : <p className="py-10 text-muted-foreground">{t("access_choose")}</p>}
      </section>
    </div>
    <Dialog open={!!revoke} onOpenChange={open => !open && !busy && setRevoke(null)}><DialogContent><DialogHeader><DialogTitle>{t("access_revoke_title")}</DialogTitle></DialogHeader><p className="text-sm">{t("access_revoke_confirm")}</p><p className="font-semibold">{personName(user, lang)} · {systemName(data.systems.find(s => s.id === revoke)?.code ?? "tasks")}</p><DialogFooter><Button variant="outline" disabled={!!busy} onClick={() => setRevoke(null)}>{t("cancel")}</Button><Button variant="destructive" disabled={!!busy} onClick={() => revoke && update(revoke, null)}>{t("access_revoke")}</Button></DialogFooter></DialogContent></Dialog>
  </div>;
}