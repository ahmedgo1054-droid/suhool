import { Link } from '@tanstack/react-router';
import { ClipboardList, Package, ShoppingCart, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/lib/i18n';
export function AdminServicesNav(){const {t}=useI18n();return <nav aria-label={t('portal_admin_services')} className="mb-6 flex gap-2 overflow-x-auto border-b pb-4">
 <Button variant="ghost" asChild><Link to="/admin-services" activeProps={{className:'bg-accent text-accent-foreground'}} activeOptions={{exact:true}}><ClipboardList className="h-4 w-4"/>{t('ar_title')}</Link></Button>
 <Button variant="ghost" asChild><Link to="/admin-services/assets" activeProps={{className:'bg-accent text-accent-foreground'}}><Package className="h-4 w-4"/>{t('ops_assets')}</Link></Button>
 <Button variant="ghost" asChild><Link to="/admin-services/purchases" activeProps={{className:'bg-accent text-accent-foreground'}}><ShoppingCart className="h-4 w-4"/>{t('ops_purchases')}</Link></Button>
 <Button variant="ghost" asChild><Link to="/admin-services/permissions" activeProps={{className:'bg-accent text-accent-foreground'}}><ShieldCheck className="h-4 w-4"/>{t('ops_permissions')}</Link></Button>
 </nav>}
