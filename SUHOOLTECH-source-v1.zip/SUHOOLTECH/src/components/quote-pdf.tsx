import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Download, FileText, Loader2, Printer } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { translate, useI18n, type Lang, type TKey } from "@/lib/i18n";
import type { Database } from "@/integrations/supabase/types";
import logo from "@/assets/suhool-logo.png.asset.json";
import mark from "@/assets/suhool-mark.png.asset.json";

type Tables = Database["public"]["Tables"];
type Quote = Tables["quotations"]["Row"];
type Item = Tables["quotation_items"]["Row"];
type Customer = Tables["customers"]["Row"];
type Company = Tables["company_settings"]["Row"];

export type QuoteDoc = {
  quote: Quote;
  items: Item[];
  customer: Customer | null;
  company: Company | null;
  frozen: boolean;
};

/** Issued quotations render from the immutable snapshot; drafts render live data. */
export function buildQuoteDoc(quote: Quote, items: Item[], customer: Customer | null, company: Company | null): QuoteDoc {
  const snap = quote.snapshot as null | { company?: Company; customer?: Customer; items?: Item[]; quotation?: Quote };
  if (snap && snap.quotation) {
    const q = snap.quotation;
    return {
      quote: { ...quote, subtotal: q.subtotal, discount_total: q.discount_total, vat_rate: q.vat_rate, vat_amount: q.vat_amount,
        grand_total: q.grand_total, payment_terms: q.payment_terms, notes: q.notes, valid_until: q.valid_until, issue_date: q.issue_date },
      items: snap.items ?? [],
      customer: snap.customer ?? null,
      company: snap.company ?? null,
      frozen: true,
    };
  }
  return { quote, items, customer, company, frozen: false };
}

// A4 at 96 dpi
const PAGE_W = 794;
const PAGE_H = 1123;
const FIRST_CAP = 18;
const NEXT_CAP = 25;
const SUMMARY_ROWS = 13; // rows of space the totals/terms/signature block needs

function paginate(items: Item[]): { rows: Item[]; summary: boolean }[] {
  const pages: { rows: Item[]; summary: boolean }[] = [];
  let i = 0;
  let cap = FIRST_CAP;
  do {
    pages.push({ rows: items.slice(i, i + cap), summary: false });
    i += cap;
    cap = NEXT_CAP;
  } while (i < items.length);
  const last = pages[pages.length - 1]!;
  const lastCap = pages.length === 1 ? FIRST_CAP : NEXT_CAP;
  if (lastCap - last.rows.length >= SUMMARY_ROWS) last.summary = true;
  else pages.push({ rows: [], summary: true });
  return pages;
}

function fmtMoney(n: unknown, lang: Lang) {
  return Number(n ?? 0).toLocaleString(lang === "ar" ? "ar-SA" : "en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtNum(n: unknown, lang: Lang) {
  return Number(n ?? 0).toLocaleString(lang === "ar" ? "ar-SA" : "en-US", { maximumFractionDigits: 3 });
}
function fmtD(d: string | null | undefined, lang: Lang) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString(lang === "ar" ? "ar-SA-u-ca-gregory" : "en-GB");
}

function QuoteDocument({ doc, lang, refPrefix }: { doc: QuoteDoc; lang: Lang; refPrefix?: string }) {
  const t = (k: TKey) => translate(lang, k);
  const dir = lang === "ar" ? "rtl" : "ltr";
  const { quote, items, customer: c, company: co } = doc;
  const pages = paginate(items);
  const ref = `${co?.quote_prefix ?? refPrefix ?? "Q-"}${quote.quote_no}`;
  const net = Number(quote.subtotal) - Number(quote.discount_total);
  const issued = !["DRAFT", "PENDING_APPROVAL"].includes(quote.status);
  const companyName = lang === "ar" ? co?.name_ar : co?.name_en;
  const companyAddr = lang === "ar" ? co?.address_ar : co?.address_en;
  const custName = c ? (lang === "ar" ? c.name_ar : c.name_en || c.name_ar) : "—";
  const terms = lang === "ar" ? co?.terms_ar : co?.terms_en;
  const validityDays = quote.valid_until && quote.issue_date
    ? Math.round((new Date(quote.valid_until).getTime() - new Date(quote.issue_date).getTime()) / 86400000) : null;

  return (
    <>
      {pages.map((p, pi) => (
        <div key={pi} dir={dir} lang={lang} className="quote-pdf-page relative overflow-hidden bg-background text-foreground"
          style={{ width: PAGE_W, height: PAGE_H, fontFamily: "'IBM Plex Sans Arabic','IBM Plex Sans',sans-serif", fontSize: 11 }}>
          {/* watermark */}
          <img src={mark.url} alt="" crossOrigin="anonymous" className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.05]" style={{ width: 460 }} />
          {!issued && (
            <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 -rotate-[30deg] text-[110px] font-bold text-destructive opacity-[0.08]">{t("draft_watermark")}</div>
          )}
          <div className="h-2 w-full bg-primary" />
          <div className="h-1 w-full bg-accent-brand" />

          <div className="relative flex h-[calc(100%-12px)] flex-col px-12 pb-6 pt-6">
            {/* header */}
            <div className="flex items-start justify-between gap-6 border-b border-border pb-4">
              <img src={logo.url} alt="SUHOOLTECH" crossOrigin="anonymous" style={{ height: 64 }} className="w-auto object-contain" />
              <div className="text-end leading-relaxed">
                <p className="text-sm font-bold text-primary">{companyName}</p>
                {companyAddr && <p className="text-muted-foreground">{companyAddr}</p>}
                {co?.cr_no && <p className="text-muted-foreground">{t("cr_no")}: <span dir="ltr">{co.cr_no}</span></p>}
                {co?.vat_no && <p className="text-muted-foreground">{t("vat_no")}: <span dir="ltr">{co.vat_no}</span></p>}
                {(co?.phone || co?.email) && <p className="text-muted-foreground" dir="ltr">{[co?.phone, co?.email].filter(Boolean).join(" · ")}</p>}
              </div>
            </div>

            {pi === 0 ? (
              <>
                <div className="mt-5 flex items-end justify-between">
                  <h1 className="text-2xl font-bold text-primary">{t("pdf_title")}</h1>
                  {doc.frozen && <p className="text-[9px] text-muted-foreground">{t("snapshot_note")}</p>}
                </div>
                <div className="mt-3 grid grid-cols-2 gap-4">
                  <div className="rounded-md border border-border p-3">
                    <p className="mb-1 text-[10px] font-semibold uppercase text-accent-brand">{t("pdf_bill_to")}</p>
                    <p className="text-sm font-bold">{custName}</p>
                    {c?.contact_name && <p>{t("contact_name")}: {c.contact_name}</p>}
                    {c?.address && <p>{c.address}</p>}
                    {c?.vat_no && <p>{t("vat_no")}: <span dir="ltr">{c.vat_no}</span></p>}
                    {c?.cr_no && <p>{t("cr_no")}: <span dir="ltr">{c.cr_no}</span></p>}
                    {(c?.phone || c?.email) && <p dir="ltr" className="text-end rtl:text-end">{[c?.phone, c?.email].filter(Boolean).join(" · ")}</p>}
                  </div>
                  <div className="rounded-md border border-border bg-muted/40 p-3">
                    <Meta k={t("quote_ref")} v={<span dir="ltr">{ref}</span>} />
                    <Meta k={t("issue_date")} v={fmtD(quote.issue_date, lang)} />
                    <Meta k={t("valid_until")} v={fmtD(quote.valid_until, lang)} />
                    {validityDays != null && <Meta k={t("validity")} v={`${fmtNum(validityDays, lang)} ${t("days")}`} />}
                  </div>
                </div>
              </>
            ) : (
              <p className="mt-4 text-xs text-muted-foreground">{t("pdf_title")} <span dir="ltr">{ref}</span> · {custName}</p>
            )}

            {/* items */}
            {(p.rows.length > 0 || (pi === 0 && items.length === 0)) && (
              <table className="mt-4 w-full border-collapse text-[10.5px]">
                <thead>
                  <tr className="bg-primary text-primary-foreground">
                    {(["item_no", "description", "unit", "qty", "unit_price", "discount", "line_total"] as TKey[]).map((k) => (
                      <th key={k} className={`px-2 py-2 font-semibold ${k === "description" ? "text-start" : "text-center"}`}>{t(k)}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {p.rows.map((it, ri) => {
                    const n = items.indexOf(it) + 1;
                    return (
                      <tr key={it.id ?? ri} className="border-b border-border odd:bg-muted/30" style={{ breakInside: "avoid" }}>
                        <td className="px-2 py-1.5 text-center">{fmtNum(n, lang)}</td>
                        <td className="px-2 py-1.5 text-start" style={{ maxWidth: 260 }}><div className="line-clamp-2">{it.description}</div></td>
                        <td className="px-2 py-1.5 text-center">{it.unit || "—"}</td>
                        <td className="px-2 py-1.5 text-center tabular-nums">{fmtNum(it.qty, lang)}</td>
                        <td className="px-2 py-1.5 text-center tabular-nums">{fmtMoney(it.unit_price, lang)}</td>
                        <td className="px-2 py-1.5 text-center tabular-nums">{fmtMoney(it.discount, lang)}</td>
                        <td className="px-2 py-1.5 text-center font-semibold tabular-nums">{fmtMoney(it.line_total, lang)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}

            {p.summary && (
              <div className="mt-5 space-y-4">
                <div className="flex justify-end">
                  <div className="w-72 rounded-md border border-border">
                    <Tot k={t("subtotal")} v={fmtMoney(quote.subtotal, lang)} cur={t("currency")} />
                    <Tot k={t("discount")} v={`- ${fmtMoney(quote.discount_total, lang)}`} cur={t("currency")} />
                    <Tot k={t("net_taxable")} v={fmtMoney(net, lang)} cur={t("currency")} />
                    <Tot k={`${t("vat")} (${fmtNum(quote.vat_rate, lang)}%)`} v={fmtMoney(quote.vat_amount, lang)} cur={t("currency")} />
                    <div className="flex justify-between bg-primary px-3 py-2 text-sm font-bold text-primary-foreground">
                      <span>{t("grand_total")}</span><span className="tabular-nums">{fmtMoney(quote.grand_total, lang)} {t("currency")}</span>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-[10px] leading-relaxed">
                  <div>
                    <p className="mb-1 font-semibold text-primary">{t("payment_terms")}</p>
                    <p className="whitespace-pre-wrap text-muted-foreground">{pickLang(quote.payment_terms, lang)}</p>
                    {quote.notes && <><p className="mb-1 mt-2 font-semibold text-primary">{t("notes")}</p><p className="whitespace-pre-wrap text-muted-foreground">{quote.notes}</p></>}
                  </div>
                  <div>
                    <p className="mb-1 font-semibold text-primary">{t("terms_conditions")}</p>
                    <p className="line-clamp-[8] whitespace-pre-wrap text-muted-foreground">{terms || "—"}</p>
                  </div>
                </div>
                <div>
                  <p className="mb-2 text-xs font-semibold text-primary">{t("authorization")}</p>
                  <div className="grid grid-cols-4 gap-3 text-[10px]">
                    {(["prepared_by", "approved_by", "customer_acceptance", "company_stamp"] as TKey[]).map((k) => (
                      <div key={k} className={`flex h-24 flex-col justify-between rounded-md border border-border p-2 ${k === "company_stamp" ? "border-dashed" : ""}`}>
                        <p className="font-semibold">{t(k)}</p>
                        {k !== "company_stamp" && (
                          <div className="space-y-2 text-muted-foreground">
                            <p className="border-b border-dotted border-border pb-1">{t("name")}:</p>
                            <p className="border-b border-dotted border-border pb-1">{t("signature")}:</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="mt-auto flex justify-between border-t border-border pt-2 text-[9px] text-muted-foreground">
              <span dir="ltr">{ref}</span>
              <span>{t("page")} {fmtNum(pi + 1, lang)} {t("of")} {fmtNum(pages.length, lang)}</span>
            </div>
          </div>
        </div>
      ))}
    </>
  );
}

/** Payment terms are stored as "arabic\nenglish" by default; show the matching line when possible. */
function pickLang(text: string, lang: Lang) {
  const lines = text.split("\n").filter((l) => l.trim());
  if (lines.length === 2) {
    const isAr = (s: string) => /[\u0600-\u06FF]/.test(s);
    const ar = lines.find(isAr), en = lines.find((l) => !isAr(l));
    if (ar && en) return lang === "ar" ? ar : en;
  }
  return text || "—";
}

function Meta({ k, v }: { k: string; v: React.ReactNode }) {
  return <div className="flex justify-between gap-2 py-0.5"><span className="text-muted-foreground">{k}</span><span className="font-semibold">{v}</span></div>;
}
function Tot({ k, v, cur }: { k: string; v: string; cur: string }) {
  return <div className="flex justify-between border-b border-border px-3 py-1.5"><span>{k}</span><span className="tabular-nums">{v} {cur}</span></div>;
}

export function QuotePdfButton({ doc }: { doc: QuoteDoc }) {
  const { t, lang: uiLang } = useI18n();
  const [open, setOpen] = useState(false);
  const [lang, setLang] = useState<Lang>(uiLang);
  const [busy, setBusy] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(0.7);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const fit = () => { if (wrapRef.current) setScale(Math.min(1, (wrapRef.current.clientWidth - 16) / PAGE_W)); };
    const id = setTimeout(fit, 50);
    window.addEventListener("resize", fit);
    return () => { clearTimeout(id); window.removeEventListener("resize", fit); };
  }, [open]);

  const fileName = `${doc.company?.quote_prefix ?? "Q-"}${doc.quote.quote_no}-${lang}.pdf`;

  async function download() {
    if (!printRef.current) return;
    setBusy(true);
    try {
      await document.fonts.ready;
      await Promise.all(Array.from(printRef.current.querySelectorAll("img")).map((i) => i.decode().catch(() => undefined)));
      const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import("html2canvas-pro"), import("jspdf")]);
      const pdf = new jsPDF({ unit: "mm", format: "a4", compress: true });
      const pages = Array.from(printRef.current.querySelectorAll<HTMLElement>(".quote-pdf-page"));
      for (let i = 0; i < pages.length; i++) {
        const canvas = await html2canvas(pages[i]!, { scale: 2, useCORS: true, backgroundColor: "#ffffff" });
        if (i > 0) pdf.addPage();
        pdf.addImage(canvas.toDataURL("image/jpeg", 0.92), "JPEG", 0, 0, 210, 297);
      }
      pdf.setProperties({ title: fileName });
      pdf.save(fileName);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Button size="sm" variant="outline" className="gap-2" onClick={() => setOpen(true)}>
        <FileText className="h-4 w-4" />{t("preview_pdf")}
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="flex max-h-[95vh] max-w-4xl flex-col gap-3">
          <DialogHeader><DialogTitle>{t("preview_pdf")}</DialogTitle></DialogHeader>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm text-muted-foreground">{t("pdf_lang")}:</span>
            {(["ar", "en"] as Lang[]).map((l) => (
              <Button key={l} size="sm" variant={lang === l ? "default" : "outline"} onClick={() => setLang(l)}>{l === "ar" ? "العربية" : "English"}</Button>
            ))}
            <div className="ms-auto flex gap-2">
              <Button size="sm" variant="outline" className="gap-2" onClick={() => window.print()}><Printer className="h-4 w-4" />{t("print")}</Button>
              <Button size="sm" className="gap-2" disabled={busy} onClick={download}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}{busy ? t("generating") : t("download_pdf")}
              </Button>
            </div>
          </div>
          <div ref={wrapRef} className="min-h-0 flex-1 overflow-auto rounded-md bg-muted p-2">
            <div style={{ zoom: scale, width: PAGE_W }} className="mx-auto space-y-4 [&>.quote-pdf-page]:shadow-md">
              <QuoteDocument doc={doc} lang={lang} />
            </div>
          </div>
        </DialogContent>
      </Dialog>
      {open && typeof document !== "undefined" && createPortal(
        <div ref={printRef} className="quote-print-root" aria-hidden>
          <QuoteDocument doc={doc} lang={lang} />
        </div>,
        document.body,
      )}
    </>
  );
}
