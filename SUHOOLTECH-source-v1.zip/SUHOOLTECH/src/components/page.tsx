import type { ReactNode } from "react";
import { Inbox, Loader2, Plus, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useI18n, type TKey } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function PageHeader({ title, action, onAction, children }: { title: TKey; action?: TKey | undefined; onAction?: () => void; children?: ReactNode }) {
  const { t } = useI18n();
  return (
    <div className="mb-6 grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 border-b pb-5 sm:items-center">
      <div className="min-w-0">
        <h1 className="break-words text-2xl font-semibold leading-snug text-primary">{t(title)}</h1>
      </div>
      <div className="flex items-center gap-2">
        {children}
        {action && onAction && (
          <Button onClick={onAction} className="gap-2" aria-label={t(action)} title={t(action)}>
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">{t(action)}</span>
          </Button>
        )}
      </div>
    </div>
  );
}

export function EmptyState({ label = "emptyTitle" }: { label?: TKey }) {
  const { t } = useI18n();
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-14 text-center">
      <div className="grid h-12 w-12 place-items-center rounded-lg border border-accent-brand/20 bg-accent-brand/10 text-accent-brand">
        <Inbox className="h-6 w-6" />
      </div>
      <p className="text-sm text-muted-foreground">{t(label)}</p>
    </div>
  );
}

export function Loading() {
  const { t } = useI18n();
  return (
    <div role="status" aria-label={t("loading")} className="flex justify-center py-14 text-muted-foreground">
      <Loader2 className="h-6 w-6 animate-spin" />
    </div>
  );
}

export function ErrorBox({ error }: { error: unknown }) {
  const { t } = useI18n();
  return <div role="alert" className="flex items-start gap-3 rounded-md border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><p className="min-w-0 break-words">{t("error_generic")}: {error instanceof Error ? error.message : String(error)}</p></div>;
}

/** Table wrapper that handles loading / empty / error states. */
export function DataTable({ columns, loading, error, empty, children }: { columns: TKey[]; loading?: boolean; error?: unknown; empty?: boolean; children?: ReactNode }) {
  const { t } = useI18n();
  return (
    <div className="overflow-hidden rounded-lg border bg-card shadow-surface">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              {columns.map((c) => (
                <TableHead key={c} className="whitespace-nowrap text-start">{t(c)}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading || error || empty ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="p-4">
                  {loading ? <Loading /> : error ? <ErrorBox error={error} /> : <EmptyState />}
                </TableCell>
              </TableRow>
            ) : children}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

export function FilterChips<T extends string>({ items, value, onChange, label }: { items: T[]; value: T | "all"; onChange: (v: T | "all") => void; label: (v: T) => string }) {
  const { t } = useI18n();
  const all: (T | "all")[] = ["all", ...items];
  return (
    <div className="mb-4 flex flex-wrap gap-2">
      {all.map((k) => (
        <Button
          key={k}
          type="button"
          variant="ghost"
          size="sm"
          aria-pressed={value === k}
          onClick={() => onChange(k)}
          className={cn(
            "rounded-md border text-xs font-medium",
            value === k ? "border-accent-brand/40 bg-accent text-accent-foreground hover:bg-accent" : "border-transparent bg-background text-muted-foreground hover:bg-muted",
          )}
        >
          {k === "all" ? t("filter_all") : label(k)}
        </Button>
      ))}
    </div>
  );
}

const tones: Record<string, string> = {
  NEW: "bg-muted text-foreground",
  ASSIGNED: "bg-primary/10 text-primary",
  IN_PROGRESS: "bg-accent-brand/15 text-accent-foreground",
  PENDING_REVIEW: "bg-chart-3/15 text-foreground",
  APPROVED: "bg-chart-4/15 text-chart-4",
  TRANSFERRED: "bg-primary/10 text-primary",
  RETURNED: "bg-destructive/10 text-destructive",
  CANCELLED: "bg-muted text-muted-foreground line-through",
  DRAFT: "bg-muted text-foreground",
  PENDING_APPROVAL: "bg-chart-3/15 text-foreground",
  ISSUED: "bg-primary/10 text-primary",
  ACCEPTED: "bg-chart-4/15 text-chart-4",
  REJECTED: "bg-destructive/10 text-destructive",
  EXPIRED: "bg-muted text-muted-foreground",
};

export function StatusBadge({ status, kind }: { status: string; kind: "task" | "quote" }) {
  const { t } = useI18n();
  const key = `${kind === "task" ? "s" : "q"}_${status}` as TKey;
  return <span className={cn("inline-flex whitespace-nowrap rounded-md px-2 py-0.5 text-xs font-medium", tones[status])}>{t(key)}</span>;
}

export function Field({ label, children, className }: { label: TKey; children: ReactNode; className?: string }) {
  const { t } = useI18n();
  return (
    <div className={cn("space-y-1.5", className)}>
      <Label>{t(label)}</Label>
      {children}
    </div>
  );
}

/** Native select styled like the input; reliable inside dialogs and RTL. */
export function NativeSelect({ className, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={cn(
        "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/30 focus-visible:border-ring disabled:bg-muted disabled:opacity-60",
        className,
      )}
    />
  );
}
