import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { personName, useMe, type Role } from "@/lib/data";
import type { ReactNode } from "react";
import {
  Grid2X2, LayoutDashboard, ListChecks, Users, Building2, Contact, FileText, Bell, BarChart3, Settings, Languages, Search, LogOut, ShieldCheck, LockKeyhole,
} from "lucide-react";
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarHeader,
  SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, useSidebar,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useI18n, type TKey } from "@/lib/i18n";
import logo from "@/assets/suhool-logo.png.asset.json";
import mark from "@/assets/suhool-mark.png.asset.json";

type Item = { key: TKey; to: string; icon: typeof LayoutDashboard; roles?: Role[] };
const groups: { label: TKey; items: Item[] }[] = [
  { label: "nav_main", items: [
     { key: "portal", to: "/", icon: Grid2X2 },
    { key: "notifications", to: "/notifications", icon: Bell },
  ] },
  { label: "nav_work", items: [
    { key: "tasks", to: "/tasks", icon: ListChecks },
    { key: "hr_overview", to: "/hr", icon: Users },
    { key: "docs_title", to: "/docs", icon: FileText },
    { key: "portal_admin_services", to: "/admin-services", icon: Building2 },
    { key: "portal_vault", to: "/vault", icon: LockKeyhole },
  ] },
  { label: "nav_sales", items: [
    { key: "customers", to: "/customers", icon: Contact, roles: ["admin", "sales", "manager"] },
    { key: "quotations", to: "/quotations", icon: FileText, roles: ["admin", "sales", "manager"] },
  ] },
  { label: "nav_admin", items: [
    { key: "access_title", to: "/system-access", icon: ShieldCheck, roles: ["admin"] },
    { key: "employees", to: "/employees", icon: Users, roles: ["admin"] },
    { key: "departments", to: "/departments", icon: Building2, roles: ["admin", "manager"] },
    { key: "reports", to: "/reports", icon: BarChart3, roles: ["admin", "manager"] },
    { key: "settings", to: "/settings", icon: Settings, roles: ["admin"] },
  ] },
];

function AppSidebar() {
  const { t, dir, lang } = useI18n();
  const { state, isMobile, setOpenMobile } = useSidebar();
  const { data: me } = useMe();
  const navigate = useNavigate();
  const can = (it: Item) => !it.roles || it.roles.some((r) => me?.roles.includes(r));
  const visible = groups.map((g) => ({ ...g, items: g.items.filter(can) })).filter((g) => g.items.length);
  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/login" });
  }
  const path = useRouterState({ select: (r) => r.location.pathname });
  const active = (to: string) => (to === "/" ? path === "/" : path.startsWith(to));
  return (
    <Sidebar collapsible="icon" side={dir === "rtl" ? "right" : "left"}>
      <SidebarHeader className="border-b border-sidebar-border px-4 py-5">
        {state === "collapsed" ? (
          <img src={mark.url} alt={t("brand")} className="mx-auto h-8 w-8 object-contain" />
        ) : (
          <Link to="/" aria-label={t("portal")}><img src={logo.url} alt={t("portal_brand")} className="h-14 w-full object-contain" /></Link>
        )}
      </SidebarHeader>
      <SidebarContent className="gap-3 py-4">
        {visible.map((g) => (
          <SidebarGroup key={g.label}>
            <SidebarGroupLabel className="px-3 text-xs font-medium text-muted-foreground">{t(g.label)}</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu className="gap-1">
                {g.items.map((it) => (
                  <SidebarMenuItem key={it.to}>
                    <SidebarMenuButton className="h-10 rounded-md px-3 data-[active=true]:font-semibold data-[active=true]:shadow-sm" asChild isActive={active(it.to)} tooltip={t(it.key)}>
                      <Link to={it.to} onClick={() => isMobile && setOpenMobile(false)}>
                        <it.icon className="h-4 w-4" />
                        <span>{t(it.key)}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
      <SidebarFooter className="border-t border-sidebar-border">
        <SidebarMenu>
          <SidebarMenuItem>
            {state !== "collapsed" && me && (
              <div className="flex min-w-0 items-center gap-3 px-2 py-3">
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-accent font-semibold text-accent-foreground">{personName(me.profile, lang).slice(0, 1)}</div>
                <div className="min-w-0"><p className="truncate text-sm font-medium">{personName(me.profile, lang)}</p>
                <p className="truncate text-xs text-muted-foreground">{me.roles.map((r) => t(`r_${r}` as TKey)).join(lang === "ar" ? "، " : ", ")}</p></div>
              </div>
            )}
            <SidebarMenuButton tooltip={t("logout")} onClick={signOut}>
              <LogOut className="h-4 w-4" />
              <span>{t("logout")}</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { t, toggle, dir } = useI18n();
  const path = useRouterState({ select: r => r.location.pathname });
  const current = groups.flatMap(g => g.items).filter(it => it.to !== "/" && path.startsWith(it.to)).sort((a,b) => b.to.length - a.to.length)[0];
  const { data: me } = useMe();
  const { data: unread = 0 } = useQuery({
    queryKey: ["unread", me?.user.id],
    enabled: !!me,
    refetchInterval: 60_000,
    queryFn: async () => {
      const { count } = await supabase.from("notifications").select("id", { count: "exact", head: true }).is("read_at", null);
      return count ?? 0;
    },
  });
  return (
    <SidebarProvider>
      <div dir={dir} className="app-workspace flex min-h-screen w-full bg-workspace">
        <AppSidebar />
        <SidebarInset className="min-w-0 bg-workspace">
          <header className="sticky top-0 z-10 flex h-16 items-center gap-2 border-b bg-background/95 px-3 backdrop-blur sm:gap-4 sm:px-6">
            <SidebarTrigger />
            <Button variant="ghost" size="sm" asChild>
              <Link to="/" aria-label={t("portal")}><Grid2X2 className="h-4 w-4" /><span className="hidden sm:inline">{t("portal")}</span></Link>
            </Button>
            {current && <div className="hidden min-w-0 items-center gap-4 sm:flex"><span className="h-5 border-s" /><span className="truncate text-sm font-medium text-muted-foreground">{t(current.key)}</span></div>}
            <div className="ms-auto flex items-center gap-2">
              <Button variant="ghost" size="icon" asChild aria-label={t("notifications")}>
                <Link to="/notifications" className="relative">
                  <Bell className="h-4 w-4" />
                  {unread > 0 && <span className="absolute -end-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-destructive px-1 text-[10px] text-destructive-foreground">{unread}</span>}
                </Link>
              </Button>
              <Button variant="outline" size="sm" onClick={toggle} className="gap-2">
                <Languages className="h-4 w-4" />
                {t("switchLang")}
              </Button>
            </div>
          </header>
          <main className="mx-auto w-full max-w-[1600px] flex-1 p-4 sm:p-6 lg:p-8">{children}</main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
