import { useEffect, useRef, useState } from 'react';
import { useSuspenseQuery } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { LockKeyhole, Plus, Eye, EyeOff, Copy, Star, Pencil, Trash2, ShieldCheck, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useI18n, type TKey } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Field, PageHeader, NativeSelect, EmptyState } from '@/components/page';
import { getPersonalVault, personalVaultAction, type PersonalVaultAction } from '@/lib/personal-vault.functions';
import { queryOptions } from '@tanstack/react-query';
import { emptySecret, generateStrongPassword, personalContext, personalSecretSchema, PERSONAL_IDLE_MS, type PersonalSecret, wrapSchema } from '@/lib/personal-vault';
import { decryptVaultValue, encryptVaultValue, generateRecoveryPassphrase, generateVaultKey, unwrapPersonalKey, wrapPersonalKey } from '@/lib/vault-crypto';
import type { Database } from '@/integrations/supabase/types';
import { CompanyVault } from '@/components/company-vault';

export const personalVaultQuery = queryOptions({ queryKey: ['personal-vault-key'], queryFn: () => getPersonalVault(), staleTime: 0, gcTime: 0 });
type Row = Database['public']['Tables']['personal_vault_records']['Row'];
type Listed = { row: Row; details: Omit<PersonalSecret, 'password'> };
type VerifiedKey = Awaited<ReturnType<typeof personalVaultAction>>['key'];
type Pending = { input: Omit<PersonalVaultAction,'code'|'factorId'>; done: (rows: Row[], verifiedKey: VerifiedKey) => Promise<void> };

export function PersonalVault() {
  const { t, dir } = useI18n();
  const { data: initial, refetch } = useSuspenseQuery(personalVaultQuery);
  const runAction = useServerFn(personalVaultAction);
  const key = useRef<CryptoKey | null>(null);
  const generation = useRef(0);
  const enrollment = useRef(false);
  const [ready, setReady] = useState(false);
  const [listed, setListed] = useState<Listed[]>([]);
  const [factor, setFactor] = useState('');
  const [qr, setQr] = useState('');
  const [passphrase, setPassphrase] = useState('');
  const [repeat, setRepeat] = useState('');
  const [recovery, setRecovery] = useState('');
  const [recoverMode, setRecoverMode] = useState(false);
  const [savedRecovery, setSavedRecovery] = useState(false);
  const [pending, setPending] = useState<Pending | null>(null);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [favorites, setFavorites] = useState(false);
  const [editor, setEditor] = useState<{ row?: Row; value: PersonalSecret } | null>(null);
  const [selected, setSelected] = useState<Listed | null>(null);
  const [revealed, setRevealed] = useState<string | null>(null);
  const [tab, setTab] = useState('personal');
  const lock = () => { generation.current++; key.current = null; setReady(false); setListed([]); setEditor(null); setSelected(null); setRevealed(null); setPassphrase(''); setRepeat(''); setRecovery(''); setPending(null); setCode(''); setQr(''); setBusy(false); if (enrollment.current) { enrollment.current = false; setFactor(''); } };
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    const reset = () => { clearTimeout(timer); timer = setTimeout(lock, PERSONAL_IDLE_MS); };
    const visibility = () => { if (document.hidden) lock(); };
    reset(); window.addEventListener('pointerdown', reset); window.addEventListener('keydown', reset); document.addEventListener('visibilitychange', visibility);
    return () => { clearTimeout(timer); key.current = null; generation.current++; window.removeEventListener('pointerdown', reset); window.removeEventListener('keydown', reset); document.removeEventListener('visibilitychange', visibility); };
  }, []);
  useEffect(() => { if (revealed === null) return; const timer = setTimeout(() => setRevealed(null), 30000); return () => clearTimeout(timer); }, [revealed]);
  useEffect(() => { let active = true; void supabase.auth.mfa.listFactors().then(({ data }) => { if (active) setFactor(data?.totp.find(f => f.status === 'verified')?.id ?? ''); }); return () => { active = false; }; }, []);
  const fail = (error: unknown) => toast.error(t(error instanceof Error && error.message === 'VAULT_CONFLICT' ? 'v_conflict' : 'v_failed'));
  async function decryptRows(rows: Row[]) {
    const currentKey = key.current; const currentGeneration = generation.current;
    if (!currentKey) return;
    const values: Listed[] = [];
    for (const row of rows) {
      const envelope = row.envelope as unknown as Parameters<typeof decryptVaultValue>[1];
      const plaintext = await decryptVaultValue(currentKey, envelope, personalContext(initial.ownerId, row.id));
      if (currentGeneration !== generation.current) return;
      const value = personalSecretSchema.parse(JSON.parse(plaintext));
      const { password: _password, ...details } = value;
      values.push({ row, details });
    }
    if (currentGeneration === generation.current) { setListed(values); setReady(true); }
  }
  async function enroll() {
    const gen = generation.current; setBusy(true);
    try {
      const existing = await supabase.auth.mfa.listFactors();
      if (gen !== generation.current) return;
      for (const item of existing.data?.all ?? []) {
        if (item.factor_type === 'totp' && item.status === 'unverified') await supabase.auth.mfa.unenroll({ factorId: item.id });
        if (gen !== generation.current) return;
      }
      const result = await supabase.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'SUHOOLTECH Vault' });
      if (result.error || !result.data) throw new Error();
      if (gen !== generation.current) return;
      enrollment.current = true; setFactor(result.data.id); setQr(result.data.totp.qr_code);
    } catch (error) { fail(error); } finally { if (gen === generation.current) setBusy(false); }
  }
  async function prepareUnlock() {
    const gen = generation.current; setBusy(true);
    try {
      if (!initial.hasKey) {
        if (passphrase !== repeat) { toast.error(t('v_mismatch')); return; }
        const newKey = await generateVaultKey(); if (gen !== generation.current) return; const phrase = generateRecoveryPassphrase();
        const [password_wrap, recovery_wrap] = await Promise.all([wrapPersonalKey(newKey, passphrase, initial.ownerId), wrapPersonalKey(newKey, phrase, initial.ownerId)]);
        if (gen !== generation.current) return;
        setRecovery(phrase); setSavedRecovery(false);
        setPending({ input: { action: 'setup', password_wrap, recovery_wrap }, done: async rows => { key.current = newKey; await decryptRows(rows); await refetch(); } });
      } else {
        if (recoverMode && passphrase !== repeat) { toast.error(t('v_mismatch')); return; }
        const recovering = recoverMode; const phrase = recovering ? recovery : passphrase; const newPassphrase = passphrase;
        setPending({ input: { action: 'unlock' }, done: async (rows, verifiedKey) => {
          if (!verifiedKey || gen !== generation.current) return;
          const newKey = await unwrapPersonalKey(wrapSchema.parse(recovering ? verifiedKey.recovery_wrap : verifiedKey.password_wrap), phrase, initial.ownerId);
          if (gen !== generation.current) return;
          if (recovering) {
            const password_wrap = await wrapPersonalKey(newKey, newPassphrase, initial.ownerId);
            if (gen !== generation.current) return;
            setPending({ input: { action: 'recover', revision: verifiedKey.revision, password_wrap }, done: async recoveredRows => { key.current = newKey; await decryptRows(recoveredRows); await refetch(); } });
          } else { key.current = newKey; await decryptRows(rows); await refetch(); }
        } });
      }
    } catch (error) { fail(error); } finally { if (gen === generation.current) setBusy(false); }
  }
  async function confirmAction() {
    if (!pending || !factor || !/^\d{6}$/.test(code)) return;
    const action = pending; const currentGeneration = generation.current; setBusy(true);
    try {
      const result = await runAction({ data: { ...action.input, factorId: factor, code } });
      if (currentGeneration !== generation.current) return;
      setPending(null); setCode('');
      await action.done(result.records, result.key); if (currentGeneration !== generation.current) return; enrollment.current = false; setQr(''); setPassphrase(''); setRepeat(''); setRecovery('');
    } catch (error) { if (currentGeneration === generation.current) fail(error); } finally { if (currentGeneration === generation.current) setBusy(false); }
  }
  async function loadSecret(item: Listed) {
    const currentKey = key.current; if (!currentKey) throw new Error();
    return personalSecretSchema.parse(JSON.parse(await decryptVaultValue(currentKey, item.row.envelope as unknown as Parameters<typeof decryptVaultValue>[1], personalContext(initial.ownerId,item.row.id))));
  }
  function secretAction(item: Listed, action: 'reveal'|'copy'|'edit') {
    const gen = generation.current;
    setPending({ input: { action: action === 'edit' ? 'reveal' : action, id: item.row.id }, done: async () => {
      const value = await loadSecret(item);
      if (gen !== generation.current) return;
      if (action === 'edit') { setSelected(null); setEditor({ row: item.row, value }); }
      else if (action === 'reveal') setRevealed(value.password);
      else { await navigator.clipboard.writeText(value.password); if (gen === generation.current) toast.success(t('v_copied')); }
    } });
  }
  async function saveEditor() {
    const currentKey = key.current; const gen = generation.current; if (!editor || !currentKey) return;
    try {
      const value = personalSecretSchema.parse(editor.value); const id = editor.row?.id ?? crypto.randomUUID();
      const envelope = await encryptVaultValue(currentKey, JSON.stringify(value), personalContext(initial.ownerId,id));
      if (gen !== generation.current) return;
      setPending({ input: { action: editor.row ? 'edit' : 'create', id, envelope, ...(editor.row ? { revision: editor.row.revision } : {}) }, done: async rows => { setEditor(null); await decryptRows(rows); } });
    } catch (error) { fail(error); }
  }
  async function favorite(item: Listed) {
    const gen = generation.current; const currentKey = key.current; if (!currentKey) return;
    try {
      const value = await loadSecret(item); if (gen !== generation.current) return; value.favorite = !value.favorite;
      const envelope = await encryptVaultValue(currentKey, JSON.stringify(value), personalContext(initial.ownerId,item.row.id));
      if (gen !== generation.current) return;
      setPending({ input: { action: 'favorite', id: item.row.id, revision: item.row.revision, envelope }, done: decryptRows });
    } catch (error) { fail(error); }
  }
  const categories = [...new Set(listed.map(r => r.details.category).filter(Boolean))];
  const filtered = listed.filter(r => (!favorites || r.details.favorite) && (!category || r.details.category === category) && [r.details.name,r.details.username,r.details.project,r.details.host].join(' ').toLowerCase().includes(search.toLowerCase()));
  const iconButton = (label: TKey, icon: React.ReactNode, onClick: () => void) => <Button variant="ghost" size="icon" title={t(label)} aria-label={t(label)} onClick={onClick}>{icon}</Button>;
  return <div className="mx-auto max-w-6xl space-y-5">
    <PageHeader title="portal_vault">{ready && <Button variant="outline" onClick={lock}><LockKeyhole className="h-4 w-4" />{t('v_lock')}</Button>}</PageHeader>
    <p role="status" className="border-s-2 border-accent-brand bg-accent p-3 text-sm text-accent-foreground">{t('v_trial')}</p>
    <Tabs value={tab} onValueChange={value => { lock(); setTab(value); }}><TabsList><TabsTrigger value="personal">{t('v_personal')}</TabsTrigger><TabsTrigger value="company">{t('v_company')}</TabsTrigger></TabsList>
      <TabsContent value="company"><CompanyVault /></TabsContent>
      <TabsContent value="personal" className="space-y-5">
        {!ready ? <section className="mx-auto max-w-md space-y-5 py-8">
          <div className="flex items-center gap-3"><LockKeyhole className="h-9 w-9 text-accent-brand" /><div><h2 className="text-xl font-semibold">{t(initial.hasKey ? 'v_locked' : 'v_setup')}</h2><p className="text-sm text-muted-foreground">{t('v_private')}</p></div></div>
          {!factor && <Button variant="outline" disabled={busy} onClick={enroll}><ShieldCheck className="h-4 w-4" />{t('v_mfa_enroll')}</Button>}
          {qr && <div className="space-y-3"><p className="text-sm">{t('v_mfa_scan')}</p><img src={qr.startsWith('data:') ? qr : `data:image/svg+xml;charset=utf-8,${encodeURIComponent(qr)}`} alt={t('v_mfa')} className="mx-auto h-48 w-48" /></div>}
          {recoverMode && <Field label="v_recovery"><Input aria-label={t('v_recovery')} type="password" value={recovery} onChange={e=>setRecovery(e.target.value)} autoComplete="off" /></Field>}
          <Field label="v_passphrase"><Input aria-label={t('v_passphrase')} type="password" value={passphrase} onChange={e=>setPassphrase(e.target.value)} autoComplete="off" /></Field>
          {(!initial.hasKey || recoverMode) && <Field label="v_repeat"><Input aria-label={t('v_repeat')} type="password" value={repeat} onChange={e=>setRepeat(e.target.value)} autoComplete="off" /></Field>}
          <Button className="w-full" onClick={prepareUnlock} disabled={busy || !factor || passphrase.length < 12}>{t(initial.hasKey ? recoverMode ? 'v_recover' : 'v_unlock' : 'v_setup')}</Button>
          {initial.hasKey && <Button variant="ghost" onClick={()=>{setRecoverMode(!recoverMode); setPassphrase(''); setRepeat(''); setRecovery('');}}>{t(recoverMode ? 'v_unlock' : 'v_recover')}</Button>}
        </section> : <>
          <div className="flex flex-wrap items-center justify-between gap-3"><p className="text-sm text-muted-foreground">{t('v_count')}: <span className="font-semibold text-foreground">{listed.length}</span></p><Button onClick={()=>setEditor({ value: {...emptySecret} })}><Plus className="h-4 w-4" />{t('v_new')}</Button></div>
          <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_200px_auto]"><Input aria-label={t('search')} placeholder={t('search')} value={search} onChange={e=>setSearch(e.target.value)} /><NativeSelect aria-label={t('ops_category')} value={category} onChange={e=>setCategory(e.target.value)}><option value="">{t('filter_all')}</option>{categories.map(c=><option key={c}>{c}</option>)}</NativeSelect><Button variant={favorites ? 'secondary' : 'outline'} aria-pressed={favorites} onClick={()=>setFavorites(!favorites)}><Star className="h-4 w-4" />{t('v_favorites')}</Button></div>
          {filtered.length === 0 ? <EmptyState /> : <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{filtered.map(item=><article key={item.row.id} className="min-w-0 rounded-lg border bg-card p-5 shadow-surface"><div className="flex items-start gap-3"><LockKeyhole className="mt-1 h-5 w-5 shrink-0 text-accent-brand" /><div className="min-w-0 flex-1"><h3 className="break-words font-semibold">{item.details.name}</h3><p className="break-words text-sm text-muted-foreground">{item.details.category || '—'}</p></div>{iconButton('v_favorite',<Star className={`h-4 w-4 ${item.details.favorite ? 'fill-current text-accent-brand' : ''}`} />,()=>void favorite(item))}</div><p className="my-4 break-words text-sm">{item.details.username || '—'}</p><Button variant="outline" className="w-full" onClick={()=>{setSelected(item); setRevealed(null);}}>{t('v_record')}</Button></article>)}</div>}
        </>}
      </TabsContent>
    </Tabs>
    <Dialog open={!!selected} onOpenChange={open=>{if(!open){generation.current++;setSelected(null);setRevealed(null);setPending(null);setCode('');}}}><DialogContent dir={dir}><DialogHeader><DialogTitle>{selected?.details.name}</DialogTitle><DialogDescription>{t('v_private')}</DialogDescription></DialogHeader>{selected && <><dl className="grid gap-3 text-sm">{([['v_username','username'],['v_url','url'],['v_host','host'],['v_project','project'],['ops_category','category'],['v_review','reviewAt'],['notes','notes']] as const).map(([label,field])=><div key={field}><dt className="text-muted-foreground">{t(label)}</dt><dd className="whitespace-pre-wrap break-words">{selected.details[field] || '—'}</dd></div>)}</dl><div className="flex min-w-0 items-center gap-2 border-y py-3"><p className="min-w-0 flex-1 break-all font-mono">{revealed ?? '••••••••••••'}</p>{iconButton(revealed === null ? 'v_reveal':'v_hide',revealed === null ? <Eye className="h-4 w-4" />:<EyeOff className="h-4 w-4" />,()=>revealed === null ? secretAction(selected,'reveal'):setRevealed(null))}{iconButton('v_copy',<Copy className="h-4 w-4" />,()=>secretAction(selected,'copy'))}</div><div className="flex justify-end gap-2">{iconButton('v_edit_secret',<Pencil className="h-4 w-4" />,()=>secretAction(selected,'edit'))}{iconButton('delete',<Trash2 className="h-4 w-4 text-destructive" />,()=>setPending({input:{action:'delete',id:selected.row.id,revision:selected.row.revision},done:async rows=>{setSelected(null);setRevealed(null);await decryptRows(rows);}}))}</div></>}</DialogContent></Dialog>
    <Dialog open={!!editor} onOpenChange={open=>{if(!open){generation.current++;setEditor(null);setPending(null);setCode('');setBusy(false);}}}><DialogContent dir={dir}><DialogHeader><DialogTitle>{t(editor?.row ? 'v_edit_secret' : 'v_new')}</DialogTitle><DialogDescription>{t('v_private')}</DialogDescription></DialogHeader>{editor && <form onSubmit={e=>{e.preventDefault();void saveEditor();}} className="space-y-4"><div className="grid gap-4 sm:grid-cols-2">{([['name','name'],['ops_category','category'],['v_username','username'],['v_url','url'],['v_host','host'],['v_project','project'],['v_review','reviewAt']] as const).map(([label,field])=><Field key={field} label={label}><Input aria-label={t(label)} value={editor.value[field]} type={field==='reviewAt'?'date':'text'} required={field==='name'} autoComplete="off" onChange={e=>setEditor({...editor,value:{...editor.value,[field]:e.target.value}})} /></Field>)}</div><Field label="password"><div className="flex gap-2"><Input aria-label={t('password')} type="password" autoComplete="off" value={editor.value.password} onChange={e=>setEditor({...editor,value:{...editor.value,password:e.target.value}})} />{iconButton('v_generate',<RefreshCw className="h-4 w-4" />,()=>setEditor({...editor,value:{...editor.value,password:generateStrongPassword()}}))}</div></Field><Field label="notes"><Textarea aria-label={t('notes')} value={editor.value.notes} onChange={e=>setEditor({...editor,value:{...editor.value,notes:e.target.value}})} /></Field><Button type="submit" className="w-full">{t('save')}</Button></form>}</DialogContent></Dialog>
    <Dialog open={!!pending} onOpenChange={open=>{if(!open){generation.current++;setBusy(false);setPending(null);setCode('');setRecovery('');}}}><DialogContent dir={dir}><DialogHeader><DialogTitle>{t('v_reauth')}</DialogTitle><DialogDescription>{t(pending?.input.action==='delete'?'v_delete_confirm':'v_mfa')}</DialogDescription></DialogHeader>{pending?.input.action==='setup' && <><p className="text-sm">{t('v_recovery_warning')}</p><p className="select-all break-all rounded-md border bg-muted p-3 font-mono text-sm">{recovery}</p><label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={savedRecovery} onChange={e=>setSavedRecovery(e.target.checked)} />{t('v_recovery_saved')}</label></>}<Field label="v_code"><Input aria-label={t('v_code')} value={code} onChange={e=>setCode(e.target.value.replace(/\D/g,'').slice(0,6))} inputMode="numeric" autoComplete="one-time-code" maxLength={6} /></Field><Button disabled={busy || code.length!==6 || (pending?.input.action==='setup'&&!savedRecovery)} onClick={()=>void confirmAction()}>{t('v_verify')}</Button></DialogContent></Dialog>
  </div>;
}