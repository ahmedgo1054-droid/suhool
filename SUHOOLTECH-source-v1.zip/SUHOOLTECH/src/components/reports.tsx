import { useEffect, useMemo, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useQuery } from "@tanstack/react-query";
import { Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PageHeader, FilterChips } from "@/components/page";
import { supabase } from "@/integrations/supabase/client";
import { deptName, fmtDate, money, must, personName, useDepartments, useMe, useProfiles } from "@/lib/data";
import { useI18n, type TKey } from "@/lib/i18n";
import { hrQuery } from "@/lib/hr";
import { documentsQuery } from "@/lib/documents";
import { adminRequestsQuery } from "@/lib/admin-requests";
import { adminOpsQuery } from "@/lib/admin-ops";
import { companyVaultQuery } from "@/components/company-vault";
import logo from "@/assets/suhool-logo.png.asset.json";

type Table = { title: TKey; cols: TKey[]; rows: ReactNode[][]; foot?: ReactNode[] };
type Report = { key: TKey; kpis: { label: TKey; value: ReactNode }[]; breakdown: { label: string; count: number; value?: string | undefined }[]; tables: Table[] } | "denied" | null;

const systems = ["all", "tasks", "quotes", "hr", "docs", "requests", "assets", "purchases", "vault"] as const;
type Sys = (typeof systems)[number];
const opt = { retry: false, staleTime: 30_000 } as const;

export function ReportsCenter() {
  const { t, lang } = useI18n();
  const { data: me } = useMe();
  const { data: profiles = [] } = useProfiles();
  const { data: depts = [] } = useDepartments();
  const [sys, setSys] = useState<Sys>("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const tasks = useQuery({ queryKey: ["rp-tasks"], ...opt, queryFn: async () => must(await supabase.from("tasks").select("*").order("task_no")) });
  const quotes = useQuery({ queryKey: ["rp-quotes"], ...opt, enabled: !!me && (me.isAdmin || me.is("manager") || me.is("sales")), queryFn: async () => must(await supabase.from("quotations").select("*, customers(name_ar,name_en)").order("quote_no")) });
  const hr = useQuery({ ...hrQuery, ...opt });
  const docs = useQuery({ ...documentsQuery, ...opt });
  const reqs = useQuery({ ...adminRequestsQuery, ...opt });
  const ops = useQuery({ ...adminOpsQuery, ...opt });
  const vault = useQuery({ ...companyVaultQuery, ...opt });

  const inRange = (d: string | null | undefined) => {
    if (!d) return !from && !to;
    const x = d.slice(0, 10);
    return (!from || x >= from) && (!to || x <= to);
  };
  const who = (id: string | null | undefined, list: { id: string; full_name_ar: string; full_name_en: string; email?: string }[] = profiles) =>
    personName(list.find((p) => p.id === id) as never, lang);
  const pct = (a: number, b: number) => (b ? `${Math.round((a / b) * 100)}%` : "—");
  const groupBy = <T,>(rows: T[], key: (r: T) => string, label: (k: string) => string, val?: (r: T) => number) => {
    const m = new Map<string, T[]>();
    rows.forEach((r) => m.set(key(r), [...(m.get(key(r)) ?? []), r]));
    return [...m].map(([k, l]) => ({ label: label(k), count: l.length, value: val ? money(l.reduce((a, r) => a + val(r), 0), lang) : undefined }));
  };
  const tk = (k: string) => t(k as TKey) ?? k;
  const stateKey = (s: string) => (["ordered", "received", "available", "assigned", "maintenance", "retired"].includes(s) ? `ops_${s}` : `ar_${s}`);

  const reports = useMemo((): Record<Exclude<Sys, "all">, Report> => {
    const today = new Date().toISOString().slice(0, 10);
    const r: Partial<Record<Exclude<Sys, "all">, Report>> = {};
    // Tasks
    if (tasks.error) r.tasks = "denied";
    else if (tasks.data) {
      const l = tasks.data.filter((x) => inRange(x.created_at));
      const done = l.filter((x) => x.status === "APPROVED").length;
      const overdue = l.filter((x) => x.due_date && x.due_date < today && !["APPROVED", "CANCELLED"].includes(x.status));
      const people = profiles.map((p) => { const m = l.filter((x) => x.assignee_id === p.id); return { p, n: m.length, d: m.filter((x) => x.status === "APPROVED").length, ret: m.filter((x) => x.status === "RETURNED").length }; }).filter((x) => x.n);
      r.tasks = {
        key: "rp_tasks",
        kpis: [{ label: "rp_total", value: l.length }, { label: "rp_done", value: done }, { label: "rp_completion", value: pct(done, l.length) }, { label: "rp_overdue", value: overdue.length }],
        breakdown: groupBy(l, (x) => x.status, (k) => tk(`s_${k}`)),
        tables: [
          { title: "rp_perf", cols: ["rp_employee", "rp_total", "rp_done", "rp_returned", "rp_completion"], rows: people.map((x) => [personName(x.p, lang), x.n, x.d, x.ret, pct(x.d, x.n)]) },
          { title: "rp_details", cols: ["rp_no", "rp_subject", "rp_assignee", "rp_dept", "rp_priority", "rp_due", "rp_status"], rows: l.map((x) => [x.task_no, x.title, who(x.assignee_id), deptName(depts.find((d) => d.id === x.department_id), lang), tk(`p_${x.priority}`), fmtDate(x.due_date, lang), tk(`s_${x.status}`)]) },
        ],
      };
    }
    // Quotations
    if (quotes.error) r.quotes = "denied";
    else if (quotes.data) {
      const l = quotes.data.filter((x) => inRange(x.issue_date));
      const sum = l.reduce((a, x) => a + Number(x.grand_total), 0);
      const acc = l.filter((x) => x.status === "ACCEPTED");
      const cust = (x: (typeof l)[number]) => { const c = x.customers as { name_ar: string; name_en: string } | null; return c ? (lang === "ar" ? c.name_ar : c.name_en || c.name_ar) : "—"; };
      r.quotes = {
        key: "rp_quotes",
        kpis: [{ label: "rp_total", value: l.length }, { label: "rp_value", value: money(sum, lang) }, { label: "rp_avg", value: money(l.length ? sum / l.length : 0, lang) }, { label: "rp_accept_rate", value: pct(acc.length, l.length) }],
        breakdown: groupBy(l, (x) => x.status, (k) => tk(`q_${k}`), (x) => Number(x.grand_total)),
        tables: [{ title: "rp_details", cols: ["rp_no", "rp_date", "rp_customer", "rp_status", "rp_value"], rows: l.map((x) => [x.quote_no, fmtDate(x.issue_date, lang), cust(x), tk(`q_${x.status}`), money(x.grand_total, lang)]), foot: [t("rp_total"), "", "", "", money(sum, lang)] }],
      };
    } else if (me && !quotes.isFetching && !quotes.data) r.quotes = "denied";
    // HR
    if (hr.error) r.hr = "denied";
    else if (hr.data) {
      const h = hr.data;
      const lv = h.leaves.filter((x) => inRange(x.start_date));
      const at = h.attendance.filter((x) => inRange(x.work_date));
      const salary = h.permissions.view_salary;
      const emp = (id: string) => who(id, h.profiles);
      const typ = (id: string) => { const x = h.types.find((y) => y.id === id); return x ? (lang === "ar" ? x.name_ar : x.name_en) : "—"; };
      r.hr = {
        key: "rp_hr",
        kpis: [{ label: "rp_employees", value: h.employees.length }, { label: "rp_leaves", value: lv.length }, { label: "rp_days", value: lv.filter((x) => x.status === "approved").reduce((a, x) => a + (x.days ?? 0), 0) }, { label: "rp_late", value: at.reduce((a, x) => a + x.late_minutes, 0) }],
        breakdown: groupBy(lv, (x) => x.status, (k) => tk(stateKey(k))),
        tables: [
          { title: "rp_employees", cols: salary ? ["rp_no", "rp_employee", "rp_job", "rp_start", "rp_status", "rp_salary"] : ["rp_no", "rp_employee", "rp_job", "rp_start", "rp_status"], rows: h.employees.map((e) => { const f = h.finances.find((x) => x.id === e.id); const row: ReactNode[] = [e.employee_no, emp(e.id), e.job_title, fmtDate(e.start_date, lang), e.employment_status]; if (salary) row.push(f ? money(Number(f.salary) + Number(f.allowances), lang) : "—"); return row; }) },
          { title: "rp_leaves", cols: ["rp_employee", "rp_type", "rp_from", "rp_to", "rp_days", "rp_status"], rows: lv.map((x) => [emp(x.employee_id), typ(x.type_id), fmtDate(x.start_date, lang), fmtDate(x.end_date, lang), x.days ?? "—", tk(stateKey(x.status))]) },
          { title: "rp_attendance", cols: ["rp_date", "rp_employee", "rp_check_in", "rp_check_out", "rp_late", "rp_status"], rows: at.map((x) => [fmtDate(x.work_date, lang), emp(x.employee_id), x.check_in ? new Date(x.check_in).toLocaleTimeString(lang === "ar" ? "ar-SA" : "en-GB", { hour: "2-digit", minute: "2-digit" }) : "—", x.check_out ? new Date(x.check_out).toLocaleTimeString(lang === "ar" ? "ar-SA" : "en-GB", { hour: "2-digit", minute: "2-digit" }) : "—", x.late_minutes, tk(`hr_${x.status}`)]) },
        ],
      };
    }
    // Documents
    if (docs.error) r.docs = "denied";
    else if (docs.data) {
      const d = docs.data;
      const l = d.documents.filter((x) => inRange(x.created_at));
      const cat = (id: string | null) => { const c = d.categories.find((x) => x.id === id); return c ? (lang === "ar" ? c.name_ar : c.name_en) : t("docs_uncategorized"); };
      r.docs = {
        key: "rp_docs",
        kpis: [{ label: "rp_total", value: l.length }, { label: "docs_approved", value: l.filter((x) => x.status === "approved").length }, { label: "docs_in_review", value: l.filter((x) => x.status === "in_review").length }, { label: "docs_draft", value: l.filter((x) => x.status === "draft").length }],
        breakdown: groupBy(l, (x) => x.category_id ?? "", (k) => cat(k || null)),
        tables: [{ title: "rp_details", cols: ["rp_subject", "rp_category", "rp_owner", "rp_date", "rp_status"], rows: l.map((x) => [x.title, cat(x.category_id), who(x.owner_id, d.profiles), fmtDate(x.updated_at, lang), tk(`docs_${x.status}`)]) }],
      };
    }
    // Requests
    if (reqs.error) r.requests = "denied";
    else if (reqs.data) {
      const q = reqs.data;
      const l = q.requests.filter((x) => inRange(x.created_at));
      const typ = (id: string) => { const x = q.types.find((y) => y.id === id); return x ? (lang === "ar" ? x.name_ar : x.name_en) : "—"; };
      r.requests = {
        key: "rp_requests",
        kpis: [{ label: "rp_total", value: l.length }, { label: "ar_pending", value: l.filter((x) => x.status === "pending").length }, { label: "ar_approved", value: l.filter((x) => x.status === "approved").length }, { label: "ar_completed", value: l.filter((x) => x.status === "completed").length }],
        breakdown: groupBy(l, (x) => x.type_id, typ),
        tables: [{ title: "rp_details", cols: ["rp_no", "rp_subject", "rp_type", "rp_requester", "rp_priority", "rp_date", "rp_status"], rows: l.map((x) => [x.request_no, x.title, typ(x.type_id), who(x.requester_id, q.profiles), tk(`p_${x.priority}`), fmtDate(x.created_at, lang), tk(stateKey(x.status))]) }],
      };
    }
    // Assets + purchases
    if (ops.error) { r.assets = "denied"; r.purchases = "denied"; }
    else if (ops.data) {
      const o = ops.data;
      const active = (id: string) => o.custody.find((c) => c.asset_id === id && !c.returned_at);
      r.assets = {
        key: "rp_assets",
        kpis: [{ label: "rp_total", value: o.assets.length }, { label: "ops_assigned", value: o.assets.filter((x) => x.status === "assigned").length }, { label: "ops_available", value: o.assets.filter((x) => x.status === "available").length }, { label: "ops_maintenance", value: o.assets.filter((x) => x.status === "maintenance").length }],
        breakdown: groupBy(o.assets, (x) => x.category || "—", (k) => k),
        tables: [
          { title: "rp_details", cols: ["ops_asset_tag", "rp_subject", "rp_category", "ops_serial", "ops_location", "rp_custodian", "rp_status"], rows: o.assets.map((x) => [x.asset_tag, x.name, x.category, x.serial_no || "—", x.location || "—", active(x.id) ? who(active(x.id)!.custodian_id, o.profiles) : "—", tk(`ops_${x.status}`)]) },
          { title: "ops_custody", cols: ["ops_asset_tag", "rp_custodian", "ops_assigned_at", "ops_returned_at", "ops_condition"], rows: o.custody.filter((c) => inRange(c.assigned_at)).map((c) => [o.assets.find((a) => a.id === c.asset_id)?.asset_tag ?? "—", who(c.custodian_id, o.profiles), fmtDate(c.assigned_at, lang), fmtDate(c.returned_at, lang), tk(`ops_${c.return_condition ?? c.issue_condition}`)]) },
        ],
      };
      const pl = o.purchases.filter((x) => inRange(x.created_at));
      const sum = pl.reduce((a, x) => a + Number(x.total), 0);
      r.purchases = {
        key: "rp_purchases",
        kpis: [{ label: "rp_total", value: pl.length }, { label: "rp_value", value: money(sum, lang) }, { label: "ops_received", value: pl.filter((x) => x.status === "received").length }, { label: "ar_pending", value: pl.filter((x) => x.status === "pending").length }],
        breakdown: groupBy(pl, (x) => x.status, (k) => tk(stateKey(k)), (x) => Number(x.total)),
        tables: [{ title: "rp_details", cols: ["rp_no", "rp_subject", "rp_requester", "rp_supplier", "rp_date", "rp_status", "rp_value"], rows: pl.map((x) => [x.purchase_no, x.title, who(x.requester_id, o.profiles), x.supplier || "—", fmtDate(x.created_at, lang), tk(stateKey(x.status)), money(x.total, lang)]), foot: [t("rp_total"), "", "", "", "", "", money(sum, lang)] }],
      };
    }
    if (vault.error) r.vault = "denied";
    else if (vault.data) {
      const l = vault.data.records.filter(x => inRange(x.updated_at));
      r.vault = { key: "rp_vault", kpis: [{ label: "rp_total", value: l.length }], breakdown: groupBy(l, x => x.category || "—", k => k), tables: [{ title: "rp_details", cols: ["name", "ops_category", "v_project", "v_device", "v_review", "password"], rows: l.map(x => [x.name, x.category, x.project, x.device_type, fmtDate(x.review_at, lang), t("v_secret_hidden")]) }] };
    }
    return r as Record<Exclude<Sys, "all">, Report>;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tasks.data, tasks.error, quotes.data, quotes.error, quotes.isFetching, hr.data, hr.error, docs.data, docs.error, reqs.data, reqs.error, ops.data, ops.error, vault.data, vault.error, profiles, depts, lang, from, to, me]);

  const keys = (sys === "all" ? systems.slice(1) : [sys]) as Exclude<Sys, "all">[];
  const visible = keys.map((k) => [k, reports[k]] as const).filter(([, v]) => v && (sys !== "all" || v !== "denied"));
  const period = from || to ? `${from ? fmtDate(from, lang) : "…"} — ${to ? fmtDate(to, lang) : "…"}` : t("rp_all_time");
  const sheet = (
    <div className="report-sheet mx-auto max-w-[210mm] rounded-lg border bg-card text-card-foreground shadow-surface" dir={lang === "ar" ? "rtl" : "ltr"}>
      {visible.map(([k, rep]) => (
        <ReportSection key={k} rep={rep!} period={period} by={personName(me?.profile, lang)} logo={logo.url} />
      ))}
      {!visible.length && <p className="p-10 text-center text-sm text-muted-foreground">{t("rp_no_data")}</p>}
    </div>
  );

  return (
    <div>
      <PageHeader title="rp_title" />
      <p className="-mt-3 mb-5 text-sm text-muted-foreground">{t("rp_sub")}</p>
      <div className="mb-5 flex flex-col gap-4 rounded-lg border bg-card p-4 shadow-surface lg:flex-row lg:items-end lg:justify-between">
        <div className="min-w-0 space-y-3">
          <FilterChips items={systems.slice(1) as Exclude<Sys, "all">[]} value={sys} onChange={(v) => setSys(v)} label={(s) => t(`rp_${s}` as TKey)} />
          <div className="grid grid-cols-2 gap-3 sm:max-w-md">
            <label className="space-y-1 text-xs text-muted-foreground">{t("rp_from")}<Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
            <label className="space-y-1 text-xs text-muted-foreground">{t("rp_to")}<Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></label>
          </div>
        </div>
        <Button onClick={() => window.print()} disabled={!visible.length}><Printer className="h-4 w-4" />{t("rp_print")}</Button>
      </div>
      <div className="overflow-x-auto">{sheet}</div>
      {mounted && createPortal(<div className="report-print-root">{sheet}</div>, document.body)}
    </div>
  );
}

function ReportSection({ rep, period, by, logo }: { rep: Exclude<Report, null>; period: string; by: string; logo: string }) {
  const { t, lang } = useI18n();
  if (rep === "denied") return <p className="report-section p-8 text-center text-sm text-muted-foreground">{t("rp_denied")}</p>;
  const total = rep.breakdown.reduce((a, b) => a + b.count, 0);
  return (
    <section className="report-section p-6 sm:p-8">
      <header className="overflow-hidden rounded-md border">
        <div className="flex items-center justify-between gap-4 bg-primary px-5 py-4 text-primary-foreground">
          <div className="min-w-0">
            <p className="text-xs opacity-80">SUHOOLTECH | سهول تيك</p>
            <h2 className="text-lg font-semibold">{t(rep.key)}</h2>
          </div>
          <div className="rounded bg-background px-2 py-1"><img src={logo} alt="SUHOOLTECH" className="h-9 w-auto" /></div>
        </div>
        <div className="h-1 bg-accent-brand" />
        <dl className="grid grid-cols-3 gap-2 bg-muted/50 px-5 py-2 text-xs">
          <div><dt className="text-muted-foreground">{t("rp_period")}</dt><dd className="font-medium">{period}</dd></div>
          <div><dt className="text-muted-foreground">{t("rp_generated")}</dt><dd className="font-medium">{fmtDate(new Date().toISOString(), lang)}</dd></div>
          <div><dt className="text-muted-foreground">{t("rp_by")}</dt><dd className="font-medium">{by}</dd></div>
        </dl>
      </header>

      <h3 className="mb-2 mt-6 border-s-4 border-accent-brand ps-2 text-sm font-semibold text-primary">{t("rp_summary")}</h3>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {rep.kpis.map((k) => (
          <div key={k.label} className="report-kpi rounded-md border bg-accent/40 p-3">
            <p className="text-xs text-muted-foreground">{t(k.label)}</p>
            <p className="mt-1 text-xl font-semibold tabular-nums text-primary">{k.value}</p>
          </div>
        ))}
      </div>

      {rep.breakdown.length > 0 && (
        <>
          <h3 className="mb-2 mt-6 border-s-4 border-accent-brand ps-2 text-sm font-semibold text-primary">{t("rp_status_summary")}</h3>
          <div className="space-y-2">
            {rep.breakdown.map((b) => (
              <div key={b.label} className="grid grid-cols-[8rem_minmax(0,1fr)_3rem_auto] items-center gap-3 text-xs">
                <span className="truncate">{b.label}</span>
                <span className="h-2 overflow-hidden rounded-full bg-muted"><span className="block h-full rounded-full bg-accent-brand" style={{ width: `${total ? (b.count / total) * 100 : 0}%` }} /></span>
                <span className="tabular-nums">{b.count}</span>
                <span className="tabular-nums text-muted-foreground">{b.value ?? (total ? `${Math.round((b.count / total) * 100)}%` : "")}</span>
              </div>
            ))}
          </div>
        </>
      )}

      {rep.tables.map((tb, i) => (
        <div key={i}>
          <h3 className="mb-2 mt-6 border-s-4 border-accent-brand ps-2 text-sm font-semibold text-primary">{t(tb.title)} <span className="text-xs font-normal text-muted-foreground">({tb.rows.length})</span></h3>
          {tb.rows.length ? (
            <table className="w-full border-collapse text-xs">
              <thead><tr className="bg-primary text-primary-foreground">{tb.cols.map((c) => <th key={c} className="px-2 py-2 text-start font-medium">{t(c)}</th>)}</tr></thead>
              <tbody>{tb.rows.map((r, j) => <tr key={j} className="border-b even:bg-muted/40">{r.map((c, n) => <td key={n} className="px-2 py-1.5 align-top">{c}</td>)}</tr>)}</tbody>
              {tb.foot && <tfoot><tr className="bg-accent font-semibold text-accent-foreground">{tb.foot.map((c, n) => <td key={n} className="px-2 py-2">{c}</td>)}</tr></tfoot>}
            </table>
          ) : <p className="rounded-md border border-dashed p-4 text-center text-xs text-muted-foreground">{t("rp_no_data")}</p>}
        </div>
      ))}

      <footer className="mt-8 flex justify-between border-t pt-2 text-[10px] text-muted-foreground">
        <span>{t("rp_confidential")}</span><span>SUHOOLTECH</span>
      </footer>
    </section>
  );
}
