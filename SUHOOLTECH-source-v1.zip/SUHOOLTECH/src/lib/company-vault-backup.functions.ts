import { createServerFn } from '@tanstack/react-start';
import { getRequestHeader, setResponseHeader } from '@tanstack/react-start/server';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { encryptVaultValue, decryptVaultValue } from '@/lib/vault-crypto';
import { envelopeSchema } from '@/lib/personal-vault';

const BACKUP_CONTEXT = 'company-kek-backup:v1';

async function backupKey(secret: string) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(secret));
  return crypto.subtle.importKey('raw', digest, 'AES-GCM', false, ['encrypt', 'decrypt']);
}

async function assertAdmin(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc('has_role', { _user_id: ctx.userId, _role: 'admin' });
  if (error || !data) throw new Error('VAULT_DENIED');
}

async function verifyMfa(factorId: string, code: string) {
  const url = process.env['SUPABASE_URL'];
  const apikey = process.env['SUPABASE_PUBLISHABLE_KEY'];
  const auth = getRequestHeader('authorization');
  if (!url || !apikey || !auth) throw new Error('VAULT_FAILED');
  const headers = { apikey, Authorization: auth, 'Content-Type': 'application/json' };
  const challenge = await fetch(`${url}/auth/v1/factors/${factorId}/challenge`, { method: 'POST', headers, body: '{}' });
  if (!challenge.ok) throw new Error('VAULT_MFA_FAILED');
  const challengeId = z.object({ id: z.string().uuid() }).parse(await challenge.json()).id;
  const verify = await fetch(`${url}/auth/v1/factors/${factorId}/verify`, { method: 'POST', headers, body: JSON.stringify({ challenge_id: challengeId, code }) });
  if (!verify.ok) throw new Error('VAULT_MFA_FAILED');
}

export const backupCompanyVaultKeys = createServerFn({ method: 'POST' })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    setResponseHeader('Cache-Control', 'no-store');
    await assertAdmin(context);
    const v1 = process.env['COMPANY_VAULT_KEK_V1'];
    const v2 = process.env['COMPANY_VAULT_KEK_V2'];
    const backupSecret = process.env['COMPANY_VAULT_KEK_BACKUP_KEY'];
    if (!v2 || !backupSecret) throw new Error('VAULT_FAILED');
    const blob = await encryptVaultValue(await backupKey(backupSecret), JSON.stringify({ v1: v1 ?? null, v2 }), BACKUP_CONTEXT);
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    const { error } = await supabaseAdmin.from('company_vault_kek_backups').insert({ blob, created_by: context.userId });
    if (error) throw new Error('VAULT_FAILED');
    return { ok: true };
  });

export const exportCompanyVaultKeys = createServerFn({ method: 'POST' })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { factorId: string; code: string }) => ({
    factorId: z.string().uuid().parse(i.factorId),
    code: z.string().regex(/^\d{6}$/).parse(i.code),
  }))
  .handler(async ({ context, data }) => {
    setResponseHeader('Cache-Control', 'no-store');
    try {
      await assertAdmin(context);
      await verifyMfa(data.factorId, data.code);
      const backupSecret = process.env['COMPANY_VAULT_KEK_BACKUP_KEY'];
      if (!backupSecret) throw new Error('VAULT_FAILED');
      const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
      const { data: row, error } = await supabaseAdmin
        .from('company_vault_kek_backups')
        .select('blob')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error || !row) throw new Error('VAULT_FAILED');
      const plain = await decryptVaultValue(await backupKey(backupSecret), envelopeSchema.parse(row.blob), BACKUP_CONTEXT);
      return z.object({ v1: z.string().nullable(), v2: z.string() }).parse(JSON.parse(plain));
    } catch {
      throw new Error('VAULT_FAILED');
    }
  });
