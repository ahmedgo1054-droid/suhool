import { createServerFn } from '@tanstack/react-start';
import { setResponseHeader, getRequestHeader } from '@tanstack/react-start/server';
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { envelopeSchema, wrapSchema } from '@/lib/personal-vault';

export const getPersonalVault = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  setResponseHeader('Cache-Control', 'no-store');
  const member = await context.supabase.rpc('vault_member');
  if (member.error || !member.data) throw new Error('VAULT_DENIED');
  const status = await context.supabase.rpc('personal_vault_status');
  if (status.error) throw new Error('VAULT_FAILED');
  const parsed = z.object({ has_key: z.boolean(), revision: z.number().nullable() }).parse(status.data);
  return { ownerId: context.userId, hasKey: parsed.has_key };
});

const actionSchema = z.object({
  action: z.enum(['setup','unlock','recover','create','edit','delete','reveal','copy','favorite']),
  factorId: z.string().uuid(), code: z.string().regex(/^\d{6}$/),
  id: z.string().uuid().optional(), revision: z.number().int().positive().optional(),
  envelope: envelopeSchema.optional(), password_wrap: wrapSchema.optional(), recovery_wrap: wrapSchema.optional(),
}).superRefine((v, ctx) => {
  if (['create','edit','delete','reveal','copy','favorite'].includes(v.action) && !v.id) ctx.addIssue({ code: 'custom', message: 'VAULT_INVALID' });
  if (['edit','delete','favorite','recover'].includes(v.action) && !v.revision) ctx.addIssue({ code: 'custom', message: 'VAULT_INVALID' });
  if (['create','edit','favorite'].includes(v.action) && !v.envelope) ctx.addIssue({ code: 'custom', message: 'VAULT_INVALID' });
  if (['setup','recover'].includes(v.action) && !v.password_wrap) ctx.addIssue({ code: 'custom', message: 'VAULT_INVALID' });
  if (v.action === 'setup' && !v.recovery_wrap) ctx.addIssue({ code: 'custom', message: 'VAULT_INVALID' });
});
export type PersonalVaultAction = z.infer<typeof actionSchema>;
export const personalVaultAction = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator((input: PersonalVaultAction) => actionSchema.parse(input))
  .handler(async ({ context, data }) => {
    setResponseHeader('Cache-Control', 'no-store');
    const sb = context.supabase;
    const member = await sb.rpc('vault_member');
    if (member.error || !member.data) throw new Error('VAULT_DENIED');
    // Each action creates and consumes its own server-side MFA challenge. No reusable unlock ticket.
    const url = process.env['SUPABASE_URL'];
    const apikey = process.env['SUPABASE_PUBLISHABLE_KEY'];
    const authorization = getRequestHeader('authorization');
    if (!url || !apikey || !authorization) throw new Error('VAULT_FAILED');
    const headers = { apikey, Authorization: authorization, 'Content-Type': 'application/json' };
    const challengeResponse = await fetch(`${url}/auth/v1/factors/${data.factorId}/challenge`, { method: 'POST', headers, body: '{}' });
    if (!challengeResponse.ok) throw new Error('VAULT_MFA_FAILED');
    const challenge = z.object({ id: z.string().uuid() }).parse(await challengeResponse.json());
    const verifyResponse = await fetch(`${url}/auth/v1/factors/${data.factorId}/verify`, { method: 'POST', headers, body: JSON.stringify({ challenge_id: challenge.id, code: data.code }) });
    if (!verifyResponse.ok) throw new Error('VAULT_MFA_FAILED');
    const verified = z.object({ access_token: z.string() }).parse(await verifyResponse.json());
    const verifiedClient = createClient<Database>(url, apikey, { auth: { persistSession: false, autoRefreshToken: false }, global: { headers: { Authorization: `Bearer ${verified.access_token}` } } });
    const { action, code: _code, factorId: _factor, ...payload } = data;
    // Privileged capability issuance only, after caller membership and fresh MFA verification.
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    const token = crypto.randomUUID();
    const issued = await supabaseAdmin.from('personal_vault_authorizations').insert({ token, owner_id: context.userId, action, record_id: data.id ?? null });
    if (issued.error) throw new Error('VAULT_FAILED');
    const command = await verifiedClient.rpc('personal_vault_command', { _action: action, _data: { ...payload, authorization: token } });
    await supabaseAdmin.from('personal_vault_authorizations').delete().eq('token', token).eq('owner_id', context.userId);
    if (command.error) throw new Error(command.error.message.includes('VAULT_CONFLICT') ? 'VAULT_CONFLICT' : 'VAULT_FAILED');
    // Ciphertext is returned atomically by the verified, owner-scoped command only.
    return z.object({
      key: z.object({ owner_id: z.string().uuid(), revision: z.number(), password_wrap: wrapSchema, recovery_wrap: wrapSchema }).nullable(),
      records: z.array(z.object({ id: z.string().uuid(), owner_id: z.string().uuid(), envelope: envelopeSchema, revision: z.number(), created_at: z.string(), updated_at: z.string() })),
    }).parse(command.data);
  });