import { queryOptions } from '@tanstack/react-query';
import { getHr } from '@/lib/hr.functions';
export const hrQuery = queryOptions({queryKey:['hr'],queryFn:()=>getHr()});
export type HrData = Awaited<ReturnType<typeof getHr>>;
