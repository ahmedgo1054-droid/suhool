import { queryOptions } from '@tanstack/react-query';
import { getAdminRequests } from './admin-requests.functions';
export const adminRequestsQuery=queryOptions({queryKey:['admin-requests'],queryFn:()=>getAdminRequests()});
export const adminRequestStates=['draft','pending','approved','rejected','completed','cancelled'] as const;
