import { queryOptions } from '@tanstack/react-query';
import { getDocuments, getDocument } from './documents.functions';
export const documentsQuery = queryOptions({ queryKey: ['documents'], queryFn: () => getDocuments() });
export const documentQuery = (id: string) => queryOptions({ queryKey: ['document', id], queryFn: () => getDocument({ data: { id } }) });
export const documentStates = ['draft','in_review','approved','rejected','archived'] as const;