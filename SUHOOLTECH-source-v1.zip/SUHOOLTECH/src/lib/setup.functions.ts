import { createServerFn } from "@tanstack/react-start";

async function adminExists() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { count, error } = await supabaseAdmin.from("user_roles").select("id", { count: "exact", head: true }).eq("role", "admin");
  if (error) throw new Error(error.message);
  return (count ?? 0) > 0;
}

export const getSetupStatus = createServerFn({ method: "GET" }).handler(async () => ({ needsSetup: !(await adminExists()) }));

export const createInitialAdmin = createServerFn({ method: "POST" })
  .inputValidator((i: { email: string; password: string; name: string }) => {
    const email = String(i.email ?? "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 255) throw new Error("Invalid email");
    if (String(i.password ?? "").length < 8) throw new Error("Password must be at least 8 characters");
    const name = String(i.name ?? "").trim().slice(0, 120);
    if (!name) throw new Error("Name is required");
    return { email, password: String(i.password), name };
  })
  .handler(async ({ data }) => {
    // Only allowed while no administrator exists; the signup trigger grants admin to the first account.
    if (await adminExists()) throw new Error("Setup already completed");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: c, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email, password: data.password, email_confirm: true,
      user_metadata: { full_name_ar: data.name, full_name_en: data.name },
    });
    if (error || !c.user) throw new Error(error?.message ?? "Could not create account");
    const { data: role } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", c.user.id);
    if (!role?.some((r) => r.role === "admin")) {
      await supabaseAdmin.auth.admin.deleteUser(c.user.id);
      throw new Error("Setup already completed");
    }
    return { ok: true };
  });
