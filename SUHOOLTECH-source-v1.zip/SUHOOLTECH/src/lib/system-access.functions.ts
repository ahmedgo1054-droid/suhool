import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { validateSystemAccess, type SystemAccessInput } from "@/lib/system-access-rules";

async function requireAdmin(context: { supabase: SupabaseClient<Database>; userId: string }) {
  const [role, active] = await Promise.all([
    context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" }),
    context.supabase.rpc("is_active_user", { _user_id: context.userId }),
  ]);
  if (role.error || active.error || !role.data || !active.data) throw new Error("ACCESS_DENIED");
}

export const getSystemAccess = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await requireAdmin(context);
    const [profiles, systems, access] = await Promise.all([
      context.supabase.from("profiles").select("id,full_name_ar,full_name_en,email,is_active,department_id").order("full_name_ar"),
      context.supabase.from("systems").select("*").order("position"),
      context.supabase.from("user_system_access").select("*"),
    ]);
    if (profiles.error || systems.error || access.error) throw new Error("ACCESS_LOAD_FAILED");
    return { profiles: profiles.data ?? [], systems: systems.data ?? [], access: access.data ?? [] };
  });

export const setSystemAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: SystemAccessInput) => validateSystemAccess(input))
  .handler(async ({ data, context }) => {
    await requireAdmin(context);
    const [profile, system] = await Promise.all([
      context.supabase.from("profiles").select("id").eq("id", data.userId).single(),
      context.supabase.from("systems").select("id,code").eq("id", data.systemId).single(),
    ]);
    if (profile.error || system.error || !profile.data || !system.data || !["tasks", "quotes", "hr", "docs", "admin_services", "vault"].includes(system.data.code)) throw new Error("ACCESS_INVALID");
    if (data.role === null) {
      const result = await context.supabase.from("user_system_access").delete().eq("user_id", data.userId).eq("system_id", data.systemId).select("id");
      if (result.error) throw new Error("ACCESS_SAVE_FAILED");
    } else {
      const result = await context.supabase.from("user_system_access").upsert({ user_id: data.userId, system_id: data.systemId, role: data.role }, { onConflict: "user_id,system_id" }).select("id").single();
      if (result.error || !result.data) throw new Error("ACCESS_SAVE_FAILED");
    }
    return { ok: true };
  });