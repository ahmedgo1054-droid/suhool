import type { Role } from "@/lib/data";

export type SystemAccessInput = { userId: string; systemId: string; role: Role | null };
export function validateSystemAccess(input: SystemAccessInput): SystemAccessInput {
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!input || !uuid.test(input.userId) || !uuid.test(input.systemId) || (input.role !== null && !["admin", "manager", "sales", "employee"].includes(input.role))) throw new Error("ACCESS_INVALID");
  return { userId: input.userId, systemId: input.systemId, role: input.role };
}