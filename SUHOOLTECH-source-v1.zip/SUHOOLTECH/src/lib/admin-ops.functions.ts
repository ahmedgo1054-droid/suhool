import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { must } from './data';
export const getAdminOps=createServerFn({method:'GET'}).middleware([requireSupabaseAuth]).handler(async({context})=>{
 const sb=context.supabase;if(!must(await sb.rpc('admin_services_member')))throw new Error('OPS_DENIED');
 const [assets,custody,purchases,items,events,permissions,manageAssets,approve,managePurchases,admin,profiles]=await Promise.all([
 sb.from('admin_assets').select('*').order('created_at',{ascending:false}),sb.from('admin_custody').select('*').order('assigned_at',{ascending:false}),sb.from('admin_purchases').select('*').order('created_at',{ascending:false}),sb.from('admin_purchase_items').select('*').order('position'),sb.from('admin_ops_events').select('*').order('created_at',{ascending:false}),sb.from('admin_ops_permissions').select('*'),sb.rpc('admin_ops_can',{_permission:'assets'}),sb.rpc('admin_ops_can',{_permission:'approve'}),sb.rpc('admin_ops_can',{_permission:'purchases'}),sb.rpc('has_role',{_user_id:context.userId,_role:'admin'}),sb.from('profiles').select('id,full_name_ar,full_name_en,email').eq('is_active',true)]);
 return {userId:context.userId,assets:must(assets),custody:must(custody),purchases:must(purchases),items:must(items),events:must(events),permissions:must(permissions),manageAssets:must(manageAssets),approve:must(approve),managePurchases:must(managePurchases),isAdmin:must(admin),profiles:must(profiles)};
});
export const adminOpsCommand=createServerFn({method:'POST'}).middleware([requireSupabaseAuth])
 .inputValidator((input:{action:string;data:Record<string,unknown>})=>{
 const value=z.object({action:z.enum(['permissions','asset_create','asset_edit','asset_assign','asset_return','asset_status','purchase_create','purchase_edit','purchase_transition']),data:z.record(z.unknown())}).parse(input);
 if(JSON.stringify(value.data).length>50000)throw new Error('OPS_INVALID');return value;
 }).handler(async({context,data})=>must(await context.supabase.rpc('admin_ops_command',{_action:data.action,_data:JSON.parse(JSON.stringify(data.data))})));
