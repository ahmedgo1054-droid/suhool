import { queryOptions } from "@tanstack/react-query";
import { getSystemAccess } from "@/lib/system-access.functions";
export const systemAccessQuery = queryOptions({ queryKey: ["system-access"], queryFn: () => getSystemAccess() });