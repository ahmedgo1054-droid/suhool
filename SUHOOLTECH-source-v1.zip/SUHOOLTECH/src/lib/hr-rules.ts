export function leaveDays(start: string, end: string) {
  const a = Date.parse(`${start}T00:00:00Z`), b = Date.parse(`${end}T00:00:00Z`);
  if (!Number.isFinite(a) || !Number.isFinite(b) || b < a) throw new Error('HR_INVALID_DATES');
  return (b - a) / 86400000 + 1;
}
export function remainingBalance(entitlement: number, approvedDays: number) { return entitlement - approvedDays; }
