import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { must } from './data';
export const getAdminRequests = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
 const sb=context.supabase;
 if (!must(await sb.rpc('admin_services_member'))) throw new Error('ADMIN_REQUEST_DENIED');
 const [requests,types,events,reviewer,admin]=await Promise.all([
 sb.from('admin_requests').select('*').order('created_at',{ascending:false}),
 sb.from('admin_request_types').select('*').order('name_ar'),
 sb.from('admin_request_events').select('*').order('created_at',{ascending:false}),
 sb.rpc('admin_services_reviewer'),sb.rpc('has_role',{_user_id:context.userId,_role:'admin'})]);
 const isAdmin=must(admin);
 const profiles=must(await sb.from('profiles').select('id,full_name_ar,full_name_en,email').eq('is_active',true));
 const memberships=isAdmin?must(await sb.from('user_system_access').select('user_id,role,systems!inner(code)').eq('systems.code','admin_services')):[];
 return {userId:context.userId,requests:must(requests),types:must(types),events:must(events),profiles,isReviewer:must(reviewer),isAdmin,memberships};
});
export const adminRequestCommand=createServerFn({method:'POST'}).middleware([requireSupabaseAuth])
 .inputValidator((input:{action:string;data:Record<string,string|boolean>})=>z.object({action:z.enum(['create','edit','transition','type','membership']),data:z.record(z.union([z.string(),z.boolean()]))}).parse(input))
 .handler(async({context,data})=>must(await context.supabase.rpc('admin_request_command',{_action:data.action,_data:data.data})));
