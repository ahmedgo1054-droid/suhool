import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { must } from "@/lib/data";

export type System = Database["public"]["Tables"]["systems"]["Row"];
export type SystemAccess = Database["public"]["Tables"]["user_system_access"]["Row"];
export type SystemCode = "tasks" | "quotes" | "hr" | "docs" | "admin_services" | "vault";

export function isSystemCode(code: string): code is SystemCode {
  return ["tasks", "quotes", "hr", "docs", "admin_services", "vault"].includes(code);
}

// Membership controls portal entry; it never overrides the existing data policies.
export function availableSystems(systems: System[], access: SystemAccess[]) {
  const permitted = new Set(access.map((entry) => entry.system_id));
  return systems.filter((system) => system.status === "active" && permitted.has(system.id));
}

export function futureSystems(systems: System[]) {
  return systems.filter((system) => system.status === "coming_soon");
}

export const portalQueryOptions = queryOptions({
  queryKey: ["portal-systems"],
  queryFn: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error) throw error;
    if (!data.user) throw new Error("Authentication required");
    const [systems, access] = await Promise.all([
      supabase.from("systems").select("*").order("position"),
      supabase.from("user_system_access").select("*").eq("user_id", data.user.id),
    ]);
    return { systems: must(systems), access: must(access) };
  },
});