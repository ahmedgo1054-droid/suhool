// Web Crypto only: shared by browser personal vault and server company helpers.
// Callers keep keys and decrypted values in session memory, never durable storage.
export const PERSONAL_KDF_ITERATIONS = 600_000;
export type CipherEnvelope = { version: 1; iv: string; ciphertext: string };
export type PasswordWrap = CipherEnvelope & { salt: string; iterations: typeof PERSONAL_KDF_ITERATIONS };

function encode(bytes: Uint8Array): string {
  return btoa(Array.from(bytes, (byte) => String.fromCharCode(byte)).join(""));
}
function decode(value: string): Uint8Array<ArrayBuffer> {
  return Uint8Array.from(atob(value), (char) => char.charCodeAt(0));
}
export async function generateVaultKey(): Promise<CryptoKey> {
  return crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, true, ["encrypt", "decrypt"]);
}
export async function encryptVaultValue(key: CryptoKey, value: string, context: string): Promise<CipherEnvelope> {
  if (!context || value.length > 100_000) throw new Error("VAULT_INVALID_INPUT");
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: new TextEncoder().encode(context), tagLength: 128 },
    key, new TextEncoder().encode(value),
  );
  return { version: 1, iv: encode(iv), ciphertext: encode(new Uint8Array(ciphertext)) };
}
export async function decryptVaultValue(key: CryptoKey, envelope: CipherEnvelope, context: string): Promise<string> {
  try {
    const iv = decode(envelope.iv);
    if (envelope.version !== 1 || iv.length !== 12 || !context) throw new Error();
    const plaintext = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv, additionalData: new TextEncoder().encode(context), tagLength: 128 },
      key, decode(envelope.ciphertext),
    );
    return new TextDecoder("utf-8", { fatal: true }).decode(plaintext);
  } catch {
    throw new Error("VAULT_UNLOCK_FAILED");
  }
}
async function passwordKey(passphrase: string, salt: Uint8Array<ArrayBuffer>, iterations: number): Promise<CryptoKey> {
  if (passphrase.length < 12 || passphrase.length > 1024 || salt.length !== 16 || iterations !== PERSONAL_KDF_ITERATIONS) {
    throw new Error("VAULT_INVALID_KDF");
  }
  const material = await crypto.subtle.importKey("raw", new TextEncoder().encode(passphrase), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations, hash: "SHA-256" }, material,
    { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"],
  );
}
export async function wrapPersonalKey(key: CryptoKey, passphrase: string, ownerId: string): Promise<PasswordWrap> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const wrapping = await passwordKey(passphrase, salt, PERSONAL_KDF_ITERATIONS);
  const raw = new Uint8Array(await crypto.subtle.exportKey("raw", key));
  try {
    const envelope = await encryptVaultValue(wrapping, encode(raw), `personal-key:${ownerId}:v1`);
    return { ...envelope, salt: encode(salt), iterations: PERSONAL_KDF_ITERATIONS };
  } finally { raw.fill(0); }
}
export async function unwrapPersonalKey(wrap: PasswordWrap, passphrase: string, ownerId: string): Promise<CryptoKey> {
  try {
    const wrapping = await passwordKey(passphrase, decode(wrap.salt), wrap.iterations);
    const raw = decode(await decryptVaultValue(wrapping, wrap, `personal-key:${ownerId}:v1`));
    try { return await crypto.subtle.importKey("raw", raw, "AES-GCM", true, ["encrypt", "decrypt"]); }
    finally { raw.fill(0); }
  } catch { throw new Error("VAULT_UNLOCK_FAILED"); }
}
export function generateRecoveryPassphrase(): string {
  return encode(crypto.getRandomValues(new Uint8Array(32)));
}