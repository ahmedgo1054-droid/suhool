import { z } from 'zod';

export const personalSecretSchema = z.object({
  name: z.string().trim().min(1).max(200), category: z.string().max(100),
  username: z.string().max(300), password: z.string().max(1024),
  url: z.string().max(2000), host: z.string().max(300), project: z.string().max(200),
  notes: z.string().max(10000), favorite: z.boolean(), reviewAt: z.string().max(10),
});
export type PersonalSecret = z.infer<typeof personalSecretSchema>;
export const emptySecret: PersonalSecret = { name: '', category: '', username: '', password: '', url: '', host: '', project: '', notes: '', favorite: false, reviewAt: '' };
export const envelopeSchema = z.object({ version: z.literal(1), iv: z.string().regex(/^[A-Za-z0-9+/]{16}$/), ciphertext: z.string().regex(/^[A-Za-z0-9+/]+={0,2}$/).min(24).max(150000) });
export const wrapSchema = envelopeSchema.extend({ salt: z.string().regex(/^[A-Za-z0-9+/]{22}==$/), iterations: z.literal(600000) });
export function personalContext(ownerId: string, recordId: string) { return `personal-record:${ownerId}:${recordId}:v1`; }
export const PERSONAL_IDLE_MS = 5 * 60 * 1000;
export function generateStrongPassword(length = 24): string {
  if (!Number.isInteger(length) || length < 16 || length > 128) throw new Error('VAULT_INVALID');
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*-_+=';
  let password = '';
  const limit = 256 - (256 % alphabet.length);
  while (password.length < length) {
    const bytes = crypto.getRandomValues(new Uint8Array(64));
    for (const byte of bytes) { if (byte < limit && password.length < length) password += alphabet[byte % alphabet.length]; }
  }
  if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password) || !/[!@#$%&*\-_+=]/.test(password)) return generateStrongPassword(length);
  return password;
}