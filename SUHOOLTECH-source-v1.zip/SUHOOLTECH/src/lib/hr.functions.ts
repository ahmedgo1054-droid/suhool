import { createServerFn } from '@tanstack/react-start';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { must, maybe } from '@/lib/data';
const actions = ['employee','finance','permissions','policy','leave_type','balance','leave_save','leave_transition','check_in','check_out','attendance'];
export const getHr = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({context}) => {
  const sb = context.supabase;
  if (!must(await sb.rpc('hr_can', {_permission:'access'}))) throw new Error('HR_ACCESS_DENIED');
  const permissions = Object.fromEntries(await Promise.all(['manage_employees','view_salary','approve_leaves','correct_attendance'].map(async p => [p,must(await sb.rpc('hr_can',{_permission:p}))])));
  const [employees, finances, leaves, attendance, types, balances, policy, grants, admin] = await Promise.all([
    sb.from('hr_employees').select('*').order('employee_no'),
    permissions.view_salary ? sb.from('hr_finances').select('*') : Promise.resolve({data:[],error:null}),
    sb.from('hr_leaves').select('*').order('created_at',{ascending:false}),
    sb.from('hr_attendance').select('*').order('work_date',{ascending:false}),
    sb.from('hr_leave_types').select('*'), sb.from('hr_leave_balances').select('*'),
    sb.from('hr_policy').select('*').maybeSingle(), sb.from('hr_permissions').select('*'),
    sb.rpc('has_role',{_user_id:context.userId,_role:'admin'})
  ]);
  const isAdmin = must(admin);
  const profileResult = permissions.manage_employees || isAdmin
    ? await sb.from('profiles').select('id,full_name_ar,full_name_en,email,phone,department_id').order('full_name_ar')
    : await sb.from('profiles').select('id,full_name_ar,full_name_en,email,phone,department_id').in('id',must(employees).map(e=>e.id).concat(context.userId));
  return {userId:context.userId,permissions,isAdmin,employees:must(employees),finances:must(finances),leaves:must(leaves),attendance:must(attendance),types:must(types),balances:must(balances),audit:must(await sb.from('hr_audit_logs').select('*').order('created_at',{ascending:false}).limit(100)),policy:maybe(policy),grants:must(grants),profiles:must(profileResult),departments:must(await sb.from('departments').select('*'))};
});
export const hrCommand = createServerFn({method:'POST'}).middleware([requireSupabaseAuth])
.inputValidator((input:{action:string;data:Record<string, string|number|boolean|number[]>})=>{
 if (!actions.includes(input.action) || JSON.stringify(input.data).length>12000) throw new Error('HR_INVALID_INPUT');
 return input;
}).handler(async ({data,context})=>must(await context.supabase.rpc('hr_command',{_action:data.action,_data:data.data})));
