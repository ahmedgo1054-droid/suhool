import { queryOptions } from '@tanstack/react-query';
import { getAdminOps } from './admin-ops.functions';
export const adminOpsQuery=queryOptions({queryKey:['admin-ops'],queryFn:()=>getAdminOps()});
export const assetStates=['available','assigned','maintenance','retired'] as const;
export const purchaseStates=['draft','pending','approved','rejected','ordered','received','cancelled'] as const;
