import { z } from 'zod';
import { personalSecretSchema } from '@/lib/personal-vault';

export const companyMetadataSchema = z.object({ name: z.string().trim().min(1).max(200), category: z.string().max(100), project: z.string().max(200), device_type: z.string().max(100), customer_id: z.string().uuid().nullable(), review_at: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable() });
export const companySecretSchema = personalSecretSchema.pick({ username: true, password: true, url: true, host: true, notes: true });
export const companyGrantSchema = z.object({ user_id: z.string().uuid(), can_view: z.boolean(), can_reveal: z.boolean(), can_edit: z.boolean(), can_delete: z.boolean(), can_sensitive_print: z.boolean(), can_manage_grants: z.boolean() });
export const companyActionSchema = z.object({ action: z.enum(['create','edit','delete','reveal','copy','sensitive_print','grant','revoke','favorite','rotate']), factorId: z.string().uuid(), code: z.string().regex(/^\d{6}$/), id: z.string().uuid(), revision: z.number().int().positive().optional(), metadata: companyMetadataSchema.optional(), secret: companySecretSchema.optional(), grant: companyGrantSchema.optional(), favorite: z.boolean().optional() }).superRefine((v, ctx) => {
  if (['create','edit'].includes(v.action) && (!v.metadata || !v.secret)) ctx.addIssue({ code:'custom', message:'VAULT_INVALID' });
  if (['edit','delete','rotate','grant','revoke'].includes(v.action) && !v.revision) ctx.addIssue({ code:'custom', message:'VAULT_INVALID' });
  if (['grant','revoke'].includes(v.action) && !v.grant) ctx.addIssue({ code:'custom', message:'VAULT_INVALID' });
});
export type CompanyAction = z.infer<typeof companyActionSchema>;
export type CompanySecret = z.infer<typeof companySecretSchema>;
export type CompanyMetadata = z.infer<typeof companyMetadataSchema>;
export type CompanyGrant = z.infer<typeof companyGrantSchema>;
export const emptyCompanySecret: CompanySecret = { username:'', password:'', url:'', host:'', notes:'' };
export const emptyCompanyMetadata: CompanyMetadata = { name:'', category:'', project:'', device_type:'', customer_id:null, review_at:null };
export function companyRecordContext(owner: string, id: string) { return `company-record:${owner}:${id}:v1`; }
export function companyKeyContext(owner: string, id: string, version: string) { return `company-key:${owner}:${id}:${version}`; }