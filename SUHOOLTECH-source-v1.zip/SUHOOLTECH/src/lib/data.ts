import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Role = Database["public"]["Enums"]["app_role"];
export type TaskStatus = Database["public"]["Enums"]["task_status"];
export type TaskPriority = Database["public"]["Enums"]["task_priority"];
export type QuoteStatus = Database["public"]["Enums"]["quote_status"];
export type Profile = Database["public"]["Tables"]["profiles"]["Row"];
export type Department = Database["public"]["Tables"]["departments"]["Row"];

export const ROLES: Role[] = ["admin", "manager", "sales", "employee"];
export const PRIORITIES: TaskPriority[] = ["LOW", "MEDIUM", "HIGH", "URGENT"];

/** Throws on Supabase errors so react-query surfaces them. */
type ResData<R> = R extends { data: infer X } ? X : never;
type Res = { data: unknown; error: { message: string } | null };

export function must<R extends Res>(res: R): NonNullable<ResData<R>> {
  if (res.error) throw new Error(res.error.message);
  return (res.data ?? []) as NonNullable<ResData<R>>;
}

/** Like must() but for single-row lookups that may legitimately return nothing. */
export function maybe<R extends Res>(res: R): ResData<R> | null {
  if (res.error) throw new Error(res.error.message);
  return (res.data ?? null) as ResData<R> | null;
}

export function useMe() {
  return useQuery({
    queryKey: ["me"],
    queryFn: async () => {
      const { data } = await supabase.auth.getUser();
      const user = data.user;
      if (!user) return null;
      const profile = maybe(await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle());
      const roles = must(await supabase.from("user_roles").select("role").eq("user_id", user.id)).map((r) => r.role);
      const is = (r: Role) => roles.includes(r);
      return { user, profile, roles, is, isAdmin: is("admin") };
    },
    staleTime: 60_000,
  });
}

export type ProfileWithRoles = Profile & { roles: Role[] };

export function useProfiles() {
  return useQuery({
    queryKey: ["profiles"],
    queryFn: async (): Promise<ProfileWithRoles[]> => {
      const profiles = must(await supabase.from("profiles").select("*").order("created_at"));
      const roles = must(await supabase.from("user_roles").select("user_id, role"));
      return profiles.map((p) => ({ ...p, roles: roles.filter((r) => r.user_id === p.id).map((r) => r.role) }));
    },
  });
}

export function useDepartments() {
  return useQuery({
    queryKey: ["departments"],
    queryFn: async () => must(await supabase.from("departments").select("*").order("name_en")),
  });
}

export function useCustomers() {
  return useQuery({ queryKey: ["customers"], queryFn: async () => must(await supabase.from("customers").select("*").order("name_ar")) });
}

export function useSettings() {
  return useQuery({
    queryKey: ["settings"],
    queryFn: async () => maybe(await supabase.from("company_settings").select("*").maybeSingle()),
  });
}

export function personName(p: Pick<Profile, "full_name_ar" | "full_name_en" | "email"> | null | undefined, lang: "ar" | "en") {
  if (!p) return "—";
  return (lang === "ar" ? p.full_name_ar || p.full_name_en : p.full_name_en || p.full_name_ar) || p.email;
}

export function deptName(d: Pick<Department, "name_ar" | "name_en"> | null | undefined, lang: "ar" | "en") {
  if (!d) return "—";
  return lang === "ar" ? d.name_ar : d.name_en;
}

export function money(n: number | string | null | undefined, lang: "ar" | "en") {
  const v = Number(n ?? 0);
  return v.toLocaleString(lang === "ar" ? "ar-SA" : "en-SA", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function fmtDate(d: string | null | undefined, lang: "ar" | "en") {
  if (!d) return "—";
  return new Date(d).toLocaleDateString(lang === "ar" ? "ar-SA-u-ca-gregory" : "en-GB");
}
