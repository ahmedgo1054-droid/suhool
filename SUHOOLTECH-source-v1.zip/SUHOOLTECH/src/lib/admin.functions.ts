import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Role = "admin" | "manager" | "sales" | "employee";
const ROLES: Role[] = ["admin", "manager", "sales", "employee"];

type EmployeeInput = {
  email: string;
  password: string;
  full_name_ar: string;
  full_name_en: string;
  phone?: string | null;
  department_id?: string | null;
  role: Role;
};

async function assertAdmin(ctx: { supabase: any; userId: string }) {
  const { data, error } = await ctx.supabase.rpc("has_role", { _user_id: ctx.userId, _role: "admin" });
  if (error || !data) throw new Error("Forbidden: administrators only");
}

export const createEmployee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: EmployeeInput) => {
    const email = String(i.email ?? "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 255) throw new Error("Invalid email");
    if (String(i.password ?? "").length < 8) throw new Error("Password must be at least 8 characters");
    if (!ROLES.includes(i.role)) throw new Error("Invalid role");
    const full_name_ar = String(i.full_name_ar ?? "").trim().slice(0, 120);
    const full_name_en = String(i.full_name_en ?? "").trim().slice(0, 120);
    if (!full_name_ar && !full_name_en) throw new Error("Name is required");
    return { ...i, email, full_name_ar, full_name_en, phone: i.phone?.trim().slice(0, 30) || null, department_id: i.department_id || null };
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name_ar: data.full_name_ar, full_name_en: data.full_name_en },
    });
    if (error || !created.user) throw new Error(error?.message ?? "Could not create account");
    const id = created.user.id;
    await supabaseAdmin.from("profiles").update({ phone: data.phone, department_id: data.department_id }).eq("id", id);
    await supabaseAdmin.from("user_roles").delete().eq("user_id", id);
    const { error: rErr } = await supabaseAdmin.from("user_roles").insert({ user_id: id, role: data.role });
    if (rErr) throw new Error(rErr.message);
    return { id };
  });

export const updateEmployee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { id: string; full_name_ar: string; full_name_en: string; phone?: string | null; department_id?: string | null; role: Role }) => {
    if (!ROLES.includes(i.role)) throw new Error("Invalid role");
    return i;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    if (data.id === context.userId && data.role !== "admin") throw new Error("You cannot remove your own administrator role");
    const sb = context.supabase;
    const { error } = await sb.from("profiles").update({
      full_name_ar: data.full_name_ar.trim(), full_name_en: data.full_name_en.trim(),
      phone: data.phone?.trim() || null, department_id: data.department_id || null,
    }).eq("id", data.id);
    if (error) throw new Error(error.message);
    await sb.from("user_roles").delete().eq("user_id", data.id).neq("role", data.role);
    const { error: rErr } = await sb.from("user_roles").upsert({ user_id: data.id, role: data.role }, { onConflict: "user_id,role" });
    if (rErr) throw new Error(rErr.message);
    return { ok: true };
  });

export const setEmployeeActive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i: { id: string; active: boolean }) => i)
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    if (data.id === context.userId) throw new Error("You cannot suspend your own account");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.id, { ban_duration: data.active ? "none" : "876000h" });
    if (error) throw new Error(error.message);
    const { error: pErr } = await supabaseAdmin.from("profiles").update({ is_active: data.active }).eq("id", data.id);
    if (pErr) throw new Error(pErr.message);
    return { ok: true };
  });
