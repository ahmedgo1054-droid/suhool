import { createServerFn } from '@tanstack/react-start';
import { getRequestHeader, setResponseHeader } from '@tanstack/react-start/server';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { envelopeSchema } from '@/lib/personal-vault';
import { companyActionSchema, type CompanyAction } from '@/lib/company-vault';

export const getCompanyVault = createServerFn({method:'GET'}).middleware([requireSupabaseAuth]).handler(async ({context})=>{
  setResponseHeader('Cache-Control','no-store');
  const sb=context.supabase;
  if (!(await sb.rpc('vault_member')).data) throw new Error('VAULT_DENIED');
  const [records,grants,favorites,events,profiles,customers]=await Promise.all([
    sb.from('vault_records').select('*').order('updated_at',{ascending:false}),sb.from('vault_record_grants').select('*'),sb.from('company_vault_favorites').select('*').eq('user_id',context.userId),sb.from('vault_audit_events').select('*').order('created_at',{ascending:false}).limit(100),sb.rpc('company_vault_sharing_candidates'),sb.from('customers').select('id,name_ar,name_en')
  ]);
  if(records.error||grants.error||favorites.error||events.error||profiles.error) throw new Error('VAULT_FAILED');
  return {ownerId:context.userId,records:records.data,grants:grants.data,favorites:favorites.data,events:events.data,profiles:profiles.data??[],customers:customers.data??[]};
});
export const companyVaultAction=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator((input:CompanyAction)=>companyActionSchema.parse(input)).handler(async ({context,data})=>{
  setResponseHeader('Cache-Control','no-store');
  try {
    if (!(await context.supabase.rpc('vault_member')).data) throw new Error('VAULT_DENIED');
    const permission = ({edit:'edit',rotate:'edit',delete:'delete',grant:'grants',revoke:'grants',favorite:'view',reveal:'reveal',copy:'reveal',sensitive_print:'sensitive_print'} as const)[data.action as Exclude<CompanyAction['action'],'create'>];
    if(data.action!=='create' && !(await context.supabase.rpc('vault_can',{_record:data.id,_permission:permission})).data) throw new Error('VAULT_DENIED');
    const url=process.env['SUPABASE_URL']; const apikey=process.env['SUPABASE_PUBLISHABLE_KEY']; const auth=getRequestHeader('authorization');
    const v1=process.env['COMPANY_VAULT_KEK_V1']; const v2=process.env['COMPANY_VAULT_KEK_V2'];
    if(!url||!apikey||!auth||!v2) throw new Error('VAULT_FAILED');
    const headers={apikey,Authorization:auth,'Content-Type':'application/json'};
    const challenge=await fetch(`${url}/auth/v1/factors/${data.factorId}/challenge`,{method:'POST',headers,body:'{}'});
    if(!challenge.ok) throw new Error('VAULT_MFA_FAILED');
    const challengeId=z.object({id:z.string().uuid()}).parse(await challenge.json()).id;
    const verify=await fetch(`${url}/auth/v1/factors/${data.factorId}/verify`,{method:'POST',headers,body:JSON.stringify({challenge_id:challengeId,code:data.code})});
    if(!verify.ok) throw new Error('VAULT_MFA_FAILED');
    // Verify response is never logged, cached, or returned.
    const {supabaseAdmin}=await import('@/integrations/supabase/client.server');
    const {encryptCompanySecret,decryptCompanySecret,rewrapCompanyKey}=await import('@/lib/company-vault-crypto');
    const {code:_code,factorId:_factor,secret,...payload}=data;
    const command=async (body:Record<string,unknown>)=>{
      const token=crypto.randomUUID();
      const issued=await supabaseAdmin.from('company_vault_authorizations').insert({token,actor_id:context.userId,action:data.action,record_id:data.id});
      if(issued.error) throw new Error('VAULT_FAILED');
      try {
        const result=await supabaseAdmin.rpc('company_vault_command',{_actor:context.userId,_action:data.action,_id:data.id,_token:token,_data:body as never});
        if(result.error) throw new Error(result.error.message.includes('VAULT_CONFLICT')?'VAULT_CONFLICT':'VAULT_DENIED');
        return result.data;
      } finally { await supabaseAdmin.from('company_vault_authorizations').delete().eq('token',token); }
    };
    if(data.action==='create' && secret) { await command({...payload,...await encryptCompanySecret(secret,v2,context.userId,data.id,'v2')}); return {secret:null}; }
    if(['edit','rotate','reveal','copy','sensitive_print'].includes(data.action)) {
      const read=z.object({record:z.object({owner_id:z.string().uuid()}),cipher:z.object({envelope:envelopeSchema,wrapped_key:envelopeSchema,key_version:z.enum(['v1','v2'])})}).parse(await command({revision:data.revision}));
      const oldKek=read.cipher.key_version==='v1'?v1:v2;
      if(!oldKek) throw new Error('VAULT_FAILED');
      if(data.action==='edit' && secret) {await command({...payload,...await encryptCompanySecret(secret,v2,read.record.owner_id,data.id,'v2')});return {secret:null};}
      if(data.action==='rotate') {await command({...payload,...await rewrapCompanyKey(read.cipher,oldKek,v2,read.record.owner_id,data.id,'v2')});return {secret:null};}
      return {secret:await decryptCompanySecret(read.cipher,oldKek,read.record.owner_id,data.id)};
    }
    await command(payload); return {secret:null};
  } catch(error) {throw new Error(error instanceof Error && error.message==='VAULT_CONFLICT'?'VAULT_CONFLICT':'VAULT_FAILED');}
});