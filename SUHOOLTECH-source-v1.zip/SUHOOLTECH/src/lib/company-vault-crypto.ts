import { decryptVaultValue, encryptVaultValue, generateVaultKey, type CipherEnvelope } from '@/lib/vault-crypto';
import { companyKeyContext, companyRecordContext, companySecretSchema, type CompanySecret } from '@/lib/company-vault';
import { envelopeSchema } from '@/lib/personal-vault';

async function wrappingKey(secret: string) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(secret));
  return crypto.subtle.importKey('raw', digest, 'AES-GCM', false, ['encrypt','decrypt']);
}
async function wrap(key: CryptoKey, kek: string, context: string) {
  const bytes = new Uint8Array(await crypto.subtle.exportKey('raw',key));
  try { return await encryptVaultValue(await wrappingKey(kek), btoa(String.fromCharCode(...bytes)), context); }
  finally { bytes.fill(0); }
}
export async function encryptCompanySecret(secret: CompanySecret, kek: string, owner: string, id: string, version: string) {
  const key = await generateVaultKey();
  return { envelope:await encryptVaultValue(key,JSON.stringify(companySecretSchema.parse(secret)),companyRecordContext(owner,id)), wrapped_key:await wrap(key,kek,companyKeyContext(owner,id,version)), key_version:version };
}
export async function openCompanyKey(cipher: { wrapped_key: unknown; key_version: string }, kek: string, owner: string, id: string) {
  const raw = Uint8Array.from(atob(await decryptVaultValue(await wrappingKey(kek),envelopeSchema.parse(cipher.wrapped_key),companyKeyContext(owner,id,cipher.key_version))),c=>c.charCodeAt(0));
  try { return await crypto.subtle.importKey('raw',raw,'AES-GCM',true,['encrypt','decrypt']); } finally { raw.fill(0); }
}
export async function decryptCompanySecret(cipher: { envelope: unknown; wrapped_key: unknown; key_version: string }, kek: string, owner: string, id: string) {
  return companySecretSchema.parse(JSON.parse(await decryptVaultValue(await openCompanyKey(cipher,kek,owner,id),envelopeSchema.parse(cipher.envelope),companyRecordContext(owner,id))));
}
export async function rewrapCompanyKey(cipher: { envelope: unknown; wrapped_key: unknown; key_version: string }, oldKek: string, newKek: string, owner: string, id: string, version: string) {
  return { envelope:envelopeSchema.parse(cipher.envelope) as CipherEnvelope, wrapped_key:await wrap(await openCompanyKey(cipher,oldKek,owner,id),newKek,companyKeyContext(owner,id,version)),key_version:version };
}