import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { must } from '@/lib/data';

export const getDocuments = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const sb = context.supabase;
  if (!must(await sb.rpc('docs_member'))) throw new Error('DOCS_DENIED');
  const [documents, categories, profiles, access, memberships, admin] = await Promise.all([
    sb.from('documents').select('*').order('updated_at', { ascending: false }),
    sb.from('document_categories').select('*').order('name_ar'),
    sb.from('profiles').select('id,full_name_ar,full_name_en').eq('is_active', true),
    sb.from('document_access').select('*'),
    sb.from('user_system_access').select('user_id,systems!inner(code)').eq('systems.code', 'docs'),
    sb.rpc('has_role', { _user_id: context.userId, _role: 'admin' }),
  ]);
  return { userId: context.userId, documents: must(documents), categories: must(categories), profiles: must(profiles), access: must(access), memberships: must(memberships), isAdmin: must(admin) };
});

export const getDocument = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const sb = context.supabase;
    if (!must(await sb.rpc('docs_can', { _id: data.id }))) throw new Error('DOCS_DENIED');
    const [document, versions, events, edit, share, review] = await Promise.all([
      sb.from('documents').select('*').eq('id', data.id).single(),
      sb.from('document_versions').select('*').eq('document_id', data.id).order('version', { ascending: false }),
      sb.from('document_events').select('*').eq('document_id', data.id).order('created_at', { ascending: false }),
      sb.rpc('docs_can', { _id: data.id, _permission: 'edit' }),
      sb.rpc('docs_can', { _id: data.id, _permission: 'share' }),
      sb.rpc('docs_can', { _id: data.id, _permission: 'review' }),
    ]);
    return { document: must(document), versions: must(versions), events: must(events), canEdit: must(edit), canShare: must(share), canReview: must(review) };
  });

export const documentCommand = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator((input: { action: string; data: Record<string, string | number | boolean> }) => {
    const parsed = z.object({ action: z.enum(['create','edit','category','membership','share','reserve','finalize','transition']), data: z.record(z.string(), z.union([z.string(),z.number(),z.boolean()])) }).parse(input);
    if (JSON.stringify(parsed.data).length > 24000) throw new Error('DOCS_INVALID');
    return parsed;
  }).handler(async ({ context, data }) => must(await context.supabase.rpc('docs_command', { _action: data.action, _data: data.data })));

export const downloadDocument = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const v = must(await context.supabase.from('document_versions').select('*').eq('id', data.id).single());
    if (!v.ready || !must(await context.supabase.rpc('docs_can', { _id: v.document_id }))) throw new Error('DOCS_DENIED');
    return must(await context.supabase.storage.from('documents').createSignedUrl(v.storage_path, 60, { download: v.file_name }));
  });