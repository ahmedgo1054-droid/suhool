REVOKE ALL ON public.vault_ciphertexts FROM anon, authenticated;
REVOKE INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER ON public.vault_records,public.vault_record_grants,public.vault_audit_events FROM anon,authenticated;
REVOKE ALL ON public.personal_vault_keys,public.personal_vault_records FROM anon;
GRANT SELECT ON public.vault_records,public.vault_record_grants,public.vault_audit_events TO authenticated;
GRANT ALL ON public.vault_ciphertexts,public.vault_records,public.vault_record_grants,public.vault_audit_events TO service_role;