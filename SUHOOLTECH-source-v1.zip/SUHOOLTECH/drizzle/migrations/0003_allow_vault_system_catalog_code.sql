ALTER TABLE public.systems DROP CONSTRAINT systems_code_check;
ALTER TABLE public.systems ADD CONSTRAINT systems_code_check CHECK(code IN ('tasks','quotes','hr','docs','admin_services','vault'));