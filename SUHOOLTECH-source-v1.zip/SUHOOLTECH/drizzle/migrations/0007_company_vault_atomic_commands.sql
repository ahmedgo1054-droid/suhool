CREATE TABLE public.company_vault_authorizations(token uuid PRIMARY KEY,actor_id uuid NOT NULL REFERENCES public.profiles(id),action text NOT NULL,record_id uuid NOT NULL,expires_at timestamptz NOT NULL DEFAULT now()+interval '60 seconds');
GRANT ALL ON public.company_vault_authorizations TO service_role;
ALTER TABLE public.company_vault_authorizations ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.company_vault_favorites(user_id uuid NOT NULL REFERENCES public.profiles(id),record_id uuid NOT NULL REFERENCES public.vault_records(id) ON DELETE CASCADE,PRIMARY KEY(user_id,record_id));
GRANT SELECT ON public.company_vault_favorites TO authenticated;
GRANT ALL ON public.company_vault_favorites TO service_role;
ALTER TABLE public.company_vault_favorites ENABLE ROW LEVEL SECURITY;
CREATE POLICY company_favorites_owner ON public.company_vault_favorites FOR SELECT TO authenticated USING(user_id=auth.uid() AND public.vault_can(record_id,'view'));
CREATE FUNCTION public.company_vault_command(_actor uuid,_action text,_id uuid,_token uuid,_data jsonb DEFAULT '{}'::jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE r public.vault_records; g public.vault_record_grants; target uuid; result jsonb;
BEGIN
 IF NOT public.is_active_user(_actor) OR NOT EXISTS(SELECT 1 FROM public.user_system_access a JOIN public.systems s ON s.id=a.system_id WHERE a.user_id=_actor AND s.code='vault' AND s.status='active') THEN RAISE EXCEPTION 'VAULT_DENIED'; END IF;
 DELETE FROM public.company_vault_authorizations WHERE token=_token AND actor_id=_actor AND action=_action AND record_id=_id AND expires_at>clock_timestamp();
 IF NOT FOUND THEN RAISE EXCEPTION 'VAULT_FRESH_VERIFICATION_REQUIRED'; END IF;
 IF octet_length(_data::text)>160000 THEN RAISE EXCEPTION 'VAULT_INVALID'; END IF;
 IF _action='create' THEN
  INSERT INTO public.vault_records(id,owner_id,name,category,project,device_type,customer_id,review_at) VALUES(_id,_actor,_data->'metadata'->>'name',coalesce(_data->'metadata'->>'category',''),coalesce(_data->'metadata'->>'project',''),coalesce(_data->'metadata'->>'device_type',''),(_data->'metadata'->>'customer_id')::uuid,(_data->'metadata'->>'review_at')::date) RETURNING * INTO r;
  INSERT INTO public.vault_record_grants VALUES(_id,_actor,true,true,true,true,true,true);
  INSERT INTO public.vault_ciphertexts(record_id,envelope,wrapped_key,key_version) VALUES(_id,_data->'envelope',_data->'wrapped_key',_data->>'key_version');
 ELSE
  SELECT * INTO r FROM public.vault_records WHERE id=_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'VAULT_DENIED'; END IF;
  SELECT * INTO g FROM public.vault_record_grants WHERE record_id=_id AND user_id=_actor;
  IF NOT FOUND THEN RAISE EXCEPTION 'VAULT_DENIED'; END IF;
  IF NOT (CASE _action WHEN 'reveal' THEN g.can_view AND g.can_reveal WHEN 'copy' THEN g.can_view AND g.can_reveal WHEN 'sensitive_print' THEN g.can_view AND g.can_reveal AND g.can_sensitive_print WHEN 'edit' THEN g.can_edit WHEN 'delete' THEN g.can_delete WHEN 'grant' THEN g.can_manage_grants WHEN 'revoke' THEN g.can_manage_grants WHEN 'favorite' THEN g.can_view WHEN 'rotate' THEN g.can_edit ELSE false END) THEN RAISE EXCEPTION 'VAULT_DENIED'; END IF;
  IF _action IN ('edit','delete','grant','revoke','rotate') AND r.revision IS DISTINCT FROM (_data->>'revision')::integer THEN RAISE EXCEPTION 'VAULT_CONFLICT'; END IF;
  IF _action IN ('reveal','copy','sensitive_print') OR (_action IN ('edit','rotate') AND NOT (_data ? 'envelope')) THEN
   SELECT jsonb_build_object('record',to_jsonb(r),'cipher',to_jsonb(c)) INTO result FROM public.vault_ciphertexts c WHERE c.record_id=_id;
  ELSIF _action='edit' THEN
   UPDATE public.vault_records SET name=_data->'metadata'->>'name',category=coalesce(_data->'metadata'->>'category',''),project=coalesce(_data->'metadata'->>'project',''),device_type=coalesce(_data->'metadata'->>'device_type',''),customer_id=(_data->'metadata'->>'customer_id')::uuid,review_at=(_data->'metadata'->>'review_at')::date,revision=revision+1 WHERE id=_id RETURNING * INTO r;
   UPDATE public.vault_ciphertexts SET envelope=_data->'envelope',wrapped_key=_data->'wrapped_key',key_version=_data->>'key_version',revision=r.revision WHERE record_id=_id;
  ELSIF _action='rotate' THEN
   UPDATE public.vault_records SET revision=revision+1 WHERE id=_id RETURNING * INTO r;
   UPDATE public.vault_ciphertexts SET wrapped_key=_data->'wrapped_key',key_version=_data->>'key_version',revision=r.revision WHERE record_id=_id;
  ELSIF _action='delete' THEN
   INSERT INTO public.vault_audit_events(actor_id,record_id,action) VALUES(_actor,_id,'delete');
   DELETE FROM public.vault_records WHERE id=_id;
   RETURN jsonb_build_object('ok',true);
  ELSIF _action IN ('grant','revoke') THEN
   target:=(_data->'grant'->>'user_id')::uuid;
   IF target=_actor THEN RAISE EXCEPTION 'VAULT_INVALID'; END IF;
   IF _action='revoke' THEN DELETE FROM public.vault_record_grants WHERE record_id=_id AND user_id=target;
   ELSE
    IF NOT public.is_active_user(target) OR NOT EXISTS(SELECT 1 FROM public.user_system_access a JOIN public.systems s ON s.id=a.system_id WHERE a.user_id=target AND s.code='vault' AND s.status='active') THEN RAISE EXCEPTION 'VAULT_DENIED'; END IF;
    INSERT INTO public.vault_record_grants VALUES(_id,target,coalesce((_data->'grant'->>'can_view')::boolean,false),coalesce((_data->'grant'->>'can_reveal')::boolean,false),coalesce((_data->'grant'->>'can_edit')::boolean,false),coalesce((_data->'grant'->>'can_delete')::boolean,false),coalesce((_data->'grant'->>'can_sensitive_print')::boolean,false),coalesce((_data->'grant'->>'can_manage_grants')::boolean,false)) ON CONFLICT(record_id,user_id) DO UPDATE SET can_view=excluded.can_view,can_reveal=excluded.can_reveal,can_edit=excluded.can_edit,can_delete=excluded.can_delete,can_sensitive_print=excluded.can_sensitive_print,can_manage_grants=excluded.can_manage_grants;
   END IF;
   UPDATE public.vault_records SET revision=revision+1 WHERE id=_id;
  ELSIF _action='favorite' THEN
   IF coalesce((_data->>'favorite')::boolean,false) THEN INSERT INTO public.company_vault_favorites VALUES(_actor,_id) ON CONFLICT DO NOTHING; ELSE DELETE FROM public.company_vault_favorites WHERE user_id=_actor AND record_id=_id; END IF;
   RETURN jsonb_build_object('ok',true);
  END IF;
 END IF;
 IF _action<>'rotate' OR _data ? 'envelope' THEN INSERT INTO public.vault_audit_events(actor_id,record_id,action) VALUES(_actor,_id,CASE WHEN _action='rotate' THEN 'edit' ELSE _action END); END IF;
 RETURN coalesce(result,jsonb_build_object('ok',true));
END; $$;
REVOKE ALL ON FUNCTION public.company_vault_command(uuid,text,uuid,uuid,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.company_vault_command(uuid,text,uuid,uuid,jsonb) TO service_role;