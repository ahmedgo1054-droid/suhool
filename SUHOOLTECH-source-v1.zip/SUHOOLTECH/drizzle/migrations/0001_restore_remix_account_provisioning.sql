CREATE OR REPLACE FUNCTION public.remix_provision_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  PERFORM pg_advisory_xact_lock(735901624);
  INSERT INTO public.profiles(id,email,full_name_ar,full_name_en)
  VALUES(NEW.id,coalesce(NEW.email,''),coalesce(NEW.raw_user_meta_data->>'full_name_ar',NEW.raw_user_meta_data->>'full_name',''),coalesce(NEW.raw_user_meta_data->>'full_name_en',NEW.raw_user_meta_data->>'full_name',''));
  INSERT INTO public.user_roles(user_id,role)
  VALUES(NEW.id,CASE WHEN EXISTS(SELECT 1 FROM public.user_roles WHERE role='admin') THEN 'employee'::public.app_role ELSE 'admin'::public.app_role END);
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.remix_provision_user() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER remix_account_provisioning AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.remix_provision_user();