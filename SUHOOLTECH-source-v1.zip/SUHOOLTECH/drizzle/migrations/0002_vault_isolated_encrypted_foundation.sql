CREATE TABLE public.vault_records (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL REFERENCES public.profiles(id), name text NOT NULL, category text NOT NULL DEFAULT '', customer_id uuid REFERENCES public.customers(id), project text NOT NULL DEFAULT '', device_type text NOT NULL DEFAULT '', review_at date, revision integer NOT NULL DEFAULT 1, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), CONSTRAINT vault_name_length CHECK(length(name) BETWEEN 1 AND 200)
);
GRANT SELECT ON public.vault_records TO authenticated;
GRANT ALL ON public.vault_records TO service_role;
ALTER TABLE public.vault_records ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.vault_record_grants (
 record_id uuid NOT NULL REFERENCES public.vault_records(id) ON DELETE CASCADE, user_id uuid NOT NULL REFERENCES public.profiles(id), can_view boolean NOT NULL DEFAULT false, can_reveal boolean NOT NULL DEFAULT false, can_edit boolean NOT NULL DEFAULT false, can_delete boolean NOT NULL DEFAULT false, can_sensitive_print boolean NOT NULL DEFAULT false, can_manage_grants boolean NOT NULL DEFAULT false, PRIMARY KEY(record_id,user_id)
);
GRANT SELECT ON public.vault_record_grants TO authenticated;
GRANT ALL ON public.vault_record_grants TO service_role;
ALTER TABLE public.vault_record_grants ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.vault_ciphertexts (
 record_id uuid PRIMARY KEY REFERENCES public.vault_records(id) ON DELETE CASCADE, envelope jsonb NOT NULL, wrapped_key jsonb NOT NULL, key_version text NOT NULL, revision integer NOT NULL DEFAULT 1
);
GRANT ALL ON public.vault_ciphertexts TO service_role;
ALTER TABLE public.vault_ciphertexts ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.vault_audit_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), actor_id uuid NOT NULL REFERENCES public.profiles(id), record_id uuid REFERENCES public.vault_records(id) ON DELETE SET NULL, action text NOT NULL CHECK(action IN ('create','edit','delete','reveal','copy','sensitive_print','grant','revoke')), created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.vault_audit_events TO authenticated;
GRANT ALL ON public.vault_audit_events TO service_role;
ALTER TABLE public.vault_audit_events ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.personal_vault_keys (
 owner_id uuid PRIMARY KEY REFERENCES public.profiles(id), password_wrap jsonb NOT NULL, recovery_wrap jsonb NOT NULL, revision integer NOT NULL DEFAULT 1, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT,INSERT,UPDATE,DELETE ON public.personal_vault_keys TO authenticated;
GRANT ALL ON public.personal_vault_keys TO service_role;
ALTER TABLE public.personal_vault_keys ENABLE ROW LEVEL SECURITY;
CREATE TABLE public.personal_vault_records (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL REFERENCES public.profiles(id), envelope jsonb NOT NULL, revision integer NOT NULL DEFAULT 1, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT,INSERT,UPDATE,DELETE ON public.personal_vault_records TO authenticated;
GRANT ALL ON public.personal_vault_records TO service_role;
ALTER TABLE public.personal_vault_records ENABLE ROW LEVEL SECURITY;
CREATE INDEX vault_owner_idx ON public.vault_records(owner_id);
CREATE INDEX vault_grant_user_idx ON public.vault_record_grants(user_id);
CREATE INDEX personal_vault_owner_idx ON public.personal_vault_records(owner_id);
CREATE INDEX vault_audit_actor_idx ON public.vault_audit_events(actor_id,created_at DESC);
CREATE FUNCTION public.vault_member() RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$ SELECT public.is_active_user(auth.uid()) AND EXISTS(SELECT 1 FROM public.user_system_access a JOIN public.systems s ON s.id=a.system_id WHERE a.user_id=auth.uid() AND s.code='vault' AND s.status='active'); $$;
REVOKE ALL ON FUNCTION public.vault_member() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.vault_member() TO authenticated, service_role;
CREATE FUNCTION public.vault_can(_record uuid,_permission text) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$ SELECT public.vault_member() AND EXISTS(SELECT 1 FROM public.vault_record_grants g WHERE g.record_id=_record AND g.user_id=auth.uid() AND CASE _permission WHEN 'view' THEN g.can_view WHEN 'reveal' THEN g.can_reveal WHEN 'edit' THEN g.can_edit WHEN 'delete' THEN g.can_delete WHEN 'sensitive_print' THEN g.can_sensitive_print AND g.can_reveal WHEN 'grants' THEN g.can_manage_grants ELSE false END); $$;
REVOKE ALL ON FUNCTION public.vault_can(uuid,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.vault_can(uuid,text) TO authenticated, service_role;
CREATE POLICY vault_metadata_read ON public.vault_records FOR SELECT TO authenticated USING(public.vault_can(id,'view'));
CREATE POLICY vault_grants_read ON public.vault_record_grants FOR SELECT TO authenticated USING(public.vault_member() AND (user_id=auth.uid() OR public.vault_can(record_id,'grants')));
CREATE POLICY vault_audit_read ON public.vault_audit_events FOR SELECT TO authenticated USING(public.vault_member() AND actor_id=auth.uid());
CREATE POLICY personal_keys_owner ON public.personal_vault_keys FOR ALL TO authenticated USING(owner_id=auth.uid() AND public.vault_member()) WITH CHECK(owner_id=auth.uid() AND public.vault_member());
CREATE POLICY personal_records_owner ON public.personal_vault_records FOR ALL TO authenticated USING(owner_id=auth.uid() AND public.vault_member()) WITH CHECK(owner_id=auth.uid() AND public.vault_member());
CREATE TRIGGER vault_records_updated BEFORE UPDATE ON public.vault_records FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER personal_keys_updated BEFORE UPDATE ON public.personal_vault_keys FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER personal_records_updated BEFORE UPDATE ON public.personal_vault_records FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();