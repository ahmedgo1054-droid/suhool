CREATE TABLE public.company_vault_kek_backups (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), blob jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), created_by uuid);
GRANT ALL ON public.company_vault_kek_backups TO service_role;
ALTER TABLE public.company_vault_kek_backups ENABLE ROW LEVEL SECURITY;