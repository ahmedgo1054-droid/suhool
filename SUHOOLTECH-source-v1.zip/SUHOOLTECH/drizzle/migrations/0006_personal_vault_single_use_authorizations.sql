CREATE TABLE public.personal_vault_authorizations (token uuid PRIMARY KEY, owner_id uuid NOT NULL REFERENCES public.profiles(id), action text NOT NULL, record_id uuid, expires_at timestamptz NOT NULL DEFAULT(now()+interval '60 seconds'));
GRANT ALL ON public.personal_vault_authorizations TO service_role;
ALTER TABLE public.personal_vault_authorizations ENABLE ROW LEVEL SECURITY;
CREATE INDEX personal_auth_expiry_idx ON public.personal_vault_authorizations(expires_at);
CREATE OR REPLACE FUNCTION public.personal_vault_command(_action text, _data jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE _owner uuid:=auth.uid(); _id uuid; _row public.personal_vault_records; _wrap public.personal_vault_keys; _proof uuid;
BEGIN
 IF NOT public.vault_member() THEN RAISE EXCEPTION 'VAULT_DENIED'; END IF;
 IF coalesce(auth.jwt()->>'aal','') <> 'aal2' THEN RAISE EXCEPTION 'VAULT_MFA_REQUIRED'; END IF;
 IF octet_length(_data::text)>160000 THEN RAISE EXCEPTION 'VAULT_INVALID'; END IF;
 DELETE FROM public.personal_vault_authorizations WHERE token=(_data->>'authorization')::uuid AND owner_id=_owner AND action=_action AND record_id IS NOT DISTINCT FROM (_data->>'id')::uuid AND expires_at>now() RETURNING token INTO _proof;
 IF _proof IS NULL THEN RAISE EXCEPTION 'VAULT_FRESH_VERIFICATION_REQUIRED'; END IF;
 IF _action='setup' THEN
  INSERT INTO public.personal_vault_keys(owner_id,password_wrap,recovery_wrap) VALUES(_owner,_data->'password_wrap',_data->'recovery_wrap');
 ELSIF _action='recover' THEN
  UPDATE public.personal_vault_keys SET password_wrap=_data->'password_wrap', revision=revision+1 WHERE owner_id=_owner AND revision=(_data->>'revision')::integer RETURNING * INTO _wrap;
  IF NOT FOUND THEN RAISE EXCEPTION 'VAULT_CONFLICT'; END IF;
 ELSIF _action='create' THEN
  _id:=(_data->>'id')::uuid;
  INSERT INTO public.personal_vault_records(id,owner_id,envelope) VALUES(_id,_owner,_data->'envelope');
 ELSIF _action IN ('edit','favorite','delete') THEN
  _id:=(_data->>'id')::uuid;
  SELECT * INTO _row FROM public.personal_vault_records WHERE id=_id AND owner_id=_owner FOR UPDATE;
  IF NOT FOUND OR (_data->>'revision') IS NULL OR _row.revision<>(_data->>'revision')::integer THEN RAISE EXCEPTION 'VAULT_CONFLICT'; END IF;
  IF _action='delete' THEN DELETE FROM public.personal_vault_records WHERE id=_id AND owner_id=_owner;
  ELSE UPDATE public.personal_vault_records SET envelope=_data->'envelope',revision=revision+1 WHERE id=_id AND owner_id=_owner; END IF;
 ELSIF _action IN ('reveal','copy') THEN
  _id:=(_data->>'id')::uuid;
  IF NOT EXISTS(SELECT 1 FROM public.personal_vault_records WHERE id=_id AND owner_id=_owner) THEN RAISE EXCEPTION 'VAULT_DENIED'; END IF;
 ELSIF _action<>'unlock' THEN RAISE EXCEPTION 'VAULT_INVALID'; END IF;
 INSERT INTO public.personal_vault_events(owner_id,record_id,action) VALUES(_owner,_id,_action);
 RETURN jsonb_build_object('ok',true);
END $$;
REVOKE ALL ON FUNCTION public.personal_vault_command(text,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.personal_vault_command(text,jsonb) TO authenticated,service_role;